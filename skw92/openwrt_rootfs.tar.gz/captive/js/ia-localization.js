(function(String, window, document, exportKey) {
    'use strict';

    var _localizedStrings = {
        "en": {
            "free_wifi": "Free Wi-Fi",
            "from_inobi": "from <strong>Inobi</strong>",
            "internet_will_connect_after": "Internet connects in",
            "skip": "Skip",
            "profilactic_work_title": "Profilactic work",
            "profilactic_work_description": "Due to scheduled inspection, wi-fi is temporarily unavailable. Try later.",
            "connect": "Connect",
            "downloading": "Downloading...",
            "page_title": "Free Wi-Fi Inobi"
        },
        "ru": {
            "free_wifi": "Бесплатный Wi-Fi",
            "from_inobi": "от <strong>Inobi</strong>",
            "internet_will_connect_after": "Интернет подключится через",
            "skip": "Пропустить",
            "profilactic_work_title": "Профилактические работы",
            "profilactic_work_description": "В связи с плановой проверкой wi-fi временно недоступен. Попробуйте позже.",
            "connect": "Подключиться",
            "downloading": "Загружаю...",
            "page_title": "Бесплатный Wi-Fi Inobi"
            
        },
        "fa": {
            "free_wifi": "وای فای رایگان",
            "from_inobi": "از <strong>اینوبی</strong>",
            "internet_will_connect_after": "اتصال به اینترنت ظرف",
            "skip": "رد کردن",
            "profilactic_work_title": "اقدام پیشگیرانه",
            "profilactic_work_description": "به دلیل بازرسی از پیش برنامه ریزی شده، شبکه وای فای قطع می باشد. لطفاً بعداً تلاش کنید.",
            "connect": "اتصال",
            "downloading": "دانلود…",
            "page_title": "اینوبی وای فای رایگان"
        }
    }

    var CONFIGS = {
        'locale': null
    };

    function getDefaultLocaleNative() {
        var l;
        if (navigator.languages != undefined) {
            l = navigator.languages[0];
        } else {
            l = navigator.language;
        }
        l = l.toLowerCase();
        if (l.indexOf('-') !== -1) {
            return l.split('-')[0]
        }
        return l;
    }
    function getDefaultLocale() {
        return CONFIGS.locale || getDefaultLocaleNative();
    }

    String.prototype.localized = function(locale) {
        locale = locale || getDefaultLocale() || 'en';
        if (_localizedStrings[locale] && typeof _localizedStrings[locale][this] === 'string') {
            return _localizedStrings[locale][this];
        }
        return this;
    };

    function IALocalization() {}

    IALocalization.Locales = Object.keys(_localizedStrings).reduce(function(acc, l) { acc[l.toUpperCase()] = l; return acc; }, {});

    IALocalization.setDefaultLocale = function (locale, apply) {
        CONFIGS.locale = locale.toLowerCase();

        apply = apply === undefined ? false : apply;

        if (apply) { IALocalization.applyLocalization(); }

        return this;
    };

    IALocalization.applyLocalization = function() {
        var elements = document.getElementsByTagName('*');
        var defaultLocale = getDefaultLocale();
        for (var i = 0; i < elements.length; i++) {
            var el = elements[i];
            if (el.dataset.iaLocalizable !== undefined) {
                if (el.lang === undefined) { 
                    el.lang = defaultLocale;
                }
                el.innerHTML = el.dataset.iaLocalizable.localized(el.lang);
            }
        }

        return this;
    };


    if (exportKey !== undefined) {
        window[exportKey] = IALocalization;
    }

})(String, window, document, 'IALocalization');