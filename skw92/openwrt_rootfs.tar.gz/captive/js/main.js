(function() {
  'use strict';
  var TEST = document.createElement('span'),
      isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream,
      fuckingAndroid = /Android (2|3|4)/.test(navigator.userAgent);
  TEST.innerHTML = 'TEST IOS';

  var PRODUCTION = true;
  window.print = PRODUCTION ? function(){} : console.log;

  var STATE = {
    muted: true,
    hasInternet: false,
    hasRequestedInternet: false,
    redirectAddress: null,
  };

  function createDOMElementByType(parent, type) {
    var element = document.createElement(type),
        isVideo = (type === 'video'),
        iOSVideo = (type === 'video' && isIOS),
        iOSIfame = (type === 'iframe' && isIOS);

    // Assign element to global var
    DOM.banner = element;
    changeClass(element, 'add', 't-area__banner-' + type);

    if (isVideo || iOSVideo) {
      element.setAttribute('playsinline', 'playsinline');

      if (STATE.muted) {
        element.setAttribute('muted', 'muted');
      }
      changeClass(DOM.muteButton, STATE.muted ? 'remove' : 'add', state.active);

      fetchVideo(MAIN_CONFIG.source, DOM.banner);
    } else {
      element.src = MAIN_CONFIG.source;
    }

    if (iOSIfame) {
      changeClass(DOM.content, 'add', 'ios');
    }

    parent.appendChild(element);
  }

  function startCounter(duration, element, redirectOnCounterEnd) {

    var originalDuration = duration;

    duration = Math.ceil(duration);

    var hideHeaderDuration = Math.ceil(duration-MAIN_CONFIG.duration);

    element.innerHTML = (duration-hideHeaderDuration);
    changeClass(element.parentElement, 'add', state.active);

    var _interval = setInterval(function() {

      duration -= 1;

      if (duration === hideHeaderDuration+1) {
        getInternet();
      }

      if (duration === hideHeaderDuration) {
        notify(NOTIFICATION_TYPES.counterPassed, originalDuration-duration);

        changeClass(DOM.skipLink, 'remove', state.hidden);
        element.innerHTML = '';
        changeClass(DOM.header, 'add', state.notDisplayed);

        DOM.content.addEventListener('click', function(e) {
          redirectTo(MAIN_CONFIG.redirect);
        });
      }

      if (duration === 0) {
        notify(NOTIFICATION_TYPES.contentEnded);

        clearInterval(_interval);
        if (redirectOnCounterEnd === true) {
          redirectTo(MAIN_CONFIG.redirect);
        }
      }

      if (duration > hideHeaderDuration) {
        element.innerHTML = (duration-hideHeaderDuration);
      }
    }, 1000);
  }

  function getInternet(ok) {
    ok = (ok === undefined) ? true : false;
    
    if (STATE.hasRequestedInternet) {
      return;
    }

    var xhr = new XMLHttpRequest();
    xhr.open('GET', "connect.php?id="+MAIN_CONFIG.id+"&ok="+(ok ? "true" : "false"), true);

    xhr.addEventListener('load', function(event) {
      notify(NOTIFICATION_TYPES.gotInternet);
      if (xhr.status === 200) {
        STATE.hasInternet = true;
        if (STATE.redirectAddress !== null) {
          redirectTo(STATE.redirectAddress);
        }
      } else {
        console.log('error', xhr.status);
      }
    });

    xhr.send();

    STATE.hasRequestedInternet = true;
  }

  function redirectTo(address) {
    if (STATE.hasInternet) {
      notify(NOTIFICATION_TYPES.redirect, 'http://'+address, isIOS);
    }
    if (STATE.redirectAddress === null) {
      STATE.redirectAddress = address;
    }
  }

  function listenToButtonClick() {
    DOM.button.addEventListener('click', function(e) {
      notify(NOTIFICATION_TYPES.connectClicked);

      e.preventDefault();
      e.stopPropagation();

      DOM.main.removeChild(DOM.panel);
      changeClass(DOM.contentContainer, 'remove', state.notDisplayed);
      changeClass(DOM.header, 'remove', state.notDisplayed);

      if (MAIN_CONFIG.type === 'video') {
        initVideo(DOM.banner);
      } else {
        changeClass(DOM.muteButton, 'add', state.notDisplayed);
        startCounter(MAIN_CONFIG.duration, DOM.counterInner, true);
      }
    });

    DOM.muteButton.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      handleVideoMute(DOM.banner);
    });
  }

  function changeClass(element, action, className) {
    if (element && action) {
      if (Array.isArray(className)) {
        className.forEach(function(item) {
          element.classList[action](item);
        });
      } else {
        element.classList[action](className);
      }
    }
  }

  function initVideo(video) {

    video.addEventListener('playing', function() {
      startCounter(video.duration || MAIN_CONFIG.duration, DOM.counterInner);
    });

    if (fuckingAndroid) {
      video.src = MAIN_CONFIG.source;
    }

    video.play();

    video.addEventListener('ended', function(event) {
      notify(NOTIFICATION_TYPES.contentEnded);
      redirectTo(MAIN_CONFIG.REDIRECT_DEFAULT);
    });

  }

  function fetchVideo(url, videoElement) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'blob';

    xhr.addEventListener('load', function(event) {
      if (xhr.status === 200) {
        var blob = xhr.response;
        if (!window.Blob) {
          var bb = new (window.WebKitBlobBuilder || window.BlobBuilder);
          bb.append(xhr.response);
          blob = bb.getBlob();
        }
        var URL = window.URL || window.webkitURL, // fuckingAndroid ? window.webkitURL : window.URL,
            blobUrl = URL.createObjectURL(blob);

        videoElement.src = blobUrl;
        makeVideoPlayableInline(videoElement);
        enableButton();
      } else {
        console.log('error', xhr.status);
      }
    });

    xhr.send();
  }

  // Perform actions
  function onDOMContentLoaded() {
    createDOMElementByType(DOM.content, MAIN_CONFIG.type);
  }

  function onLoad() {
    'use strict';

    window.notify(NOTIFICATION_TYPES.init, MAIN_CONFIG.id);

    if (MAIN_CONFIG.type !== 'video') {
      enableButton();
    }

    DOM.skipLink.addEventListener('click', function(e) {
      notify(NOTIFICATION_TYPES.skipClicked);

      e.preventDefault();
      e.stopPropagation();

      redirectTo(MAIN_CONFIG.redirect);
    });
    DOM.content.addEventListener('click', function(e) {
      notify(NOTIFICATION_TYPES.contentClicked);
    });

    window.onerror = function(e) {
      notify(NOTIFICATION_TYPES.windowError);
      getInternet(false);
      redirectTo(MAIN_CONFIG.REDIRECT_DEFAULT);
    };
  }

  function enableButton() {
    setTimeout(function() {
      DOM.button.innerHTML = 'connect'.localized();
      changeClass(DOM.button, 'remove', state.disabled);
      listenToButtonClick();
    }, 300);
  }

  function handleVideoMute(videoElem) {
    STATE.muted = !videoElem.muted;
    notify(NOTIFICATION_TYPES.muteClicked, STATE.muted);

    videoElem.muted = STATE.muted;
    changeClass(DOM.muteButton, STATE.muted ? 'remove' : 'add', state.active);
  }


  window.addEventListener('DOMContentLoaded', onDOMContentLoaded);
  window.addEventListener('load', onLoad);
  window.addEventListener('unload', function (e) { notify(NOTIFICATION_TYPES.unload); });
}());
