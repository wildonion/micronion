(function() {
  'use strict';
  
  var NOTIFICATION_TYPES = {
    init: 'INOBI_INIT',
    connectClicked: 'INOBI_CONNECT_CLICKED',
    muteClicked: 'INOBI_MUTE_CLICKED',
    counterPassed: 'INOBI_COUNTER_PASSED',
    gotInternet: 'INOBI_GOT_INTERNET',
    skipClicked: 'INOBI_SKIP_CLICKED',
    contentEnded: 'INOBI_CONTENT_ENDED',
    contentClicked: 'INOBI_CONTENT_CLICKED',
    redirect: 'INOBI_REDIRECT',
    redirectLoaded: 'INOBI_REDIRECT_LOADED',
    unknown: 'INOBI_UNKNOWN',
    unload: 'INOBI_UNLOAD',
    windowError: 'INOBI_WINDOW_ERROR',
  };

  var NOTIFICATION_HANDLERS = {
    'INOBI_INIT': function(ad_id) { return { id: ad_id, }; },
    'INOBI_CONNECT_CLICKED': function() { return true; },
    'INOBI_MUTE_CLICKED': function(muted) { return { muted: muted, }; },
    'INOBI_COUNTER_PASSED': function(duration) { return { duration: duration, }; },
    'INOBI_GOT_INTERNET': function() { return true; },
    'INOBI_SKIP_CLICKED': function() { return true; },
    'INOBI_CONTENT_ENDED': function() { return true; },
    'INOBI_CONTENT_CLICKED': function() { return true; },
    'INOBI_REDIRECT': function(url, full) { return { url: url, full: full }; },
    'INOBI_REDIRECT_LOADED': function() { return true; },
    'INOBI_UNLOAD': function() { return true; },
    'INOBI_UNKNOWN': function() { return { args: Array.prototype.slice.call(arguments).slice(0), }; },
    'INOBI_WINDOW_ERROR': function() { return true; },
  };

  function notify() {
    if (!window.parent) {
      return;
    }

    var ntype = arguments[0],
        rest = Array.prototype.slice.call(arguments).slice(1),
        handler = NOTIFICATION_HANDLERS[ntype];
    
    if (typeof handler !== 'function') {
      handler = NOTIFICATION_HANDLERS[NOTIFICATION_TYPES.unknown];
    }
    var payload = handler.apply(undefined, rest);

    var d = { type: ntype, };
    if (payload !== null) {
      d['payload'] = payload;
    }

    var msg = JSON.stringify(d);

    parent.postMessage(msg, '*');
  }

  window.NOTIFICATION_TYPES = NOTIFICATION_TYPES;
  window.notify = notify;

  // function test() {
  //   notify(NOTIFICATION_TYPES.init, '123');
  //   notify(NOTIFICATION_TYPES.connectClicked);
  //   notify(NOTIFICATION_TYPES.muteClicked, true);
  //   notify(NOTIFICATION_TYPES.counterPassed, 5);
  //   notify(NOTIFICATION_TYPES.skipClicked, 12);
  //   notify(NOTIFICATION_TYPES.contentEnded);
  //   notify(NOTIFICATION_TYPES.connectClicked, 3);
  //   notify(NOTIFICATION_TYPES.redirect, 'inobi.kg', true);
  //   notify(NOTIFICATION_TYPES.redirectLoaded, 30);
  //   notify(NOTIFICATION_TYPES.unknown, 1,2,3);
  // }

  // test();
}());
