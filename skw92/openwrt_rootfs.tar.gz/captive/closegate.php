<?php

    $ip =$_SERVER['REMOTE_ADDR'];
    $output = shell_exec("sudo ./closegate.sh {$ip}"); 
    
    // var_dump($output);

    echo "You are out! Your IP: {$ip}";

?>
