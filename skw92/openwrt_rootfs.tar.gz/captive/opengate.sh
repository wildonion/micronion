#!/bin/bash

timeout=20
# minutes

echo $1

if iptables -n -L -t nat | grep -q $1
then
    echo "rule exist"
else
    echo "iptables -t nat -I PREROUTING -s $1 -j ACCEPT \
        && iptables -A FORWARD -s $1 -j ACCEPT \
        && iptables -A FORWARD -d $1 -j ACCEPT" | at now
        
    echo "iptables -t nat -D PREROUTING -s $1 -j ACCEPT \
        && iptables -D FORWARD -s $1 -j ACCEPT \
        && iptables -D FORWARD -d $1 -j ACCEPT" | at now + $timeout minutes
fi
