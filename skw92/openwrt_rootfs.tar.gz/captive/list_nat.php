<?php
	$cmd = "sudo iptables -L -t nat -n";

	$output = shell_exec($cmd);

	echo "<pre>\ncmd: $cmd\n```\n$output\n</pre>";
?>

