<?php
  include_once 'utils.php';
  $box_locale = $BOX_LOCALE;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title data-ia-localizable='page_title'>Free Wi-Fi Inobi</title>
  <style>

    body,
    html,
    .ia-container,
    .ia-container iframe,
    .ia-spinner-layer {
      position: relative;
      overflow: hidden;

      top: 0;
      right: 0;
      width: 100%;
      height: 100%;

      margin: 0;
      padding: 0;

      border: none;
    }

    .ia-spinner-layer {
      position: absolute;

      z-index: 3;

      background-color: rgb(227, 241, 252);
    }

    .hidden {
      display: none;
    }

    .ia-spinner {
      width: 100px;
      height: 100px;

      background-image: url('img/loader.png');
      background-size: contain;

      animation: spinnerAnimation 1s linear infinite;
      -webkit-animation: spinnerAnimation 1s linear infinite;
    }
    .ia-centered {
      position: absolute;

      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
    @keyframes spinnerAnimation {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(359deg);
      }
    }
  </style>
  <script src='js/ia-localization.js'></script>
  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/ia-notifier.js"></script>
</head>
  <body>
    <div class="ia-container">
      <iframe src="the_index.php"></iframe>
    </div>
    <div class="ia-spinner-layer">
      <div class="ia-centered">
        <div class="ia-spinner" />
      </div>
    </div>
  </body>
  <script type="text/javascript">
    'use strict';

    window.onerror = function (e) {
      console.log('window.onerror', e);
    };
  </script>

  <script type="text/javascript">
    IALocalization.setDefaultLocale(<?php echo json_encode($box_locale); ?>, true);
  </script>

  <script type="text/javascript">
    'use strict';

    function changeClass(element, action, className) {
      if (element && action) {
        if (Array.isArray(className)) {
          className.forEach(function(item) {
            element.classList[action](item);
          });
        } else {
          element.classList[action](className);
        }
      }
    }
  </script>
  <script type="text/javascript">
    'use strict';

    var PRODUCTION = true;
    window.print = PRODUCTION ? function(){} : console.warn;

    var iframe = document.querySelector('iframe');
    var spinnerLayer = document.querySelector('.ia-spinner-layer');
    var STATE = {
      theIndexLoaded: false,
    };

    // IFRAME EVENTS

    function onIframeDOMLoaded(e) {
      changeClass(spinnerLayer, 'add', 'hidden');
    }

    function onIframeLoaded(e) {
      if (STATE.theIndexLoaded === false) {
        STATE.theIndexLoaded = true;
      } else {
        try {
          addEventToChronicles(NOTIFICATION_TYPES.redirectLoaded);
        } catch (e) {
        }
      }
      changeClass(spinnerLayer, 'add', 'hidden');
    }

    iframe.addEventListener('DOMContentLoaded', onIframeDOMLoaded);
    iframe.addEventListener('load', onIframeLoaded);
  </script>
  <script type="text/javascript">
    'use strict';


    // CHRONICLES 

    window.chronicles = {
      id: null,
      events: [],
      redirected: false,
    };
    function addEventToChronicles(eventType) {
      window.chronicles.events = chronicles.events.concat(eventType.slice(6));
      print(chronicles.events);
    }
    function onWindowUnload(onChroniclesLoaded) {
      if (chronicles.sent === true) {
        return;
      }
      var xhr = new XMLHttpRequest();
      xhr.open('POST', "register/", true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.addEventListener('load', function(e) {
        if (typeof onChroniclesLoaded === 'function') {
          onChroniclesLoaded();
        }
      });
      xhr.send(JSON.stringify(window.chronicles));
      window.chronicles.sent = true;
    }
    window.addEventListener('unload', onWindowUnload);


    // IFRAME MESSAGING

    function onWindowMessage(e) {
      try {
        var action = JSON.parse(e.data);
        for (var ntype in NOTIFICATION_TYPES) {
          if (NOTIFICATION_TYPES[ntype] === action.type) {
            addEventToChronicles(action.type);
            break;
          }
        }
        switch (action.type) {
          case NOTIFICATION_TYPES.init:
            chronicles.id = action.payload.id;
            break;
          case NOTIFICATION_TYPES.redirect:
            var url = action.payload.url;
            var full = action.payload.full;

            if (full === true) {
              onWindowUnload(function(){
                document.location = url;
              });
            } else {
              iframe.src = url;
            }
            break;
          case NOTIFICATION_TYPES.skipClicked:
          case NOTIFICATION_TYPES.contentClicked:
            chronicles.redirected = true;
            break;
          case NOTIFICATION_TYPES.contentEnded:
            chronicles.redirected = false;
            break;
          case NOTIFICATION_TYPES.unload:
            onWindowUnload();
            break;
          default:
            break;
        }
      } catch (e) {
      }
    }

    window.addEventListener('message', onWindowMessage);
  </script>
</html>