<?php

    http_response_code(200);
    header("Content-Type: text/html; charset=utf-8");
    
    $ip = $_SERVER['REMOTE_ADDR'];

    $cmd = "/usr/bin/sudo /bin/bash ./opengate.sh {$ip}";
    
    $output = shell_exec($cmd);
    
    echo "You are welcome! IP-address: $ip";


    if (isset($_REQUEST['id']) and isset($_REQUEST['ok']) and $_REQUEST['ok'] === 'true') {

        include_once 'utils.php';

        $ad_id = $_REQUEST['id'];
        $configs = get_configs($TEST);
        $host = $configs['host'];

        $jwt = get_view_token($configs['mac']);
        $url = "$host/v1/register_view/$ad_id?jwt=$jwt";

        $r = shell_exec("curl -X POST -k $url");
        // var_dump($r);
    }

?>
