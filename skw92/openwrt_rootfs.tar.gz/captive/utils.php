<?php

    include_once 'config.php';

    include_once 'jwt/JWT.php';
    use \Firebase\JWT\JWT;


    function get_my_mac() {
        global $DEFAULT_MAC, $NETWORK_INTERFACE;
        $o = `ifconfig $NETWORK_INTERFACE`;
        preg_match('/([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})/', $o, $matches);
        return $matches[0];
    }

    function get_configs($test=false) {
        global $INTERVAL_UPDATE_CONFIGS;
        global $TMP_FOLDER;

        $filepath = $TMP_FOLDER.'box.config';
        $configs = parse_configs($filepath, true);
        if (!is_array($configs)
            or ((time() - $configs['iat']) > $INTERVAL_UPDATE_CONFIGS)
            or $test != $configs['test']
            or $configs['host'] === null
            or $test
            )
        {
            $host = get_host($test);
            $configs = array(
                'host' => $host,
                'internet' => is_internet_allowed($host),
                'mac' => get_my_mac(),
                'test' => $test
            );
            if ($host !== '_') {
                dump_configs($configs, $filepath, true);
            }
            return $configs;
        } else {
            return $configs;
        }
    }

    function get_coords() {
        global $LATLNG_FILE;
        $coords = parse_configs($LATLNG_FILE, true);
        if (!is_array($coords)) {
            $coords = array('lat'=>0.0, 'lng'=>0.0);
        } else {
            if (!array_key_exists('lat', $coords)) {
                $coords['lat'] = 0.0;
            }
            if (!array_key_exists('lng', $coords)) {
                $coords['lng'] = 0.0;
            }
        }

        return $coords;
    }

    function get_ad_token($mac=null, $pure=true) {

        $payload = get_coords();

        $payload['pure'] = $pure;
        $payload['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
        $payload['box_mac'] = $mac;
        $payload['client_mac'] = get_client_mac();
        $payload['update_version'] = get_update_version();

        global $BOX_PLATFORM;
        $payload['platform'] = $BOX_PLATFORM;

        return get_token($payload);
    }

    function get_view_token($mac=null) {

        $payload = get_coords();

        $payload['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
        $payload['box_mac'] = $mac;
        $payload['client_mac'] = get_client_mac();
        $payload['update_version'] = get_update_version();
        
        global $BOX_PLATFORM;
        $payload['platform'] = $BOX_PLATFORM;

        return get_token($payload);
    }

    function get_chronicles_token($mac, $chronicles) {

        $payload = get_coords();

        $payload['chronicles'] = $chronicles;
        $payload['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
        $payload['box_mac'] = $mac;
        $payload['client_mac'] = get_client_mac();
        $payload['update_version'] = get_update_version();
        
        global $BOX_PLATFORM;
        $payload['platform'] = $BOX_PLATFORM;

        return get_token($payload);
    }

    function get_token($payload=null) {
        global $JWT_KEY;
        if (!is_array($payload)) {
            $payload = array(
                'iat' => time(),
                'box_mac' => get_my_mac()
            );
        }
        if (!isset($payload['iat'])) {
            $payload['iat'] = time();
        }
        if (!isset($payload['box_mac'])) {
            $payload['box_mac'] = get_my_mac();
        }
        return JWT::encode($payload, $JWT_KEY);
    }

    function get_update_version() {
        global $VERSION_FILE;
        $f_path = $VERSION_FILE;
        $version = file_get_contents($f_path);
        return $version === false ? null : trim($version);
    }

    function get_host($test=false) {

        global $HOST_FILEPATH, $DEV_SERVER, $HOST_HOST, $HOST_POSTFIX, $BOX_REGION, $DEFAULT_HOST;

        if ($test) { return $DEV_SERVER; }

        if (file_exists($HOST_FILEPATH)) {
            return trim(file_get_contents($HOST_FILEPATH)).$HOST_POSTFIX;
        }
        
        $hosts = json_decode(file_get_contents($HOST_HOST), true);
        $h = $DEFAULT_HOST;
        if (array_key_exists($BOX_REGION, $hosts)) {
            $h = $hosts[$BOX_REGION];
        } else if (array_key_exists('', $hosts)) {
            $h = $hosts[''];
        }
        return $h.$HOST_POSTFIX;
    }

    function is_internet_allowed($host) {
        return $host === null ? true : (file_get_contents($host.'/box/internet') == '1' ? true : false);
    }

    function get_client_mac() {
        $client_ip = $_SERVER['REMOTE_ADDR'];
        $output = null;
        exec('arp -an', $output);
        foreach ($output as $_line) {
            $line = explode(" ", $_line);
            if (strpos($line[1], $client_ip) !== false) {
                $mac = $line[3];
                if (preg_match('/([a-fA-F0-9]{2}[:|\-]?){6}/', $mac) === 1) {
                    return $mac;
                }
                return null;
            }
        }
        return null;
    }

    function generate_identifier($by_mac=true) {
        sleep(0.3);
        $ip = $_SERVER['REMOTE_ADDR'];
        $mac = $by_mac ? get_client_mac() : $_SERVER['HTTP_USER_AGENT'];
        return $ip.$mac;
    }

    function print_array($name, $array, $level=0, $tab="_ _ ") {
        if ($name) {
            $level += 1;
            echo "$name:<br>";
        }
        foreach ($array as $key => $value) {
            echo str_repeat($tab, $level)."\"$key\": ";
            if (is_array($value)) {
                echo "<br>";
                print_array(null, $value, $level+1);
            } else {
                echo "\"$value\"<br>";
            }
        }
    }

    function parse_configs($filepath, $isjson=true) {
        if (!file_exists($filepath)) {
            return null;
        }
        $file = fopen($filepath, 'rb');
        if ($file) {
            if ($isjson) {
              $configs = json_decode(fread($file, filesize($filepath)), true);
            } else {
              $configs = array();
              while (!feof($file)) {
                  $line = fgets($file);
                  $equal_i = strpos($line, '=');
                  if ($equal_i !== false) {
                      $key = get_key(substr($line, 0, $equal_i));
                      $value = get_value(substr($line, $equal_i));
                      if ($key and $value) {
                          $configs[$key] = $value;
                      }
                  }
              }
            }
            fclose($file);
            return $configs;
        } else {
            return null;
        }
    }

    function dump_configs($configs, $filepath, $asjson=false) {
        global $TMP_FOLDER;
        if (!is_dir($TMP_FOLDER)) {
            mkdir($TMP_FOLDER);
        }
        if (is_array($configs)) {
            $file = fopen($filepath, 'wb');
            if ($file) {
                if (!isset($configs['iat'])) {
                    $configs['iat'] = time();
                }
                if ($asjson) {
                  fwrite($file, json_encode($configs, JSON_PRETTY_PRINT));
                } else {
                  foreach ($configs as $key => $value) {
                      fwrite($file, $key.'='.strval($value).";\n");
                  }
                }
                fflush($file);
                fclose($file);
            }
        }
    }

    function get_key($s) {
        $allowed_chars = str_split('qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM0123456789');
        $out = '';
        foreach (str_split($s) as $ch) {
            if (in_array($ch, $allowed_chars)) {
                $out .= $ch;
            } else {
                return false;
            }
        }
        return (strlen($out) > 0) ? $out : false;
    }

    function get_value($s) {
        return strval(trim($s, " \t\n\r,=;"));
    }

    function log_to_file($contents, $sep=" ", $end="\n") {
        global $DEFAULT_TIMEZONE;
        date_default_timezone_set($DEFAULT_TIMEZONE);
        $time = date("Y/m/d H:i:s ");
        if (is_array($contents)) {
          array_splice($contents, 0, 0, $time);
        } else {
          $contents = array($time, $contents);
        }
        global $TMP_FOLDER;
        $file = fopen($TMP_FOLDER.'box.log', 'ab');
        if ($file) {
          $length = count($contents);
          foreach ($contents as $index => $arg) {
            fwrite($file, $arg.(($index < $length-1) ? $sep : $end));
          }
          fflush($file);
          fclose($file);
          return true;
        } else {
          echo 'Error logging';
          return false;
        }
    }

    function get_cached_source_filename($sourcename) {
        global $MEDIA_FOLDER;
        return $MEDIA_FOLDER.$sourcename;
    }

    function get_source_url($host, $source, $api='/media/') {
        return $host.$api.$source;
    }

    function get_file_extension($filename) {
        $e_arr = explode('.', $filename);
        return $e_arr[count($e_arr)-1];
    }

    function media_exists($filename) {
        global $MEDIA_FOLDER;
        return file_exists($MEDIA_FOLDER.$filename);
    }

    function cached_filename($sourcename) {
        $index = parse_configs(get_cached_source_filename('.index'), true);
        if ($index) {
            $index = $index['index'];
            if (isset($index[$sourcename])) {
                $status = $index[$sourcename];
                if (is_string($status)) {
                    return media_exists($status) ? $status : null;
                } else if (is_array($status)) {
                    if ($status['is_fetching']) {
                        global $INTERVAL_NORMAL_FILE_FETCH;
                        if (time() - $status['iat'] > $INTERVAL_NORMAL_FILE_FETCH) {
                            return null;
                        } else {
                            sleep(1);
                            return cached_filename($sourcename);
                        }
                    }
                }
            } else {
                return null;
            }
        }
        return null;
    }

    function get_cached_source_url($filename, $absolete=false) {

        global $IS_MEDIA_TMP;

        $uri = $IS_MEDIA_TMP ? "/media/tmp/$filename" : "/media/$filename";

        return $absolete ? "http://$_SERVER[HTTP_HOST]$uri" : $uri;

        // $url = "media/?src=$filename";
        // return $absolete ? 'http://'.$_SERVER['HTTP_HOST'].$url : $url;
    }

    function get_source_new_filename($file_extension) {
        global $MEDIA_FOLDER;
        $count = 1;
        $new_name = "$count.$file_extension";
        while (file_exists($MEDIA_FOLDER.$new_name)) {
            $count += 1;
            $new_name = "$count.$file_extension";
        }
        return $new_name;
    }

    function cache_single_source($src, $full_src_url, $to_url=true) {
        global $IS_MEDIA_TMP;
        if ($IS_MEDIA_TMP && memory_limit_exceeded()) {
            return $full_src_url;
        }

        global $MEDIA_FOLDER;
        if (!is_dir($MEDIA_FOLDER)) {
            if (!mkdir($MEDIA_FOLDER, 0777, true)) {
                return $full_src_url;
            }
        }

        $index_file_path = get_cached_source_filename('.index');
        $index = parse_configs($index_file_path, true);
        $index = isset($index) ? $index['index'] : array();

        $localname = get_source_new_filename(get_file_extension($src));
        $src_status = array('iat'=>time(), 'is_fetching'=>true);
        $index[$src] = $src_status;

        file_put_contents(
            $index_file_path,
            json_encode(
                array('iat'=>time(), 'index'=>$index),
                JSON_PRETTY_PRINT
            )
        );

        $r = file_put_contents(
            get_cached_source_filename($localname),
            fopen($full_src_url, 'rb')
        );

        if ($r === false) {
            $src_status = array('iat'=>time(), 'is_fetching'=>false);
            $index[$src] = $src_status;

            file_put_contents(
                $index_file_path,
                json_encode(
                    array('iat'=>time(), 'index'=>$index),
                    JSON_PRETTY_PRINT
                )
            );
            return $full_src_url;
        } else {
            $index[$src] = $localname;
            file_put_contents(
                $index_file_path,
                json_encode(
                    array('iat'=>time(), 'index'=>$index),
                    JSON_PRETTY_PRINT
                )
            );
            return $to_url ? get_cached_source_url($localname) : $localname;
        }
    }

    function memory_limit_exceeded() {

        $s = shell_exec('free -m | grep Mem');
        $mem_states = array_values(array_filter(explode(' ', $s)));
        $total = $mem_states[1];
        $used = $mem_states[2];
        $free = $mem_states[3];

        global $MEMORY_LIMIT;

        // can configure your own conditions here
        return ($total-$used) < $MEMORY_LIMIT;
    }

    function debug_print($obj) {
        echo "<script> console.log('$obj'); </script>";
    }

    function get_redirect_url($url, $fallback='inobi.kg') {
        $o = shell_exec("curl -sLk -D - ".$url." -o /dev/null | grep 'X-Frame-Options: .*' | sed 's/^.*: //'");
        $lowered = strtolower(trim($o));
        if ($lowered === 'sameorigin' or $lowered === 'deny') {
            return $fallback;
        }
        return $url;
    }

    function print_on_client($tag, $some) {
        $tag = json_encode($tag, JSON_PRETTY_PRINT);
        $json = json_encode($some, JSON_PRETTY_PRINT);
        echo "<script>console.log($tag, $json);</script>";
    }

 ?>
