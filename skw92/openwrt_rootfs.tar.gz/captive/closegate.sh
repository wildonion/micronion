#!/bin/bash

echo "iptables -t nat -D PREROUTING -s $1 -j ACCEPT \
    && iptables -D FORWARD -s $1 -j ACCEPT \
    && iptables -D FORWARD -d $1 -j ACCEPT" | at now
