<?php

  require '_proxy.php';
  require '../config.php';
  require '../utils.php';

  proxy_request_to($API['CHECK_LOGIN']);

?>