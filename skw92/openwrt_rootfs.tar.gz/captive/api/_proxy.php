<?php
  
  function request_getargs() {
    return '?'.join('&', array_map(function($key, $value) { return "$key=$value"; }, array_keys($_GET), $_GET));
  }

  $is_accepting_headers = true;

  $header_lines = [];

  function handle_curl_headerline($curl, $line) {

    global $is_accepting_headers, $header_lines;

    $header_lines[] = $line;

    if (strpos($line, 'HTTP') === 0) {
      $splitted = explode(' ', $line);
      if (count($splitted) === 3) {
        $status_code = (int)$splitted[1];
        if ($status_code >= 300 && $status_code < 400) {
          $is_accepting_headers = false;
        } else {
          $is_accepting_headers = true;
        }
      }
    }

    if ($is_accepting_headers) {
      header($line);
    }

    return strlen($line);
  }

  function proxy_request_to($to, $test=false) {

    $url = $to.request_getargs();

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);  
    curl_setopt($ch, CURLOPT_POST, 1);   
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
    curl_setopt($ch, CURLOPT_HEADERFUNCTION, 'handle_curl_headerline');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, file_get_contents('php://input'));

    $response = curl_exec($ch);
    $responseInfo = curl_getinfo($ch);
    curl_close($ch);

    if ($test) {
      header('X-Proxy-To: '.$to);
    }

    echo $response;
  }
?>