<?php

  require '_proxy.php';
  require '../config.php';
  require '../utils.php';
  require '../filter_utils.php';


  function echo_json($json) {
    http_response_code($json['status']);
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');

    echo json_encode($json);
    exit();
  }

  function publicify($ad) {
    global $REDIRECT_DEFAULT;

    if (!array_key_exists('external_source', $ad) or $ad['external_source']) {
        $source = $ad['source_full'];
    } else {

        $raw_url = $ad['source_full'];

        $cached = cached_filename($ad['source']);
        if (!$cached) {
          $cached = cache_single_source($ad['source'], $raw_url, false);
        }

        $source = $cached === $raw_url ? $raw_url : get_cached_source_url($cached, true);
    }

    $redirect_url = $ad['redirect_url'];

    if (strpos($redirect_url, 'http://') === false && strpos($redirect_url, 'https://') === false) {
      $redirect_url = "http://$redirect_url";
    }

    return array(
      'type' => $ad['type'],
      'duration' => $ad['duration'],
      'redirect_url' => $redirect_url,
      'source' => $source,
      'id' => $ad['id'],
      'REDIRECT_DEFAULT' => $REDIRECT_DEFAULT,
    );
  }

  $configs = # get_configs($TEST);
    $TEST 
    ? array(
      'host' => $DEV_SERVER.'/ad',
      'internet' => true,
      'mac' => get_my_mac(),
    )
    : array(
        'host' => $API['AD'],
        'internet' => true,
        'mac' => get_my_mac(),
      );

  if (array_key_exists('internet', $configs) and $configs['internet']) {
    
    $host = $configs['host'];
    $b_mac = $configs['mac'];
    $jwt = get_ad_token($b_mac);

    $c_mac = get_client_mac();
    $ad = $TEST ? false : get_repeated_ad($c_mac);

    $ad = $RENDER_MOCK_AD ? json_decode($MOCK_AD_JSON, true) : $ad;

    // ## TEST ## // remove on production
    $TESTARGS = $TEST ? 'test=true&' : '';

    $ad_url = "$host?{$TESTARGS}jwt=$jwt";
    if ($TEST) {
      header('X-Real-Request: '."$host?{$TESTARGS}");
    }

    $internet = $configs['internet'];
    
    if (!$ad) {
      $response = json_decode(file_get_contents($ad_url), true);
      if (is_array($response) and array_key_exists('status', $response) and $response['status'] == 200) {
        $ad = $response['ad'];;
        if (array_key_exists('internet', $response)) {
          $internet = $response['internet'];
        }
        if (array_key_exists('internet', $ad)) {
          $internet = $ad['internet'];
        }
      }
    }

    if ($ad and $host and $internet) {
      dump_fucking_android($c_mac, $ad);           
      // render_page(false, $host, $ad, $BOX_LOCALE, $HTML_GLOBAL_DIR, $REDIRECT_DEFAULT);
      echo_json(array(
        'ad' => publicify($ad), 
        'status' => 200, 
        'message' => 'OK'
      ));
    } else {
      echo_json(array(
        'error' => 'No Ad', 
        'status' => 500, 
        'message' => 'Kek',
      ));
      // render_page(true, null, null, $BOX_LOCALE, $HTML_GLOBAL_DIR);
    }
  } else {
    echo_json(array(
      'error' => 'No Ad', 
      'status' => 500, 
      'message' => 'Kek', 
    ));
    // render_page(true, null, null, $BOX_LOCALE, $HTML_GLOBAL_DIR);
  }


  // proxy_request_to($LOGIN_API['AD']);

?>