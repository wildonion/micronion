<?php
    include_once "../utils.php";

    header('Content-Type: application/json');

    echo '{"device_id": "'.get_client_mac().'"}';
?>