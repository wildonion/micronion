<?php

  require '_proxy.php';
  require '../config.php';

  proxy_request_to($API['RESTORE_ACCESS'], $TEST);

?>

