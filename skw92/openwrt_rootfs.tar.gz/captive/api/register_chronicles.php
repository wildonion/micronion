<?php
  
  http_response_code(200);
  header("Content-Type: text/html; charset=utf-8");
  
  $input = file_get_contents('php://input');
  $json = json_decode($input, true);

  if (!is_array($json)) {
    echo '<HTML><HEAD><TITLE></TITLE></HEAD><BODY></BODY></HTML>';
  }

  include_once '../utils.php';
  require '_proxy.php';

  $ad_id = $json['id'];

  $jwt = get_chronicles_token(get_my_mac(), $json);
  // $url = "${API[CHRONICLES]}$ad_id?jwt=$jwt";

  $_GET['jwt'] = $jwt;

  if ($TEST) {
    $_GET['test'] = 'true';
  }

  proxy_request_to("$API[CHRONICLES]$ad_id");

  // $r = shell_exec("curl -X POST -k $url");

?>