#!/bin/bash
iptables -t nat -D PREROUTING -s $1 -j ACCEPT
