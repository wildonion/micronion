<?php

    $HOST_HOST = 'http://inobi.kg/url_inobi_advert_bishkek.txt';

    $BOX_LOCALE = 'en';
    $HTML_GLOBAL_DIR = ''; // $BOX_LOCALE === 'fa' ? 'rtl' : '';

    $BOX_PLATFORM = 'wifi';

    $REDIRECT_DEFAULT = 'http://inobi.mobi';

    $INTERVAL_UPDATE_CONFIGS = 1000; // seconds
    $INTERVAL_NORMAL_FILE_FETCH = 12; // seconds

    // $DEV_SERVER = 'http://ads.inobi.kg';
    // $DEV_SERVER = 'http://transport.inobi.kg:5000/advertisement';
    // $DEV_SERVER = 'http://localhost:5000/advertisement';
    $DEV_SERVER = 'http://192.168.1.241:5000/advertisement';
    $TEST = true;  //(strpos(strtolower(`uname -n`), 'orangepi') === false) or 
            //(strpos(strtolower(`uname -a`), 'orangepi') === false);

    $DEFAULT_MAC = '00:00:00:00:00:00';
    $DEFAULT_TIMEZONE = "Asia/Bishkek";

    $DEBUG_CLIENT_MAC = 'f4:f5:db:fc:38:e7';

    $VERSION_FILE = '/home/dev/version';
    $LATLNG_FILE = '/tmp/latlon';

    $TMP_FOLDER = "/tmp/inobi/";
    $MEDIA_FOLDER = '/tmp/inobi/media/';
    $IS_MEDIA_TMP = true;
        
    if (is_writable('/mnt/media/')) {
        $MEDIA_FOLDER = '/mnt/media/inobi/media/';
        $IS_MEDIA_TMP = false;
    }

    $JWT_KEY = 'x7oV13J6nn33OFDog11lxIzO1lNNbsxBKUlAL1Zd';

    $BASE_URL = 'http://192.168.1.241:5000';
    // $BASE_URL = 'http://transport.inobi.kg:5000';
    $API = array(
        'LOGIN' => "$BASE_URL/app/v2/login",
        'CHECK_LOGIN' => "$BASE_URL/app/v1/login/check", 
        'VERIFY' => "$BASE_URL/app/v1/verify",
        'REGISTER' => "$BASE_URL/app/v2/register",

        'AD' => "$BASE_URL/advertisement/ad",
        'CHRONICLES' => "$BASE_URL/advertisement/v1/register/chronicles/"
    );


    $MEMORY_LIMIT = 80;  // Mb

    $RENDER_MOCK_AD = false;

    $MOCK_AD_JSON = '{
        "created": 1522908307.7178,
        "description": "For presentation",
        "duration": 8,
        "enabled": true,
        "expiration_date": null,
        "external_source": false,
        "id": "947316b3-71bf-4768-bbb2-b52c5af5e849",
        "lat": null,
        "lng": null,
        "platform": "all",
        "radius": 0.5,
        "redirect_url": "inobi.mobi",
        "requests": 1,
        "source": "d42ba3ee-50e1-46ba-9962-690d6483c6e5.jpg",
        "source_full": "http:\/\/localhost\/media\/d42ba3ee-50e1-46ba-9962-690d6483c6e5.jpg",
        "title": "Presentation Ad",
        "type": "banner",
        "views": 0,
        "views_max": null,
        "weight": 1
    }';

?>