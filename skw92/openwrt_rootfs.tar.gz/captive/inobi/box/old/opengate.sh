#!/bin/bash

timeout=20
# minutes
limit=100
# packets/sec

echo $1

if sudo iptables -n -L -t nat | grep -q $1
then
    echo "rule exist"
else
    sudo iptables -t nat -I PREROUTING -s $1 -j ACCEPT
    sudo iptables -A FORWARD -s $1 -j ACCEPT
    sudo iptables -A FORWARD -d $1 -j ACCEPT
    echo "sudo iptables -A FORWARD -s $1 -j ACCEPT -m limit --limit $limit ; sudo iptables -A FORWARD -d $1 -j ACCEPT -m limit --limit $limit ; sudo iptables -D FORWARD -s $1 -j ACCEPT ; sudo iptables -D FORWARD -d $1 -j ACCEPT" | sudo at now + 1 minutes
    echo "sudo iptables -t nat -D PREROUTING -s $1 -j ACCEPT ; sudo iptables -D FORWARD -s $1 -j ACCEPT -m limit --limit $limit ; sudo iptables -D FORWARD -d $1 -j ACCEPT -m limit --limit $limit" | sudo at now + $timeout minutes
fi
