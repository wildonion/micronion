<?php
    http_response_code(200);
    header("Content-Type: text/html; charset=utf-8");

    $input = file_get_contents('php://input');
    $json = json_decode($input, true);

    

?>
<HTML><HEAD><TITLE></TITLE></HEAD><BODY></BODY></HTML>