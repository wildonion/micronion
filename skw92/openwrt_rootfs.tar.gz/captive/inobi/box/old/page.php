<?php
    
    $url = $_REQUEST['url'];

    if (substr($url, 0, 7) !== 'http://' or substr($url, 0, 8) !== 'https://') {
        $url = 'http://'.$url;
    }

    $o = shell_exec("curl -sLk $url");

    foreach (explode("\n", $o) as $index => $line) {
        if ($index === 0 and strpos(strtolower($line), 'doctype') === false) {
            echo "<!DOCTYPE HTML>\n";
        }
        if (strpos($line, '</head>') !== false) {
            echo "<base href=\"$url\" target=\"_self\">\n";
        }
        echo $line."\n";
        if (strpos($line, '<head>') !== false) {
            echo "<base href=\"$url\" target=\"_self\">\n";
        }
    }


?>