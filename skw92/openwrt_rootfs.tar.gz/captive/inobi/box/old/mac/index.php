<?php

    include_once '../utils.php';

    $mac = get_my_mac();

?>
<html>
    <head>
    </head>

    <body>
        <p style="font-size: 5rem;"><?php echo $mac; ?></p>
    </body>

</html>