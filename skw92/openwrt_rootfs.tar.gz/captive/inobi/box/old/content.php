<?php
    
    include_once 'utils.php';

    function render_page($error, $host, $ad, $box_locale='en', $html_dir='', $default_redirect='inobi.kg') {
      $state = $error ? 'error' : 'normal';

      if (!$error) {
          $type = $ad['type'];
          if ($type == 'banner') {
              $type = 'img';
          }
          $duration = $ad['duration'];
          if (!array_key_exists('external_source', $ad) or $ad['external_source']) {
              $source = $ad['source_full'];
          } else {
              $cached = cached_filename($ad['source']);
              if ($cached) {
                  $source = get_cached_source_url($cached);
              } else {
                  $source = cache_single_source($ad['source'], $ad['source_full']);
              }
          }
          $redirect_url = get_redirect_url($ad['redirect_url'], 'inobi.kg');
          $title = 'бесплатный wi-fi';
          $title_key = 'free_wifi';
          $description = 'от <strong>Inobi</strong>';
          $description_key = 'from_inobi';
          $id = $ad['id'];
      } else {
          $type = 'error';
          $duration = '';
          $source = '';
          $redirect_url = '';
          $title = 'профилактические работы';
          $title_key = 'profilactic_work_title';
          $description = 'В связи с плановой проверкой wi-fi временно недоступен. Попробуйте позже.';
          $description_key = 'profilactic_work_description';
          $id = '';
      }



      echo <<<HTML
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-ia-localizable="page_title">Free Wi-Fi Inobi</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/ia-notifier.js"></script>
  </head>
  <body dir="$html_dir">
    <main class="b-main">
      <div class="ks-panel $state">
        <div class="ks-panel__content">
          <div class="ks-panel__card">
            <div class="ks-panel__card-logo">
              <span class="ks-panel__card-logo-img"></span>
            </div>
            <p class="ks-panel__card-heading" data-ia-localizable="$title_key">
              $title
            </p>
            <p class="ks-panel__card-description" data-ia-localizable="$description_key">
              $description
            </p>
            <button type="button" id="connectionBtn" class="ks-btn is-disabled" data-ia-localizable='downloading'>
              загружаю...
            </button>
          </div>
        </div>
      </div>
      <div class="b-header b-header--$type not-displayed">
        <p class="b-header__content" data-ia-localizable="internet_will_connect_after">интернет подключится через</p>
        <span class="b-header__counter"><span></span></span>
      </div>
      <section class="t-area t-area--$type not-displayed">
        <div class="t-area__content">
          <button class="t-area__skip-link is-hidden" data-ia-localizable="skip">пропустить</button>
          <button class="t-area__mute-btn"></button>
        </div>
      </section>
    </main>
    <script>
    // Variables to use
    var MAIN_CONFIG = {
        type: '$type',
        source: '$source',
        duration: '$duration',
        redirect: '$redirect_url',
        id: '$id',
        REDIRECT_DEFAULT: '$default_redirect',
        locale: '$box_locale'
      },
      DOM = {
        html: document.getElementsByTagName('html')[0],
        main: document.querySelector('.b-main'),
        panel: document.querySelector('.ks-panel'),
        button: document.querySelector('.ks-btn'),
        contentContainer: document.querySelector('.t-area'),
        content: document.querySelector('.t-area__content'),
        header: document.querySelector('.b-header'),
        counter: document.querySelector('.b-header__counter'),
        counterInner: document.querySelector('.b-header__counter').firstChild,
        skipLink: document.querySelector('.t-area__skip-link'),
        muteButton: document.querySelector('.t-area__mute-btn'),
        video: document.querySelector('.t-area__video'),
      },
      state = {
        active: 'is-active',
        disabled: 'is-disabled',
        notDisplayed: 'not-displayed',
        visible: 'is-visible',
        hidden: 'is-hidden',
      };
      console.log(MAIN_CONFIG);

    </script>
    <script src="js/iphone-inline-video.browser.js"></script>
    <script src="js/ia-localization.js"></script>
    <script type="text/javascript">
      IALocalization.setDefaultLocale(MAIN_CONFIG.locale).applyLocalization();
    </script>
    <script src="js/main.js" type="text/javascript"></script>
  </body>
  </html>
HTML;
}
?>
