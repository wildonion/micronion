<?php

    include_once '../utils.php';


    $CONTENT_TYPE = array(

        'html' => 'text/html',
        'htm' => 'text/html',
        'shtml' => 'text/html',
        'css' => 'text/css',
        'xml' => 'text/xml',
        'gif' => 'image/gif',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'js' => 'application/javascript',
        'txt' => 'text/plain',

        'png' => 'image/png',
        'tif' => 'image/tif',
        'tiff' => 'image/tif',
        'bmp' => 'image/x-ms-bmp',
        'svg' => 'image/svg+xml',
        'svgz' => 'image/svg+xml',
        'webp' => 'image/webp',
        'ico' => 'image/x-icon',

        'json' => 'application/json',
        'doc' => 'application/msword',
        'pdf' => 'application/pdf',
        'rtf' => 'application/rtf',
        'xls' => 'application/vnd.ms-excel',

        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',

        'mp3' => 'audio/mpeg',
        'ogg' => 'audio/ogg',
        'm4a' => 'audio/x-m4a',

        'mp4' => 'video/mp4',
        'ogg' => 'video/ogg',
        'webm' => 'video/webm',
        'mpg' => 'video/mpeg',
        'mpeg' => 'video/mpeg',
        'mov' => 'video/quicktime',
        '3gp' => 'video/3gpp',
        '3gpp' => 'video/3gpp',
        'flv' => 'video/x-flv',
        'avi' => 'video/avi',
        'wmv' => 'video/x-ms-wmv'
    );

    $src = $_REQUEST['src'];
    $src_extension = get_file_extension($src);
    $src_path = get_cached_source_filename($src);
    $src_filesize = filesize($src_path);
    if (isset($CONTENT_TYPE[$src_extension]) && media_exists($src)) {
        //header("Accept-Ranges: bytes");
	    //header("Connection: keep-alive");
	    // header("Content-Length: $src_filesize");
        header("Content-Type: {$CONTENT_TYPE[$src_extension]}");
        header("X-Source-Filename: $src_path");
        header('Access-Control-Allow-Origin: *');
        readfile($src_path);
    } else {
        http_response_code(404);
        die('Not Found');
    }
 ?>
