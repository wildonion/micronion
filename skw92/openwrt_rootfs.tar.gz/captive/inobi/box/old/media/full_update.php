<?php

    function fall($message='Error') {
        echo "Error. ($message)";
        die();
    }

    $verbose = true;

    include '../utils.php';

    $configs = get_configs(false);
    $host = $configs['host'];

#
    if (!$host) {
        fall('Host is undefined');
    }

    $token = get_token();

    $response = json_decode(
        file_get_contents("$host/box/media_list?jwt=$token"),
        true
    );

#
    if (!isset($response['status']) or $response['status'] != 200) {
        fall('Media list response not ok');
    }

    $media_list = $response['media'];

    $prev_index = parse_configs(get_cached_source_filename('.index'), true);
    if (isset($prev_index)) {
        $prev_index = $prev_index['index'];
        if ($verbose) { print_array('cache_index', $prev_index); }
    } else {
        $prev_index = array();
    }

    if ($verbose) { print_array('server provided media list', $media_list); }

    $update_list = array();

    $cache_index = array();


    foreach ($media_list as $v) {
        if (isset($prev_index[$v])) {
            $cache_index[$v] = $prev_index[$v];
            unset($prev_index[$v]);
        } else {
            $update_list[] = $v;
        }
    }

    if ($prev_index) {
        $del_count = 0;
        foreach ($prev_index as $src => $localname) {
            if (!unlink(get_cached_source_filename($localname))) {
                $cache_index[$src] = $localname;
            } else {
                $del_count += 1;
            }
        }
        if ($verbose) { echo "deleted files: $del_count<br>"; }
    }

    if ($update_list) {
        $upd_count = 0;
        foreach ($update_list as $src) {
            $localname = get_source_new_filename(get_file_extension($src));
            file_put_contents(
                get_cached_source_filename($localname),
                fopen(get_source_url($host, $src), 'r')
            );
            $cache_index[$src] = $localname;
            $upd_count += 1;
        }
        if ($verbose) { echo "updated files: $upd_count<br>"; }
    }

    file_put_contents(
        get_cached_source_filename('.index'),
        json_encode(
            array('iat'=>time(), 'index'=>$cache_index),
            JSON_PRETTY_PRINT
        )
    );

#
 ?>
