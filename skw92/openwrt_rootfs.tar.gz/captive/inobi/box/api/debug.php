<?php 

  header('Content-Type: image/svg+xml');
  passthru('cat ../img/ic_volume.svg');
  exit();

  require '../utils.php';
  $_GET['device_id'] = get_client_mac();

  echo "<pre>\n";
  echo "GET-args: \n";
  foreach ($_GET as $key => $value) {
    echo "$key: $value;\n";
  }

  echo "\n\nHeaders: \n";
  foreach ($_SERVER as $key => $value) {
    if (substr($key, 0, 5) === 'HTTP_') {
      echo "$key: $value\n";
    }
  }

  echo "\n\nBody: \n";
  echo file_get_contents('php://input');

  echo "\n\nSERVER: \n";
  foreach ($_SERVER as $key => $value) {
    if (substr($key, 0, 5) !== 'HTTP_') {
      echo "$key: $value\n";
    }
  }
  echo "\n</pre>";


  $path = $_SERVER['DOCUMENT_ROOT'].$_SERVER['DOCUMENT_URI'];

  $kek = realpath($path.'/../media/');

  echo "\n<pre>\n";
  echo json_encode($_SERVER['HTTP_HOST'].join('/', array_slice(explode('/', $_SERVER['DOCUMENT_URI']), 0, -2)).'/media/');
  echo "\n</pre>";

  echo "\n<pre>\n";


  echo "\n</pre>";

?>
