<?php

  require '_proxy.php';
  require '../config.php';
  require '../utils.php';

  $_GET['device_id'] = get_client_mac();

  proxy_request_to($API['LOGIN']);

?>