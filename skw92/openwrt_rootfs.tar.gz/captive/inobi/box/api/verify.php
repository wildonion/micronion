<?php

  require '_proxy.php';
  require '../config.php';

  proxy_request_to($API['VERIFY']);

?>