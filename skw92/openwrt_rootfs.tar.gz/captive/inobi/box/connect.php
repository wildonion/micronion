<?php

    http_response_code(200);
    header("Content-Type: text/html; charset=utf-8");
    
    $ip = $_SERVER['REMOTE_ADDR'];

    $cmd = "sudo ts -f ./opengate.sh {$ip}";
    
    $output = shell_exec($cmd);
    
    //echo "<pre>\n";
    //echo "Your IP: $ip\n";
    //echo "cmd: $cmd\n";
    //echo "```\n";
    //echo "$output\n";
    //echo "```\n";
    //echo "</pre>";

    echo "You are welcome! IP-address: $ip";

    // usleep(123456);

?>
