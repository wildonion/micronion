<?php
    http_response_code(200);
    header("Content-Type: text/html; charset=utf-8");
    echo "<HTML><HEAD><TITLE></TITLE></HEAD><BODY></BODY></HTML>";
    
    $input = file_get_contents('php://input');
    $json = json_decode($input, true);

    if (is_array($json)) {

        include_once '../utils.php';

        $ad_id = $json['id'];
        $configs = get_configs($TEST);
        $host = $configs['host'];

        $jwt = get_chronicles_token($configs['mac'], $json);
        $url = "$host/v1/register/chronicles/$ad_id?jwt=$jwt";

        $r = shell_exec("curl -X POST -k $url");
    }

?>