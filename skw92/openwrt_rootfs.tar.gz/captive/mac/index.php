<?php

  $USER = 'admin';
  $PWD = 'iwbtmyh';

  if (!isset($_SERVER['PHP_AUTH_USER']) 
    || $_SERVER['PHP_AUTH_USER'] !== $USER 
    || $_SERVER['PHP_AUTH_PW'] !== $PWD
  ) {
    header('WWW-Authenticate: Basic realm="Box Info"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'Forbidden!';
    exit;
  }

  $WVDIAL_CONF_FILE = '/etc/wvdial.conf';
  $SETTINGS_FILE = '/settings.ini';
  $HOSTAPD_CONF_FILE = '/etc/hostapd/hostapd.conf';

  $WIRELESS_CONF_FILE = '/etc/config/wireless';
  $NETWORK_CONF_FILE = '/etc/config/network';

  $DO_REMOUNT = false;

  include_once '../utils.php';

    
  $CMD = array(
    'sudo' => '/usr/bin/sudo',
    'sed' => '/bin/sed',
    'grep' => '/usr/bin/grep',
    'aplay' => '/usr/bin/aplay',
  );

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (array_key_exists('sound', $_POST)) {
    
      $fn = 'sample.wav';
      `$CMD[sudo] $CMD[aplay] $fn`;
    
    } else if (array_key_exists('apn', $_POST)) {

      $value = $_POST['apn'];

      if ($DO_REMOUNT) {`$CMD[sudo] mount -o remount,rw /`;}
      `$CMD[sudo] $CMD[sed] -i "s~option apn '.*'~option apn '${value}'~g" ${NETWORK_CONF_FILE}`;
      // `$CMD[sudo] $CMD[sed] -i 's/APN_NAME = .*/APN_NAME = ${apn}/g' ${SETTINGS_FILE}`;
      if ($DO_REMOUNT) {`$CMD[sudo] mount -o remount,ro /`;}

    } else if (array_key_exists('ussd_cmd', $_POST)) {

      $value = $_POST['ussd_cmd'];

      if ($DO_REMOUNT) {`$CMD[sudo] mount -o remount,rw /`;}
      `$CMD[sudo] $CMD[sed] -i 's/USSD_COMMAND = .*/USSD_COMMAND = ${value}/g' ${SETTINGS_FILE}`;
      if ($DO_REMOUNT) {`$CMD[sudo] mount -o remount,ro /`;}

    } else if (array_key_exists('ssid', $_POST)) {

      $value = $_POST['ssid'];

      if ($DO_REMOUNT) {`$CMD[sudo] mount -o remount,rw /`;}
      `$CMD[sudo] $CMD[sed] -i "s~option ssid '.*'~option ssid '${value}'~g" ${WIRELESS_CONF_FILE}`;
      #`$CMD[sudo] $CMD[sed] -i 's/^ssid=.*/ssid=${value}/g' ${HOSTAPD_CONF_FILE}`;
      if ($DO_REMOUNT) {`$CMD[sudo] mount -o remount,ro /`;}

    } else if (array_key_exists('reboot', $_POST)) {

      `( ( sleep 1 && sudo reboot ) & ) &`;

    } else if (array_key_exists('obd', $_POST)) {

      $new_obd = array_key_exists('value', $_POST);
      $value = $new_obd ? 'yes' : 'no';

      if ($DO_REMOUNT) {`$CMD[sudo] mount -o remount,rw /`;}
      `$CMD[sudo] $CMD[sed] -i 's/OBD = .*/OBD = ${value}/g' ${SETTINGS_FILE}`;
      if ($DO_REMOUNT) {`$CMD[sudo] mount -o remount,ro /`;}

    } else if (array_key_exists('passenger_counter', $_POST)) {

      $new_passenger_counter = array_key_exists('value', $_POST);
      $value = $new_passenger_counter ? 'yes' : 'no';

      if ($DO_REMOUNT) {`$CMD[sudo] mount -o remount,rw /`;}
      `$CMD[sudo] $CMD[sed] -i 's/PASS_COUNTER = .*/PASS_COUNTER = ${value}/g' ${SETTINGS_FILE}`;
      if ($DO_REMOUNT) {`$CMD[sudo] mount -o remount,ro /`;}
    }

    header('Location: '.$_SERVER['PHP_SELF']);
    die;
  } 


  $mac = get_my_mac();

  $ussd_cmd = `$CMD[grep] "USSD_COMMAND =" ${SETTINGS_FILE}`; 
  if (strpos($ussd_cmd, 'USSD_COMMAND =') !== false) {
    $ussd_cmd = explode('=', $ussd_cmd)[1];
    $ussd_cmd = trim($ussd_cmd);
  } else {
    $ussd_cmd = false;
  }

  $obd = `$CMD[grep] "OBD =" ${SETTINGS_FILE}`; 
  if (strpos($obd, 'OBD =') !== false) {
    $obd = explode('=', $obd)[1];
    $obd = trim($obd);
    if (in_array(strtolower($obd), ['yes', 'true', '1', 'on'])) {
      $obd = 'checked';
    } else {
      $obd = '';
    }
  } else {
    $obd = false;
  }


  $passenger_counter = `$CMD[grep] "PASS_COUNTER =" ${SETTINGS_FILE}`; 
  if (strpos($passenger_counter, 'PASS_COUNTER =') !== false) {
    $passenger_counter = explode('=', $passenger_counter)[1];
    $passenger_counter = trim($passenger_counter);
    if (in_array(strtolower($passenger_counter), ['yes', 'true', '1', 'on'])) {
      $passenger_counter = 'checked';
    } else {
      $passenger_counter = '';
    }
  } else {
    $passenger_counter = false;
  }

  $ip = $_SERVER['REMOTE_ADDR'];

  $version = trim(`cat /version`);

  $host = trim(`cat /tmp/inobi/host`);

  $php_host = get_host();

  $ssid = `$CMD[grep] 'option ssid' "${WIRELESS_CONF_FILE}"`;
  if (strpos($ssid, 'option ssid') !== false) {
    $ssid = explode(' ', trim($ssid), 3)[2];
    $ssid = trim($ssid, "'");
  } else {
    $ssid = false;
  }

  $apn = `$CMD[grep] 'option apn' "${NETWORK_CONF_FILE}"`; 
  if (strpos($apn, 'option apn') !== false) {
    $apn = explode(' ', trim($apn), 3)[2];
    $apn = trim($apn, "'");
  } else {
    $apn = false;
  }

?>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    * {
      box-sizing: border-box;
    }
    form {
      margin: 0.2em;
    }
    body {
      margin: 0;
    }
    pre, .pure {
      padding: 5px;
      word-wrap: break-word;
    }
    .large {
      font-size: 2rem;
    }
    .dashboard {
    }
    .dashboard .tab {
      background-color: #73ec73;
      border: 2px solid darkgreen;
      margin: 0.2%;
      width: 24.6%;
      float: left;
      padding: 10px 5px;
      font-size: 20px;
      text-align: center;
      height: 150px;
    }
    .dashboard h3 {
      margin: 0;
    }
    .dashboard p {
      margin: 0;
      margin-top: 10px;
    }
    .dashboard .accent {
      color: darkred;
    }

    @media (max-width: 900px) {
      .dashboard .tab {
        width: 49.6%;
      }
      .dashboard p {
        font-size: 16px;
      }
    }

    .edit-value-from-config-form {
    }
    .edit-value-from-config-form input[type="text"] {
      width: 100%;
      font-size: 18px;
      padding: 2px;
      border: 2px solid darkgray;
    }
    .edit-value-from-config-form h3 {
      margin: 3px 10px;
    }
    .edit-value-from-config-form button {
      margin: 5px 0;
      font-size: 1.5em;
    }

  </style>
</head>

<body>

  <div class="dashboard">

    <div class="tab">
      <h3>MAC-address</h3>
      <p class="accent"><?php echo $mac; ?></p>
    </div>
    <div class="tab">
      <h3>Version</h3>
      <p class="accent"><?php echo $version; ?></p>
    </div>
    <div class="tab">
      <h3>Host</h3>
      <p class="accent"><?php echo $host; ?></p>
      <p style="font-size: 10px;">(php_host: <?php echo $php_host; ?>)</p>
    </div>
    <div class="tab">
      <h3>Your IP</h3>
      <p class="accent"><?php echo $ip; ?></p>
      <form method=post action="/connect.php" style="display: inline-block;">
        <button>Connect me</button>
      </form>
      <form method=post action="/closegate.php" style="display: inline-block;">
        <button class="">Disconnect me</button>
      </form>
    </div>

  </div style="margin-top: 30px;">

  <div>
    <h3>Sound</h3>
    <form method=post>
      <input type="hidden" name="sound"></input>
      <button>Play Sound Sample</button>
    </form>
    <hr>
  </div>

  <div>
    <h3>Manage</h3>
    <form method="post">
      <hr>
      <input type="hidden" name="obd" value="1"></input>
      <label>OBD: 
        <input 
            name="value" type="checkbox" 
            <?php if ($obd !== false) { echo $obd; } ?>
            <?php if ($obd === false) { echo 'disabled'; } ?>
          >
        </input>
      </label>
      <button <?php if ($obd === false) { echo 'disabled'; } ?>
        >
          Save
      </button>
    </form>
    <form method="post">
      <hr>
      <input type="hidden" name="passenger_counter" value="1"></input>
      <label>PASSENGER COUNTER: 
        <input 
            name="value" type="checkbox" 
            <?php if ($passenger_counter !== false) { echo $passenger_counter; } ?>
            <?php if ($passenger_counter === false) { echo 'disabled'; } ?>
          >
          </input>
        </label>
      <button <?php if ($passenger_counter === false) { echo 'disabled'; } ?>
        >
          Save
      </button>
    </form>
    <form method=post>
      <hr>
      <input type="hidden" name="reboot"></input>
      <button class="large" style="background-color: yellow;">Reboot</button>
    </form>
    <hr>
  </div>

  <div>
    <form method=post class="edit-value-from-config-form">
      <h3>APN</h3>
      <input type="text" name="apn" value="<?php echo $apn === false ? "*no <${NETWORK_CONF_FILE}> or `option apn` in <${NETWORK_CONF_FILE}> file*" : $apn; ?>" <?php if ($apn === false) { echo 'disabled'; } ?>></input><br>
      <button type="submit" style="background-color: red;"
        <?php if ($apn === false) { echo 'disabled'; } ?>
        >
        Save
      </button>
    </form>
    <hr>
  </div>

  <div>
    <form method=post class="edit-value-from-config-form">
      <h3>USSD Command</h3>
      <input type="text" name="ussd_cmd" value="<?php echo $ussd_cmd === false ? "*no <${SETTINGS_FILE}> or `USSD_COMMAND` in <settings.ini> file*" : $ussd_cmd; ?>" <?php if ($ussd_cmd === false) { echo 'disabled'; } ?>></input><br>
      <button type="submit" style="background-color: deeppink;"
        <?php if ($ussd_cmd === false) { echo 'disabled'; } ?>
        >
        Save
      </button>
    </form>
    <hr>
  </div>

  <div>
    <form method=post class="edit-value-from-config-form">
      <h3>Wi-Fi SSID</h3>
      <input type="text" name="ssid" value="<?php echo $ssid === false ? "*no <${WIRELESS_CONF_FILE}> or `option ssid` in <${WIRELESS_CONF_FILE}> file*" : $ssid; ?>" <?php if ($ssid === false) { echo 'disabled'; } ?>></input><br>
      <button type="submit"
        <?php if ($ssid === false) { echo 'disabled'; } ?>
        >
        Save
      </button>
    </form>
    <hr>
  </div>

  <div>
    <h5><?php echo $SETTINGS_FILE; ?></h5>
    <div style="overflow: auto; background-color: yellow;">
      <pre class="pure"><?php echo (`cat ${SETTINGS_FILE}`); ?></pre>
    </div>
    <hr>
    <h5>/tmp/inobi/settings</h5>
    <div style="overflow: auto;">
      <pre class="large"><?php echo (`cat /tmp/inobi/settings`); ?></pre>
    </div>
    <hr>
    <h5>/tmp/inobi/token</h5>
    <div style="overflow: auto;">
      <p class="pure"><?php echo (`cat /tmp/inobi/token`); ?></p>
    </div>
    <hr>
    <h5>/tmp/modem*</h5>
    <div style="overflow: auto;">
      <p class="pure"><?php echo (`cat /tmp/modem*`); ?></p>
    </div>
    <hr>
  </div>

</body>

</html>