<?phpi
	var_dump(shell_exec('/bin/bash -c "echo $PATH"'));
?>

