<?php

    include_once 'utils.php';
    
    function is_soother() {
        $lowered_ua = strtolower($_SERVER['HTTP_USER_AGENT']);
        if ($lowered_ua === null) {
            return true;
        }

        $bad_chunks = get_bad_user_agent_chunks();

        foreach ($bad_chunks as $chunk) {
            if ($chunk and strpos($lowered_ua, trim($chunk)) !== false) {
                return true;
            }
        }
        return false;
    }

    function get_bad_user_agent_chunks() {
        $filepath = 'ua_bad_chunks.list';
        if (file_exists($filepath)) {
            $content = file_get_contents($filepath);
            return explode("\n", $content);
        }
        return array();
    }

    function get_repeated_ad($mac) {
        $devices_c = get_fucking_androids();
        if (isset($devices_c['devices'])) {
            $devices = $devices_c['devices'];
            if (isset($devices[$mac])) {
                $ad_id = $devices[$mac];
                $ad_c = get_ads();
                if (isset($ad_c['ads'])) {
                    $ads = $ad_c['ads'];
                    if (isset($ads[$ad_id])) {
                        sleep(0.159);
                        return $ads[$ad_id];
                    }
                }
            }
        }
        return null;
    }

    function dump_fucking_android($c_mac, $ad) {
        if (!$ad and !$c_mac) {
            return;
        }
        $ad_id = dump_ad($ad);
        $devices_c = get_fucking_androids();
        if (!is_array($devices_c)) {
            $devices_c = array('iat' => time(), 'devices' => array());
        }
        $devices_c['devices'][$c_mac] = $ad_id;
        dump_configs($devices_c, '/tmp/inobi/fucking_androids.list', true);
    }

    function dump_ad($ad) {
        $ad_id = $ad['id'];

        $ad_c = get_ads();
        if (!is_array($ad_c)) {
            $ad_c = array('iat' => time(), 'ads' => array());
        }
        $ad_c['ads'][$ad_id] = $ad;
        dump_configs($ad_c, '/tmp/inobi/ads.list', true);

        return $ad_id;
    }

    function get_fucking_androids() {
        $filepath = '/tmp/inobi/fucking_androids.list';
        $fd_configs = parse_configs($filepath, true);
        if (is_array($fd_configs) and 
            isset($fd_configs['iat']) and
            (time() - $fd_configs['iat']) < 180 and
            is_array($fd_configs['devices'])) {
            
            return $fd_configs;
        }
        return null;
    }

    function get_ads() {
        $filepath = '/tmp/inobi/ads.list';
        $ad_configs = parse_configs($filepath, true);
        if (is_array($ad_configs) and 
            isset($ad_configs['iat']) and
            (time() - $ad_configs['iat']) < 180 and
            is_array($ad_configs['ads'])) {

            return $ad_configs;
        }
        return null;
    }

    
?>