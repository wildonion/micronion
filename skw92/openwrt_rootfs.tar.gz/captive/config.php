<?php

    $HOST_HOST = 'http://inobi.kg/hosts.json';
    $DEFAULT_HOST = 'http://transport.inobi.kg:5000';
    $HOST_FILEPATH = '/tmp/inobi/host';
    $HOST_POSTFIX = '/advertisement';
    $BOX_REGION = 'KG';

    $SETTINGS_FILEPATH = '/settings.ini';
    $DEVICE_ID_INTERFACE_KEY = 'DEVICE_ID_INTERFACE';

    $NETWORK_INTERFACE = 'eth0';
    
    if (is_readable($SETTINGS_FILEPATH)) {
        $o = `cat $SETTINGS_FILEPATH | grep -Eo '$DEVICE_ID_INTERFACE_KEY\s*=\s*\w+'`;
        if ($o) {
            $i = trim(explode('=', $o)[1]);
            if ($i) {
                $NETWORK_INTERFACE = $i;
            }
        }
    }


    $BOX_LOCALE = 'en';
    $HTML_GLOBAL_DIR = ''; // $BOX_LOCALE === 'fa' ? 'rtl' : '';

    $BOX_PLATFORM = 'wifi';

    $REDIRECT_DEFAULT = 'http://inobi.kg/';

    $INTERVAL_UPDATE_CONFIGS = 1000; // seconds
    $INTERVAL_NORMAL_FILE_FETCH = 12; // seconds

    // $DEV_SERVER = 'http://ads.inobi.kg';
    $DEV_SERVER = "$DEFAULT_HOST$HOST_POSTFIX";
    // $DEV_SERVER = 'http://217.29.22.238:5000/advertisement';
    // $DEV_SERVER = 'http://localhost:5000/advertisement';
    $TEST = false;  

    $DEFAULT_MAC = '00:00:00:00:00:00';
    $DEFAULT_TIMEZONE = 'Asia/Bishkek';

    $VERSION_FILE = '/version';

    $LATLNG_FILE = '/tmp/coords';

    $TMP_FOLDER = '/tmp/inobi/';
    $MEDIA_FOLDER = '/tmp/inobi/media/';
    $IS_MEDIA_TMP = true;
        
    if (is_writable('/mnt/media/')) {
        $MEDIA_FOLDER = '/mnt/media/inobi/media/';
        $IS_MEDIA_TMP = false;
    }

    $JWT_KEY = 'x7oV13J6nn33OFDog11lxIzO1lNNbsxBKUlAL1Zd';

    // $BASE_URL = 'http://localhost:5000';
    // $BASE_URL = 'http://217.29.22.238:5000';
    $BASE_URL = 'http://transport.inobi.kg:5000';

    if (is_readable($HOST_FILEPATH)) {
        $BASE_URL = trim(file_get_contents($HOST_FILEPATH));
    }

    $API = array(
        'LOGIN' => "$BASE_URL/app/v2/login",
        'CHECK_LOGIN' => "$BASE_URL/app/v1/login/check", 
        'VERIFY' => "$BASE_URL/app/v1/verify",
        'REGISTER' => "$BASE_URL/app/v2/register",
        'RESTORE_ACCESS' => "$BASE_URL/app/v1/restore_access",

        'AD' => "$BASE_URL/advertisement/ad",
        'CHRONICLES' => "$BASE_URL/advertisement/v1/register/chronicles/"
    );


    $MEMORY_LIMIT = 80;  // Mb

    $RENDER_MOCK_AD = false;

    $MOCK_AD_JSON = '{
        "created": 1522908307.7178,
        "description": "For presentation",
        "duration": 8,
        "enabled": true,
        "expiration_date": null,
        "external_source": false,
        "id": "mock20180729",
        "lat": null,
        "lng": null,
        "platform": "all",
        "radius": 0.5,
        "redirect_url": "inobi.mobi",
        "requests": 1,
        "source": "mock.png",
        "source_full": "http:\/\/localhost\/media\/mock\/mock.png",
        "title": "Presentation Ad",
        "type": "banner",
        "views": 0,
        "views_max": null,
        "weight": 1
    }';

?>

