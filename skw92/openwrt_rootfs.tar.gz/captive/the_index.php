<?php

    include_once 'filter_utils.php';

    if (is_soother()) {

        http_response_code(200);
        header("Content_Type: text/html; charset=utf-8");
        echo "<HTML><HEAD><TITLE></TITLE></HEAD><BODY></BODY></HTML>";

    } else {
        
        include_once 'utils.php';
        include_once 'content.php';

        // WARNING: 
        // change test configs in /connect.php too (on production too)
        $configs = get_configs($TEST);

        // var_dump($configs);

        if (array_key_exists('internet', $configs) and $configs['internet']) {
            
            $host = $configs['host'];
            $b_mac = $configs['mac'];
            $jwt = get_ad_token($b_mac);

            // echo $jwt;

            // print_on_client('the_index.php', $jwt);
            // print_on_client('the_index.php', $BOX_PLATFORM);

            $c_mac = get_client_mac();
            $ad = $TEST ? false : get_repeated_ad($c_mac);
            if (!$ad) {
                $response = json_decode(file_get_contents($host."/ad?jwt=".$jwt), true);
                if (is_array($response) and array_key_exists('status', $response) and $response['status'] == 200) {
                    $ad = $response['ad'];
                    // print_on_client('the_index.php', $ad);
                }
            }
            if ($ad and $host) {
                dump_fucking_android($c_mac, $ad);           
                render_page(false, $host, $ad, $BOX_LOCALE, $HTML_GLOBAL_DIR);
            } else {
                render_page(true, null, null, $BOX_LOCALE, $HTML_GLOBAL_DIR);
            }
        } else {
            render_page(true, null, null, $BOX_LOCALE, $HTML_GLOBAL_DIR);
        }
        
    }



?>
