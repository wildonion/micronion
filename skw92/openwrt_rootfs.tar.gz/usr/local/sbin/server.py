#!/usr/bin/env python3


import sys

__version_info__ = (0, 3, 1)
__version__ = '.'.join(map(str, __version_info__))

if __name__ == '__main__' and {'--version', '-V'} & set(sys.argv[1:]):
    print(__version__)
    sys.exit(0)


import time
# import requests
from _sub import requests
import math
import json
import re
import subprocess
import os, stat, sys
import threading
import re
import traceback
import shutil
import itertools as IT
import operator
import logging
import collections as C
import subprocess
import glob

logging.basicConfig()


def _get_mac(interface):
    output = subprocess.check_output(['ifconfig', interface]).decode()
    m = re.search(r'(?P<address>([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2}))', output)
    return m.groupdict()['address']


def pretty_printed(filter_func=lambda k, v: not k.startswith('__') and not k.endswith('__')):
    def wrapper(cls):
        fields = {
            k: getattr(cls, k)
            for k in dir(cls) if filter_func(k, getattr(cls, k))
        }
        cls.__str__ = lambda self: '<{}, {}>'.format(cls.__name__, ', '.join('{}={!r}'.format(k, getattr(self, k)) for k,v in fields.items()))
        
        def p(self=cls, indent=1):
            print((' '*4*(indent-1))+'class', cls.__name__)
            for k in sorted(fields):
                v = getattr(self, k)
                if filter_func(k, v):
                    print('{i}{k} ='.format(i=' '*4*indent, k=k), end=' ')
                    if hasattr(v, '_pretty'):
                        v._pretty(indent=indent+1)
                    else:
                        print(repr(v))
        cls._pretty = p
        
        return cls
    return wrapper


def _simple_parse_arg(*arg_keys, bool=False, array=False, default=None, default_factory=None, 
    prompt=None, prompt_factory=str.strip):

    assert not (bool and array), 'Argument can not be boolean and array type'

    arr = []

    args = sys.argv[1:]
    for ak in arg_keys:
        if ak in args:
            if bool:
                return True
            try:
                v = args[args.index(ak)+1]
            except IndexError:
                print(ak, 'argument needs value. (--help to see details)')
                sys.exit(0)
            else:
                if array:
                    arr.append(v)
                else:
                    return v
        if ak.startswith('--'):
            for a in args:
                if a.startswith('{}='.format(ak)):
                    v = a[len(ak)+1:]
                    if array:
                        arr.append(v)
                    else:
                        return v
        elif not bool and ak.startswith('-'):
            for a in args:
                if a.startswith(ak):
                    v = a[len(ak):]
                    if array: 
                        arr.append(v)
                    else:
                        return v

    if array:
        return arr

    if prompt is not None:
        i = input('{}: '.format(prompt))
        return prompt_factory(i)

    if not default_factory: return default
    else: return default_factory() 


def _is_http_schemed(url):
    return url.startswith('http://') or url.startswith('https://')


@pretty_printed(lambda k, v: k not in ('DEFAULT_TOKEN', 'API') and k.isupper() or k in 'file api interval'.split())
class BaseConfig:

    default = None

    SERVICE_NAME = 'server.py'

    @pretty_printed(lambda k, v: k.isupper())
    class Interval:
        SLEEP = 3
        PING = None         # if None pings after every sleep, else pings if only PING seconds passed from last ping
        HOST_RENEW = 5*60
        PASSENGER_COUNTER_RESET = 60*60
        PASSENGER_COUNTER_READ = 20
        TOKEN_UPDATE = 1*60*60

        MESSAGE_SENDER_SLEEP = 5
        
        DEFAULT_TIMEOUT = 10

        LED_NORMAL_PING = 10

        WAIT_TOKEN = WAIT_HOST_HOST = WAIT_PING = DEFAULT_TIMEOUT

    @pretty_printed(lambda k, v: k.isupper())
    class File:

        BOX_VERSION_FILE =                  '/version'

        HOST_OUTPUT =                   '/tmp/inobi/host'        
        BOX_CONFIG_OUTPUT =             '/tmp/inobi/settings'
        TOKEN_OUTPUT =                  '/tmp/inobi/token'
        MESSAGES_PIPE =                 '/tmp/inobi/message'

        OBD_INSTRUCTIONS_OUTPUT =       '/tmp/inobi/obd'
        LATLNG_INPUT =                  '/tmp/coords'
        OBD_INPUT =                     '/tmp/obd.out'
        PASS_COUNTER_DEVICE =           '/dev/ttymxc2'

        ADDITIONAL_DATA_DIR =           '/tmp/inobi/add.d'

        PASS_COUNTER_OUTPUT =           ADDITIONAL_DATA_DIR+'/passengers.once,_.json'

        MAKE_DIRS =                     [('/tmp/inobi', 0o777), (ADDITIONAL_DATA_DIR, 0o777)]

        MAKE_LINKS =                    [
                                            (LATLNG_INPUT, ADDITIONAL_DATA_DIR+'/coords._.json'),
                                            (OBD_INPUT, ADDITIONAL_DATA_DIR+'/obd.obd'),
                                        ]

        SSH_PIDFILE_TEMPLATE =          '/tmp/ssh_r{remote_port}.pid'

        SSH_INFO_OUTPUT =               ADDITIONAL_DATA_DIR+'/ssh_info.json'

    MAX_MESSAGES = 100

    VERBOSE = False

    DEFAULT_PING = dict()

    DATA_PRIORITY = ['coords', 'obd']

    REGION = 'KG'
    DEFAULT_REGION = ''

    HOST_HOST = 'http://inobi.kg/hosts.json'
    DEFAULT_HOST = 'http://transport.inobi.kg:5000'

    # DEFAULT_TOKEN = 'ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SndhRzl1WlNJNklpczVPVFl4TVRFeE1URXhNVEVpTENKNExXbHpjeTEwYVcxbElqb2lNakF4Tmkwd09TMHlPRlF3T0Rvek16b3hOaUlzSW5ndGRYTmxjaTFoWkdSeVpYTnpJam9pTWpFeUxqRXhNaTR4TURZdU1Ua3dJaXdpYzJOdmNHVWlPaUp3WVhOelpXNW5aWElzZFhObGNpSXNJbWx6Y3lJNkluUmxlaTA1T1RZdE1EQXVZWHAxY21WM1pXSnphWFJsY3k1dVpYUWlMQ0p1WVcxbElqb2lYSFV3TkRGaFhIVXdORE0xWEhVd05EUXlYSFV3TkRReVhIVXdORE00WEhVd05ETXhYSFV3TkRNMVhIVXdORE5oSW4wLmtFeUNvZ3VWZTBLZkNONk81eFNrc3RHal80SXdLd1V1NHV3QlJPc1FjYWc'
    DEFAULT_TOKEN = 'ZXlKMGVYQWlPaUpLVjFRaUxDSmhiR2NpT2lKSVV6STFOaUo5LmV5SjBhVzFsSWpveE5UTXdNVEF4T0RNM0xDSnpZMjl3WlhNaU9sc2lkSEpoYm5Od2IzSjBYM1Z1YVhRaUxDSjBjbUZ1YzNCdmNuUmZkVzVwZENoa1pXWmhkV3gwS1NKZExDSnBZWFFpT2pFMU16QXdPVGs1TWpRc0ltbHpjeUk2SW1seWMyRnNZV0prUUdkdFlXbHNMbU52YlNKOS45X1RlUGw3SGowckhEemhlMWpfal9mWkRCNWN2SjRyOXJ6R2ZDM1FhT0lJ'

    DEVICE_ID_INTERFACE = 'eth0'
    DEVICE_ID = None

    @pretty_printed(lambda k, v: k.isupper())
    class API:
        LOGIN =     '/transport/v1/login'
        PING =      '/transport/bus'
        MESSAGE =   '/debug/v1/messages'

    api = API()
    file = File()
    interval = Interval()

    OBD = True
    PASS_COUNTER = True

    LED = True

    MODEM_DEVICE_INTERFACE = 'ppp0'

    PASSENGER_COUNTER_CMD = 'rs485counter'

    SSH_EXECUTABLE = shutil.which('autossh')
    DEFAULT_SSH_HOST = 'box@devz.inobi.kg'
    DEFAULT_SSH_PORT = 22

    def _init_from_config_file(self, config_file):
        import configparser
        config = configparser.ConfigParser()
        config.read(config_file)

        from pprint import pprint

        try:
            default_section = config['SETTINGS']
        except KeyError:
            print('No [SETTINGS] section in {}'.format(config_file))
            sys.exit(1)

        # applying configs from following sections
        for section_name in ['API', 'File', 'Interval']:
            if section_name not in config:
                continue
            _section = getattr(self, section_name.lower())
            config_section = config[section_name]
            for option in config_section:
                option = option.upper()
                # applying int values in section
                v = config_section.get(option, fallback=getattr(_section, option))
                if section_name == 'Interval' and v.isdigit():
                    v = int(v)
                setattr(_section, option, v)

        # parsing File.MAKE_DIRS setting
        if 'File' in config:
            mkdirs_fallback = '\n'.join('{},0{:o}'.format(d, m) for d, m in self.File.MAKE_DIRS)
            mkdirs_val = config['File'].get('MAKE_DIRS', fallback=mkdirs_fallback)
            parse_fp_and_mod_chunk = lambda x: (x[0].strip(), int(x[1], 8))
            self.file.MAKE_DIRS = list(map(parse_fp_and_mod_chunk, map(lambda ch: ch.split(','), (ch for ch in mkdirs_val.split('\n') if ch.strip()))))

            mklinks_fallback = '\n'.join('{},{}'.format(src, dst) for src, dst in self.File.MAKE_LINKS)
            mklinks_vals = config['File'].get('MAKE_LINKS', fallback=mklinks_fallback)
            parse_tuple_of_fp = lambda x: tuple(map(str.strip, x))
            self.file.MAKE_LINKS = list(map(parse_tuple_of_fp, map(lambda ch: ch.split(','), (ch for ch in mklinks_vals.split('\n') if ch.strip()))))

        # applying config for default section ('SETTINGS' section)
        for option in default_section:
            option = option.upper()
            v = default_section.get(option, fallback=getattr(self, option))
            setattr(self, option, v)

        for int_key in 'MAX_MESSAGES'.upper().split():
            v = default_section.getint(int_key, fallback=getattr(self, int_key))
            setattr(self, int_key, v)

        # applying bool keys in default section
        for bool_key in 'VERBOSE OBD PASS_COUNTER LED'.upper().split():
            v = default_section.getboolean(bool_key, fallback=getattr(self, bool_key))
            setattr(self, bool_key, v)

        # applying json fields in default section
        ping_val = default_section.get('DEFAULT_PING', fallback=json.dumps(self.DEFAULT_PING))
        self.DEFAULT_PING = json.loads(ping_val)

    def __init__(self):

        config_file = _simple_parse_arg('-C', '--config', default=None)

        f = self.File()
        self.file = f
        self.interval = self.Interval()
        self.api = self.API()

        if config_file:
            self._init_from_config_file(config_file)

        self.HOST_HOST = _simple_parse_arg('-H', '--host-host', default=self.HOST_HOST)
        assert _is_http_schemed(self.HOST_HOST), 'URLs must be specified with scheme. (like: http://*)'
        self.DEFAULT_HOST = _simple_parse_arg('-h', '--host', default=self.DEFAULT_HOST)
        assert _is_http_schemed(self.DEFAULT_HOST), 'URLs must be specified with scheme. (like: http://*)'
        self.SERVICE_NAME = _simple_parse_arg('-N', '--name', default=self.SERVICE_NAME)
        self.REGION = _simple_parse_arg('-R', '--region', default=self.REGION)
        self.DEVICE_ID_INTERFACE = _simple_parse_arg('-I', '--interface', default=self.DEVICE_ID_INTERFACE)
        _id = _simple_parse_arg('-i', '--id', '--identifier')

        if _id is not None:
            self.DEVICE_ID = _id
        else:
            self.DEVICE_ID = _get_mac(self.DEVICE_ID_INTERFACE)

        self.VERBOSE = _simple_parse_arg('-v', '--verbose', default=self.VERBOSE, bool=True)

        self.interval.SLEEP = int(_simple_parse_arg('-t', '--sleep-interval', default=self.interval.SLEEP))

        output_directory = _simple_parse_arg('-O', '--output-dir', default='/tmp/inobi')

        d = (output_directory, int(_simple_parse_arg('--output-dir-mode', default='0777'), base=8))
        if d not in f.MAKE_DIRS:
            f.MAKE_DIRS.append(d)

        f.TOKEN_OUTPUT = os.path.join(output_directory, 'token')
        f.HOST_OUTPUT = os.path.join(output_directory, 'host')
        f.BOX_CONFIG_OUTPUT = os.path.join(output_directory, 'settings')
        f.MESSAGES_PIPE = os.path.join(output_directory, 'message')
        
        f.TOKEN_OUTPUT = _simple_parse_arg('--token-output', default=f.TOKEN_OUTPUT)
        f.HOST_OUTPUT = _simple_parse_arg('--host-output', default=f.HOST_OUTPUT)
        f.BOX_CONFIG_OUTPUT = _simple_parse_arg('--box-settings-output', default=f.BOX_CONFIG_OUTPUT)
        f.MESSAGES_PIPE = _simple_parse_arg('--messages-pipe', default=f.MESSAGES_PIPE)
        f.SSH_PIDFILE_TEMPLATE = _simple_parse_arg('--ssh-pidfile-template', default=f.SSH_PIDFILE_TEMPLATE)

        f.LATLNG_INPUT = _simple_parse_arg('-c', '--coords', '--coords-input', default=f.LATLNG_INPUT)
        f.OBD_INSTRUCTIONS_OUTPUT = _simple_parse_arg('--obd-instructions-output', default=f.OBD_INSTRUCTIONS_OUTPUT)
        f.OBD_INPUT = _simple_parse_arg('--obd-input', default=f.OBD_INPUT)

        f.PASS_COUNTER_DEVICE = _simple_parse_arg('--pass-counter-device', default=f.PASS_COUNTER_DEVICE)

        self.OBD = not _simple_parse_arg('--no-obd', bool=True, default=(not self.OBD))
        self.PASS_COUNTER = not _simple_parse_arg('--no-pass-counter', bool=True, default=(not self.PASS_COUNTER))

        self.LED = not _simple_parse_arg('--no-led', bool=True, default=(not self.LED))

        self.PASSENGER_COUNTER_CMD = _simple_parse_arg('--pass-counter-cmd', default=self.PASSENGER_COUNTER_CMD)

        BaseConfig.default = self

    @classmethod
    def _help(cls):
        script_name, *args = sys.argv
        print('''
Usage: {} [OPTIONS]

Available options: 

-C, --config                    Config file to read options from.

-H, --hosts-url                 Url where 'hosts.json' located, the JSON of available Inobi hosts by region. (default: {d.HOST_HOST!r})
-R, --region                    Region to lookup in 'hosts.json' file. (default: {d.REGION!r})
-h, --host                      Default host if given host is unaivalable or region not found. (default: {d.DEFAULT_HOST!r})
-I, --interface                 Device network interface to retrieve device-id from. (default: {d.DEVICE_ID_INTERFACE!r})
-i, --id, --identifier          Device id. If set, -I, --interface parameters ignored. (default: {d.DEVICE_ID!r})

-t, --sleep-interval            Ping interval. (default: {d.interval.SLEEP!r} sec.)

-c, --coords, --coords-input    Coordinates file to read from. (default: {d.file.LATLNG_INPUT!r})
--obd-input                     OBD input file to read OBD results from. (default: {d.file.OBD_INPUT!r})

-O, --output-dir                Output directory. Can be used to set output for token, host, settings and message files. 
--output-dir-mode               Set mode of output directory. (default: 0777)

--pass-counter-device           Passenger counter device interface. (default: {d.file.PASS_COUNTER_DEVICE!r})
--pass-counter-cmd              Passenger counter command. (default: {d.PASSENGER_COUNTER_CMD!r})

--no-obd                        Disables OBD reading. (default: {d.OBD!r})
--no-pass-counter               Disables passenger counting. (default: {d.PASS_COUNTER!r})
--no-led                        Disabled LED blinking. (default: {d.LED!r})

--token-output                  Box token output file. (default: {d.file.TOKEN_OUTPUT!r})
--host-output                   Box host output. (default: {d.file.HOST_OUTPUT!r})
--box-settings-output           Box settings output. (default: {d.file.BOX_CONFIG_OUTPUT!r})
--messages-pipe                 Messages FIFO to listen to. (default: {d.file.MESSAGES_PIPE!r})
--obd-instructions-output       OBD instuctions output file. (default: {d.file.OBD_INSTRUCTIONS_OUTPUT!r})
--ssh-pidfile-template          SSH pid file template (for autossh). (default: {d.file.SSH_PIDFILE_TEMPLATE!r})
--version-file                  Box version file. (default: {d.file.BOX_VERSION_FILE!r})

--dry-run, --check-configs      Prints resulting configs and exit.
    --dry, --test, --check

-N, --name                      Service name. (default: {d.SERVICE_NAME!r})
-v, --verbose                   Verbosity of script. (default: {d.VERBOSE!r})

-V, --version                   Print version of script.
--help                          Print this.
'''.format(script_name, d=cls))

    @classmethod
    def _dry_run_config(cls):
        cls()._pretty()


class Config(BaseConfig):
    pass


if __name__ == '__main__' and {'--help'} & set(sys.argv[1:]):
    BaseConfig._help()
    sys.exit(0)

if __name__ == '__main__' and {'--dry-run', '--check-configs', '--dry', '--test', '--check'} & set(sys.argv[1:]):
    BaseConfig._dry_run_config()
    sys.exit(0)


@pretty_printed(lambda k, v: k in ('last', 'host'))
class State:

    @pretty_printed()
    class Last:
        host_request = None
        ping = None
        token_update = None
        passenger_counter_reset = None

        settings = None
        data = None
        obd = None

        pass_counter = None
        pass_counter_read = None

        _succeeded_counters = None
        _raw_counter_values = None

    _iter_pass_counter_bauds = (9600, 19200)
    _iter_pass_counter_eyes = (1, 2)

    last = Last()

    cfg = None
    host = None
    token = None

    led = None

    class Led:
        OK = 0
        NO_PING = 1
        NO_DEVICE = 2

    class Error:
        func = None
        args = None
        exception = None

        def __init__(self, func, args, exc, hash_args=True):
            (self.func, self.args, self.exception) = (func, args, exc)
            self.hash_args = hash_args

        def __str__(self):
            return 'Error on {!r};\nargs: {!r},\nexception: {!r}'.format(self.func, self.args, self.exception)

        def __eq__(self, another):
            if isinstance(another, State.Error):
                return self.func == another.func \
                    and (not self.hash_args or self.args == another.args) \
                    and type(self.exception) == type(another.exception) #\
                    # and self.exception.args == another.exception.args
            return NotImplemented

    @pretty_printed(lambda k,v: k in 'iss service type msg to'.split())
    class Message:

        CHECK_SIGNAL = '__check'

        iss = service = type = msg = to = None

        DESC_REGEXP = re.compile(r'^(?P<service>\S+)\s((?P<to>\S+)\s)?(?P<type>.*)$')

        def __init__(self, iss, service, type, msg, to=None, ts=None, version=None):
            (self.iss, self.service, self.type, self.msg, self.to, self.time, self.version) = (iss, service, type, msg, to, ts or time.time(), version)

        def _asdict(self):
            return dict(iss=self.iss, service=self.service, type=self.type, content=self.msg, to=self.to, time=self.time, version=self.version)

        def write_to(self, filepath):
            desc = ' '.join((self.service, self.to, self.type) if self.to else (self.service, self.type))
            with open(filepath, 'w') as f:
                f.write(self.service)
                f.write(' ')
                if self.to:
                    f.write(self.to)
                    f.write(' ')
                f.write(self.type)
                f.write('\n')
                f.write(self.msg)

    messages_thread = None
    message_sender_thread = None
    passengers_counter_thread = None

    box_version = None

    msg_daemon_tag = '@msg_reader:'
    msg_sender_daemon_tag = '@messages_sender:'

    DATA_FILENAME_RE = re.compile(r'(?P<name>\w+)(\.(?P<mode>.*))?\.(?P<mapper>\w+)$')
    OBD_OUTPUT_LINE_REGEXP = re.compile(r'(?P<pid>.*)\: (?P<value>.*)')
    PASSENGER_COUNTER_OUTPUT_REGEXP = re.compile(r'IN\:(?P<in>\d+) OUT:(?P<out>\d+)')

    SSH_PIDFILE_REMOTE_PORT_REGEXP = re.compile('^'+Config.file.SSH_PIDFILE_TEMPLATE.replace('/', r'\/').replace('.', r'\.').format(remote_port=r'(?P<port>\d+)'))

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.last = self.Last()
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG if cfg.VERBOSE else logging.ERROR)
        self._messages = C.deque(maxlen=cfg.MAX_MESSAGES)
        self.SSH_PIDFILE_REMOTE_PORT_REGEXP = re.compile('^'+cfg.file.SSH_PIDFILE_TEMPLATE.replace('/', r'\/').replace('.', r'\.').format(remote_port=r'(?P<port>\d+)'))
        self.logger.debug('%s', self.SSH_PIDFILE_REMOTE_PORT_REGEXP)
        self.box_version = self._get_box_version()

    def __str__(self):
        return '<State, host: {}, last: {}>'.format(host, last)

    def fail_logged(on_fail_returns=None, on_fail_factory=None, 
        hash_args=True, log=True, msg_type='error', msg_to='RisAbd',
        silent_when=(requests.ConnectTimeout, requests.ConnectionError, requests.ReadTimeout),  # exception_types
        ):
        def wow(f):
            f.__prev_error = None
            def wrapper(self, *args, **kwargs):
                try:
                    r = f(self, *args, **kwargs)
                except Exception as e:

                    self.logger.warning(f.__name__, exc_info=e)

                    error = State.Error(f, (args, kwargs), e, hash_args=hash_args)

                    if not isinstance(e, silent_when) and log and f.__prev_error != error:
                        self.add_message(State.Message(
                            iss='box/'+self.cfg.DEVICE_ID, service=self.cfg.SERVICE_NAME,
                            type=msg_type, msg=traceback.format_exc(), to=msg_to,
                            version=self.box_version))
                    
                    f.__prev_error = error

                    if on_fail_factory:
                        return on_fail_factory()
                    else:
                        return on_fail_returns
                else:
                    if f.__prev_error:
                        f.__prev_error = None
                    return r
            return wrapper
        return wow

    @fail_logged(None)
    def _get_box_version(self):
        with open(self.cfg.file.BOX_VERSION_FILE, 'r') as f:
            return f.read().strip()

    def _port_from_filename(self, fp):
        self.logger.debug(fp)
        return int(self.SSH_PIDFILE_REMOTE_PORT_REGEXP.match(fp).groupdict()['port'])

    def _prep_ssh_info(self):
        pidfiles_list = glob.glob(self.cfg.file.SSH_PIDFILE_TEMPLATE.format(remote_port='*'))
        ports = list(map(self._port_from_filename, pidfiles_list))


        self.logger.debug('%s', pidfiles_list)
        self.logger.debug('%s', ports)

        # assert len(ports) < 2

        for p in ports:
            pid = self.ssh_pid(p)

            with open(self.cfg.file.SSH_INFO_OUTPUT, 'w') as f:
                f.write(json.dumps(dict(pid=pid, remote_port=p)))

    @fail_logged()
    def _handle_setting_ssh(self, ssh):

        if isinstance(ssh, dict):
            pass
        elif isinstance(ssh, (int, str)):
            ssh = dict(remote_port=int(ssh))
        elif ssh is None:
            self.logger.debug('kill ssh requested')
            killed = self.kill_ssh()
            self.logger.debug('killed: %s', killed)
            return 
        else:
            self.logger.warning('unknown ssh setting: %s', str(ssh))
            return

        remote_port = ssh['remote_port']
        self.logger.debug('remote_port %s requested', remote_port)

        p = self.ssh_pid(remote_port)
        if p:
            # already sshed
            self.logger.debug('already open, remote_port: %s, pid: %s', remote_port, p)
            pass
        else:
            ps = self.ssh_pid()
            self.logger.debug('already opened ssh pids: %s', ps)
            if ps:
                killed = self.kill_ssh()
                self.logger.debug('killed: %s', killed)
            self.start_ssh(**ssh) 
            self.logger.debug('started ssh: %s', ssh)

    @fail_logged()
    def ssh_pid(self, port=None):

        if port is None:
            # return array of all existing pids
            pidfiles_list = glob.glob(self.cfg.file.SSH_PIDFILE_TEMPLATE.format(remote_port='*'))
            ports = map(self._port_from_filename, pidfiles_list)
            return list(filter(bool, map(self.ssh_pid, ports)))

        try:
            with open(self.cfg.file.SSH_PIDFILE_TEMPLATE.format(remote_port=port), 'r') as f:
                return int(f.read())
        except FileNotFoundError as e:
            self.logger.info('ssh pidfile not exists: %s', str(e))
        except ValueError as e:
            self.logger.warning('ssh pidfile content corrupted: %s', str(e))
        return None

    @fail_logged()
    def start_ssh(self, remote_port, host=None, port=None, _additional_cmd_args=None, _additional_envvars=None, **kwargs):

        host = host or self.cfg.DEFAULT_SSH_HOST
        port = port or self.cfg.DEFAULT_SSH_PORT
        additional_cmd_args = _additional_cmd_args or list()
        additional_envvars = _additional_envvars or dict()

        env = os.environ.copy()
        env['AUTOSSH_PIDFILE'] = self.cfg.file.SSH_PIDFILE_TEMPLATE.format(remote_port=remote_port)
        env.update(additional_envvars)

        # autossh -M0 -f -T -N 
        cmd_list = [
            self.cfg.SSH_EXECUTABLE, '-M0', '-f', '-T', '-N', 
            '-R', '0.0.0.0:{}:localhost:22'.format(remote_port),
            host,
            '-p', port,
        ]
        cmd_list.extend(
            a.format(self=self, remote_port=remote_port, host=host, port=port) 
            for a in additional_cmd_args
        )

        p = subprocess.Popen(list(map(str, cmd_list)), env=env)
        p.communicate()

        # check kek
        # assert p.returncode == 0
        
        pid = self.ssh_pid(remote_port)
        with open(self.cfg.file.SSH_INFO_OUTPUT, 'w') as f:
            f.write(json.dumps(dict(pid=pid, remote_port=remote_port, host=host, port=port, additional_cmd_args=additional_cmd_args, additional_envvars=additional_envvars, kwargs=kwargs)))

        return pid

    @fail_logged(False)
    def kill_ssh(self, port=None):

        if port is None:

            pidfiles_list = glob.glob(self.cfg.file.SSH_PIDFILE_TEMPLATE.format(remote_port='*'))
            ports = map(self._port_from_filename, pidfiles_list)

            return all(map(self.kill_ssh, ports))

        pid = self.ssh_pid(port)

        if pid:
            rc = os.system('kill {}'.format(pid))
            # assert rc == 0
            # ssh killed
            try:
                os.remove(self.cfg.file.SSH_INFO_OUTPUT)
            except FileNotFoundError:
                self.logger.warning('killed pid %s ssh, but ssh_info was not there', pid)
            return True
        else:
            # nothing to kill
            return False

    def _send_message(self, message: Message):

        if message is not None:
            self._messages.append(message)

        now = time.time()
        if self.host is None or self.last.ping is None or now - self.last.ping > 10:
            self.logger.info('%s can not send. waiting better conditions...', self.msg_sender_daemon_tag)
            return
        
        url = self.host+self.cfg.api.MESSAGE
        while self._messages:
            msg = self._messages.popleft()
            self.logger.info('%s sending message (left: %d): %s...', self.msg_sender_daemon_tag, len(self._messages), msg)
            try:
                r = requests.post(url, json=msg._asdict(), timeout=self.cfg.interval.DEFAULT_TIMEOUT)
            except Exception as e:
                self._messages.appendleft(msg)
                self.logger.info(self.msg_sender_daemon_tag, exc_info=e)
                break
            else:
                if r.status_code != requests.codes.ok:
                    self.logger.info('%s failed with status_code %d. %s', self.msg_sender_daemon_tag, r.status_code, r.text)
                    continue
                else:
                    self.logger.info('%s ok.', self.msg_sender_daemon_tag)
        else:
            self.logger.info('%s no messages to send', self.msg_sender_daemon_tag)

    def _messages_reader_daemon(self):

        while True:
            with open(self.cfg.file.MESSAGES_PIPE, 'r') as f:
                line = f.readline().strip()
                self.logger.info('%s msg got, first: line: %r', self.msg_daemon_tag, line)

                res = State.Message.DESC_REGEXP.match(line)
                if res:
                    d = res.groupdict()
                    msg = State.Message(iss='box/'+self.cfg.DEVICE_ID, msg=f.read().rstrip(), version=self.box_version, **d)
                    # self._send_message(msg)
                    self._messages.append(msg)
                else:
                   self.logger.warning('%s wrong format message, passing...\n%s\n%s', self.msg_daemon_tag, line, f.read())

    def _message_sender_daemon(self):
        while True:
            if self._messages:
                self._send_message(None)
            time.sleep(self.cfg.interval.MESSAGE_SENDER_SLEEP)

    def start_message_daemon(self):

        thm = self.messages_thread = threading.Thread(target=self._messages_reader_daemon)
        thm.daemon = True
        thm.start()

        ths = self.message_sender_thread = threading.Thread(target=self._message_sender_daemon)
        ths.daemon = True
        ths.start()

        return self

    def start_passengers_counter_daemon(self):

        if self.cfg.PASS_COUNTER:
            th = self.passengers_counter_thread = threading.Thread(target=self.passenger_counter_daemon)
            th.daemon = True
            th.start()
        else:
            self.logger.warning('start_passengers_counter_daemon called, but config is False')

        return self

    def passenger_counter_daemon(self):
        while True:
            now = time.time()
            self._dump_passengers_counter_data(now)
            time.sleep(self.cfg.interval.PASSENGER_COUNTER_READ)

    def _dump_passengers_counter_data(self, now):
        cfg = self.cfg 
        
        self.logger.info('dumping passengers...')

        pass_counter = self._get_passengers(cfg)
        if pass_counter is not None:
            # in_, out = pass_counter
            # data['passengers_in'] = in_
            # data['passengers_out'] = out
            if os.path.exists(cfg.file.PASS_COUNTER_OUTPUT):
                self.logger.info('previous passenger data still not sent, waiting...')
                self._recover_passengers(pass_counter)
            else:
                self.check_counter_reset(self.cfg, now)
                data = dict(zip(('passengers_in', 'passengers_out'), pass_counter))
                with open(cfg.file.PASS_COUNTER_OUTPUT, 'w') as f:
                    json.dump(data, f)
                self.logger.info('dumped values: %r', data)

        self.last.pass_counter = pass_counter
        self.last.pass_counter_read = now

    def add_message(self, msg: Message):
        self.logger.info('added message')
        # msg.write_to(self.cfg.file.MESSAGES_PIPE)
        self._messages.append(msg)
        return self

    @fail_logged(on_fail_factory=lambda: Config.default.DEFAULT_HOST)
    def _get_host(state, cfg: Config):
        if cfg.HOST_HOST is None:
            return cfg.DEFAULT_HOST
        j = requests.get(cfg.HOST_HOST, timeout=cfg.interval.WAIT_HOST_HOST).json()
        return j.get(cfg.REGION) or j[cfg.DEFAULT_REGION]

    @fail_logged(Config.DEFAULT_TOKEN)
    def _get_token(state, cfg: Config, host, prev=None):
        j = requests.get(host+cfg.api.LOGIN, json=dict(id=cfg.DEVICE_ID), timeout=cfg.interval.WAIT_TOKEN).json()
        return j['token']

    @fail_logged(Config.DEFAULT_PING, hash_args=False)
    def _ping(self, cfg: Config, host, token, data):
        try:
            json_data = {}
            for k in ('obd', 'ssh_info', ):
                if k in data:
                    json_data[k] = data.pop(k)
            r = requests.post(
                host+cfg.api.PING, 
                params=data, 
                json=json_data,
                headers=dict(Authorization='Bearer '+token),
                timeout=cfg.interval.WAIT_PING
            )
            j = r.json()
        except (requests.ConnectTimeout, requests.ConnectionError, requests.ReadTimeout) as e:
            return self.cfg.DEFAULT_PING
        try:
            return j['data']
        except KeyError as e:
            raise Exception('error: {}\ndata: {}\nresp: {}'.format(e, data, j))

    @fail_logged(None)
    def _reset_passenger_counter(self, cfg: Config):
        for b in self._iter_pass_counter_bauds:
            for i in self._iter_pass_counter_eyes:
                os.system('{cfg.PASSENGER_COUNTER_CMD} -b {b} -i {i} -r {cfg.file.PASS_COUNTER_DEVICE}'.format(b=b, i=i, cfg=self.cfg))
        # raise NotImplementedError('reset passenger counter!')

    @fail_logged(on_fail_factory=lambda: dict(lat=0.0, lon=0.0))
    def _get_coords(state, cfg):
        with open(cfg.file.LATLNG_INPUT, 'r') as f:
            return json.load(f)

    def _json_data_mapper(self, name, value, data, modes=None, **kwargs):
        try:
            v = json.loads(value)
        except ValueError as e:
            self.logger.warning('json value failed, value: %r', value, exc_info=e)
            return

        if not modes:
            data[name] = v
        elif '_' in modes:
            if not isinstance(v, dict):
                self.logger.error('json mode set as _, but value is not object: %r', v)
            else:
                data.update(v)

    def _obd_data_mapper(self, name, value, data, modes=None, **kwargs):

        out = {}
        for line in value.split('\n'):
            res = self.OBD_OUTPUT_LINE_REGEXP.match(line)
            if res:
                d = res.groupdict()
                out[d['pid']] = d['value']

        if out:
            data[name] = out

    def _parse_data_modes(self, modes_raw):
        modes = []
        for m in (modes_raw or '').split(','):
            m = m.strip()
            if m:
                modes.append(m)
        return modes

    def _apply_general_modes(self, modes=None, file_path=None, **context):
        if modes and file_path and 'once' in modes:
            self.logger.info('%r mode on %r, deleting...', 'once', file_path)
            os.remove(file_path)

    @fail_logged(on_fail_factory=lambda: dict(lat=0.0, lon=0.0))
    def _get_data(self, now):

        cfg = self.cfg

        mappers = {
            'json': self._json_data_mapper,
            'obd': self._obd_data_mapper,
        }

        items_to_process = []

        for i in os.listdir(cfg.file.ADDITIONAL_DATA_DIR):
            res = self.DATA_FILENAME_RE.match(i)
            if res:
                gd = res.groupdict()
                items_to_process.append(
                    (
                        gd['mapper'], 
                        self._parse_data_modes(gd['mode']), 
                        gd['name'], 
                        i, 
                        os.path.join(cfg.file.ADDITIONAL_DATA_DIR, i)
                    )
                )
            else:
                self.logger.warning('unknown file: %r', i)

        data_priority = cfg.DATA_PRIORITY

        items_to_process = sorted(
            items_to_process, 
            key=lambda i: data_priority.index(i[2]) if i[2] in data_priority else len(data_priority),
            reverse=True
        )

        data = dict()

        for mapper_name, modes, name, file_name, file_path in items_to_process:
            if mapper_name in mappers:
                try:
                    with open(file_path, 'r') as f:
                        value = f.read()
                except FileNotFoundError as e:
                    self.logger.warning('could not read file: %r\n\t(hint: seems to be link to non-existing file or permissions issue)', file_path)
                    continue

                mapper = mappers[mapper_name]

                try:
                    mapper(name, value, data, modes=modes, file_name=file_name, file_path=file_path)
                except Exception as e:
                    self.logger.error('mapper %r failed mapping', mapper_name, exc_info=e)
                else:
                    self._apply_general_modes(
                        file_path=file_path, 
                        file_name=file_name, 
                        mapper_name=mapper_name, 
                        mapper=mapper,
                        modes=modes,
                        name=name,
                        value=value
                    )
            else:
                self.logger.warning('unknown file: %r', file_name)

        # data = self._get_coords(cfg)
        # data['id'] = self.cfg.DEVICE_ID

        # if cfg.OBD:
        #     obd = self._get_obd(cfg)
        #     if obd:
        #         data['obd'] = obd
        #         self.last.obd = obd

        # if cfg.PASS_COUNTER and (self.last.pass_counter_read is None or now-self.last.pass_counter_read > cfg.interval.PASSENGER_COUNTER_READ):
        #     pass_counter = self._get_passengers(cfg)
        #     if pass_counter is not None:
        #         in_, out = pass_counter
        #         data['passengers_in'] = in_
        #         data['passengers_out'] = out
        #     self.last.pass_counter = pass_counter
        #     self.last.pass_counter_read = now
        #     self.check_counter_reset(cfg, now)

        return data

    @fail_logged(None, log=False)
    def _get_obd(state, cfg):
        out = {}
        with open(cfg.file.OBD_INPUT, 'r') as f:
            for line in f:
                res = state.OBD_OUTPUT_LINE_REGEXP.match(line)
                if res:
                    d = res.groupdict()
                    out[d['pid']] = d['value']
        return out

    @fail_logged(None, log=False)
    def _get_passengers(self, cfg):
        self.logger.info('pass counter')

        raw_values = [0, 0]
        # last_counters_with_data = []

        for b in self._iter_pass_counter_bauds:
            for i in self._iter_pass_counter_eyes:
                p = subprocess.Popen(
                    [self.cfg.PASSENGER_COUNTER_CMD, '-d', '-b', str(b), '-i', str(i), self.cfg.file.PASS_COUNTER_DEVICE], 
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
                stdout, stderr = p.communicate()
                if p.returncode == 0:
                    res = self.PASSENGER_COUNTER_OUTPUT_REGEXP.match(stdout.decode())
                    # in_, out = res.groups()
                    raw_values = list(map(sum, zip(map(int, res.groups()), raw_values)))
                    # last_counters_with_data.append((b, i))

        # if last_counters_with_data == self.last._succeeded_counters:
        #     self._iter_pass_counter_bauds = tuple(map())

        # if self.last._succeeded_counters is None:
        #     self.last._succeeded_counters = last_counters_with_data

        self.logger.info('\t%s -> %s', self.last._raw_counter_values, raw_values)

        if self.last._raw_counter_values is None:
            self.last._raw_counter_values = (0, 0)

        r = tuple(IT.starmap(operator.sub, zip(raw_values, self.last._raw_counter_values)))

        self.last._raw_counter_values = raw_values
        return r

        #raise NotImplementedError('passenger counter extraction')

    @fail_logged(None)
    def _recover_passengers(self, r):
        new_values = tuple(IT.starmap(operator.sub, zip(self.last._raw_counter_values, r)))
        self.logger.debug('recovering passenger counter values: %r - %r = %r', self.last._raw_counter_values, r, new_values)
        self.last._raw_counter_values = new_values

    def _dump_settings(state, cfg):
        fn = cfg.file.BOX_CONFIG_OUTPUT
        tmpfn = fn+'.tmp'
        with open(tmpfn, 'w') as f:
            f.write(json.dumps(state.last.settings, ensure_ascii=False, indent=2))
        os.rename(tmpfn, fn)

    @fail_logged()
    def _handle_setting_obd(self, pids):
        fn = self.cfg.file.OBD_INSTRUCTIONS_OUTPUT
        tmpfn = fn+'.tmp'
        with open(tmpfn, 'w') as f:
            for p in pids:
                print(p, file=f)
            # f.write('\n'.join(pids))
        os.rename(tmpfn, fn)

    @fail_logged()
    def _handle_settings(self, settings):

        # obd.pids
        if self.cfg.OBD:
            pids = settings.get('instructions', {}).get('obd_pids', [])
            if pids:
                self._handle_setting_obd(pids)

        if 'ssh' in settings:
            ssh = settings.get('ssh')
            self._handle_setting_ssh(ssh)

    def _set_led_state(self, new_state: Led):
        if new_state == None:
            # init led
            os.system('echo timer > /sys/class/leds/lte/trigger')
        elif new_state == self.Led.NO_DEVICE:
            # no device in ifconfig
            os.system('echo 0 > /sys/class/leds/lte/delay_off')
            os.system('echo 1 > /sys/class/leds/lte/delay_on')
        elif new_state == self.Led.NO_PING:
            # no ping to servers
            os.system('echo 500 > /sys/class/leds/lte/delay_off')
            os.system('echo 500 > /sys/class/leds/lte/delay_on')
        elif new_state == self.Led.OK:
            # all ok
            os.system('echo 2000 > /sys/class/leds/lte/delay_off')
            os.system('echo 200 > /sys/class/leds/lte/delay_on')

        self.logger.info('led state change: %s -> %s', self.led, new_state)

        self.led = new_state


    def prep(self):

        self.logger.info('prep')

        # make working dirs
        for d, mode in self.cfg.file.MAKE_DIRS:
            self.logger.info('creating directory: %s, mode: %d', d, mode)
            if os.path.exists(d):
                self.logger.warning('\t%s exists, removing...', d)
                shutil.rmtree(d)
            os.makedirs(d)
            os.chmod(d, mode)

        # make links
        for src, dst in self.cfg.file.MAKE_LINKS:
            self.logger.info('creating link: %s -> %s', src, dst)
            try:
                os.symlink(src, dst)
            except FileExistsError as e:
                self.logger.warning('link exists')

        # messages pipe preparation
        messages_pipe = self.cfg.file.MESSAGES_PIPE
        if os.path.exists(messages_pipe):
            self.logger.info('%s exists, removing...', messages_pipe)
            os.remove(messages_pipe)
        os.mkfifo(messages_pipe)
        os.chmod(messages_pipe, 0o777)

        # dumb 'settings' file
        with open(self.cfg.file.BOX_CONFIG_OUTPUT, 'w') as f:
            f.write(json.dumps(self.cfg.DEFAULT_PING))

        if self.cfg.LED:
            self._set_led_state(None)
            if self._check_modem():
                self._set_led_state(self.Led.NO_DEVICE)
            else:
                self._set_led_state(self.Led.NO_PING)

        if self.cfg.PASS_COUNTER:
            self._reset_passenger_counter(self.cfg)

        self._prep_ssh_info()

    def _check_modem(self):
        return os.system('ifconfig {}'.format(self.cfg.MODEM_DEVICE_INTERFACE)) == 0

    def check_host(self, cfg: Config, now: float):
        self.logger.info('checking host...')
        if not self.last.host_request or (now - self.last.host_request) > cfg.interval.HOST_RENEW:
            self.logger.info('updating host...')
            self.host = self._get_host(cfg)
            self.last.host_request = now
            with open(cfg.file.HOST_OUTPUT, 'w') as f:
                f.write(self.host)
        return self

    def check_token(self, cfg: Config, now: float):
        self.logger.info('checking token...')
        if not self.last.token_update or (now - self.last.token_update) > cfg.interval.TOKEN_UPDATE:
            
            self.logger.info('updating token...')
            self.token = self._get_token(cfg, host=self.host, prev=self.token)
            self.last.token_update = now
            with open(cfg.file.TOKEN_OUTPUT, 'w') as f:
                f.write(self.token)

        return self

    def check_counter_reset(self, cfg: Config, now: float):
        self.logger.info('counter reset')

        if not cfg.PASS_COUNTER:
            return self

        if self.last.passenger_counter_reset is None:
            self.last.passenger_counter_reset = now

        if self.last.passenger_counter_reset is None or (now - self.last.passenger_counter_reset) > cfg.interval.PASSENGER_COUNTER_RESET:
            self._reset_passenger_counter(cfg)
            self.last._raw_counter_values = None
            self.last.passenger_counter_reset = now

        return self

    def ping(self, cfg: Config, now: float):

        self.logger.info('checking ping...')

        if cfg.interval.PING and (now - self.last.ping) < cfg.interval.PING:
            return self

        data = self._get_data(now)
        data['id'] = self.cfg.DEVICE_ID

        self.logger.info('pinging %r %r', self.host, data)

        self.last.settings = self._ping(cfg, self.host, self.token, data=data)
        
        self._dump_settings(cfg)
        self._handle_settings(self.last.settings)

        self.last.ping = now
        self.last.data = data

        if self.cfg.LED:
            if self.last.settings is self.cfg.DEFAULT_PING:
                if self.led != self.Led.NO_PING:
                    self._set_led_state(self.Led.NO_PING)
            elif self.led != self.Led.OK:
                self._set_led_state(self.Led.OK)

        return self

    def check_modem(self, cfg, now):
        if self.cfg.LED:
            if self.led == self.Led.NO_DEVICE:
                if self._check_modem():
                    self._set_led_state(self.Led.NO_PING)
            elif self.led == self.Led.OK and now-self.last.ping >= self.cfg.interval.LED_NORMAL_PING:
                self._set_led_state(self.Led.NO_PING)


def main(cfg=Config()):

    state = State(cfg)
    state.prep()

    state.start_message_daemon()
    state.start_passengers_counter_daemon()

    while True:

        now = time.time()

        state.check_host(cfg, now)
        state.check_token(cfg, now)
        state.ping(cfg, now) 
        state.check_modem(cfg, now)

        # if cfg.VERBOSE: print(state)

        time.sleep(cfg.interval.SLEEP)



if __name__ == '__main__':
    main()

