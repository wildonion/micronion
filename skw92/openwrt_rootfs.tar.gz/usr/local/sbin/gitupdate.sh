
SETTINGS_PATH='/settings.ini'

# warning: destination must be writable
DEFAULT_LOCAL_REPO='/tmp/boxupdate'
DEFAULT_REMOTE_REPO='git@git.avisa.kg:RisAbd/box-updates.git'


fromsettings() {

    key="$1"
    default="$2"
    if [ ! $key ]; then 
        echo "first argument required"
        return 1
    fi

    settings_path="$3"
    if [ ! $settings_path ]; then
        settings_path="$SETTINGS_PATH"
    fi

    if [ ! -e "$settings_path" ]; then
        if [ $default ]; then
            export "$key"="$default"
            return 0
        fi
        echo "$settings_path not exists"
        return 1
    fi

    value="$(cat $settings_path | grep -oP "^$key\s+=\s+(.*)" | python3 -c 'import sys; print(sys.stdin.read().split("=")[-1].strip())')"
    if [ ! "$value" ] && [ ! $default ]; then
        echo 'No value found and default is not set'
        return 1
    fi
    if [ ! $value ]; then 
        value="$default"
    fi

    export "$key"="$value"
}


fromsettings REMOTE_REPO "$DEFAULT_REMOTE_REPO"
fromsettings LOCAL_REPO "$DEFAULT_LOCAL_REPO"


echo "Remote: $REMOTE_REPO"
echo "Local: $LOCAL_REPO"


echo 'cloning remote repo...'
if ! git clone "$REMOTE_REPO" "$LOCAL_REPO"; then 
    echo 'error: most likely local repo already exists, trying cd into destination...'
    if ! cd "$LOCAL_REPO"; then
        echo 'error: cd failed. unknown error. exiting...'
        exit 
    else
        echo 'pulling existing repo...'
        if ! git pull; then
            echo 'error: pull failed. unknown error. exiting...'
            exit
        else:
            echo 'pull succeeded'
        fi
    fi
else
    echo 'cloning succeeded, cd into destination...'
    cd "$LOCAL_REPO"
fi

# you are in $LOCAL_REPO

echo 'starting apply.sh...'
if ! bash ./apply.sh; then
    echo 'error: apply.sh failed'
    exit
fi

