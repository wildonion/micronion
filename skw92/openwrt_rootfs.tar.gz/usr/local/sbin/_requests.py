
### BEGIN REQUESTS MODULE REPLACEMENT ###

try:
    import kek, requests
except ImportError:


    def requests():
        pass

    class RequestException(IOError):
        pass
    class ConnectionError(RequestException):
        pass
    class ConnectTimeout(ConnectionError):
        pass
    class ReadTimeout(RequestException):
        pass

    requests.RequestException = RequestException
    requests.ConnectionError = ConnectionError
    requests.ConnectTimeout = ConnectTimeout
    requests.ReadTimeout = ReadTimeout

    from urllib.request import urlopen, Request, HTTPError, URLError
    from urllib.parse import urlencode
    from http.client import HTTPResponse
    import json as jsonm
    import socket 

    class Request(Request):
        pass

    class BaseResponse(HTTPResponse):
        def __init__(self, r):
            self._r = r
            self._content = r.read()
        def __getattr__(self, attr):
            return getattr(self._r, attr)
        @property
        def status_code(self):
            return self.code
        @property
        def content(self):
            if self._content is None:
                self._content = self.read()
            return self._content
        @property
        def text(self):
            return self.content.decode()
        def json(self) -> dict:
            return jsonm.loads(self.content)

        
    class Response(BaseResponse):
        pass

    class ErrorResponse(BaseResponse):
        def __init__(self, r):
            self._r = r
            self._content = r.fp.read()
        

    requests.Request = Request
    requests.Response = Response

    class codes:
        ok = 200

    requests.codes = codes  # type('codes', (), dict(ok=200))

    def _request(method, url, data=None, params=None, json=None, headers=None, timeout=None):
        if not headers:
            headers = dict()
        if params:
            url = '{}?{}'.format(url, urlencode(params))
        if json:
            assert not data, 'Can not pass data and json'
            if 'Content-Type' not in headers:
                headers['Content-Type'] = 'application/json'
            data = jsonm.dumps(json).encode()
        if isinstance(data, dict):
            if 'Content-Type' not in headers:
                headers['Content-Type'] = 'application/x-www-form-urlencoded'
            data = urlencode(data).encode()
        r = Request(url, method=method.upper(), data=data, headers=headers)
        try:
            with urlopen(r, **(dict(timeout=timeout) if timeout is not None else {})) as resp:
                rsp = Response(resp)
                # load body of response
                _ = rsp.content
            return rsp
        except HTTPError as e:
            return Response(e)
        except URLError as e:
            # import pdb; pdb.set_trace()
            if e.args and hasattr(e.args[0], 'errno') and e.args[0].errno == 111:
                raise ConnectionError(e)
            raise e
        except socket.timeout as e:
            raise ReadTimeout(e)

    from functools import partial

    requests.request = _request
    requests.post = partial(requests.request, 'post')
    requests.get = partial(requests.request, 'get')

    # v todo: .ConnectTimeout, .ConnectionError, ReadTimeout
    # v todo: .codes.ok == 200
    # v todo: $resp.status_code: int
    # v todo: $resp.text
    # v todo: $resp.json() -> Any  # (JSON)
    # todo: .post(str, json=dict, timeout=float, params=dict, headers=dict,) -> $resp
    # todo: .get(str, json=dict, timeout=float) -> $resp

### END REQUESTS MODULE REPLACEMENT ###
