#!/bin/bash

# $1 - speed measure interval in seconds, $2 - get wifi statistics interval in minutes

SLP=$1
WIFI_INT=$(($2*60/$1))
WIFI_CNT=0

if ifconfig | grep -q "wwan0"
then
	DEVICE=wwan0
elif ifconfig | grep -q "usb0"
then
	DEVICE=usb0
else 
	exit 0
fi

OLD_INSPEED=0
OLD_OUTSPEED=0

while true; do

LINE=`grep $DEVICE /proc/net/dev | sed s/.*://`;
RECEIVED1=`echo $LINE | awk '{print $1}'`
TRANSMITTED1=`echo $LINE | awk '{print $9}'`

if [ "$WIFI_CNT" = "0" ]; then
		RECEIVED0=$RECEIVED1
		TRANSMITTED0=$TRANSMITTED1
fi

sleep $SLP

LINE=`grep $DEVICE /proc/net/dev | sed s/.*://`;
RECEIVED2=`echo $LINE | awk '{print $1}'`
TRANSMITTED2=`echo $LINE | awk '{print $9}'`
INSPEED=$((($RECEIVED2-$RECEIVED1)/$SLP))
OUTSPEED=$((($TRANSMITTED2-$TRANSMITTED1)/$SLP))

if [ "$INSPEED" -gt "$OLD_INSPEED" ]
then
	OLD_INSPEED=$INSPEED
fi
if [ "$OUTSPEED" -gt "$OLD_OUTSPEED" ]
then
	OLD_OUTSPEED=$OUTSPEED
fi

if [ "$WIFI_CNT" -ge "$WIFI_INT" ]
then
	AV_INSPEED=$((($RECEIVED2-$RECEIVED0)/($WIFI_CNT*$SLP)))
	AV_OUTSPEED=$((($TRANSMITTED2-$TRANSMITTED0)/($WIFI_CNT*$SLP)))
	echo "RPeak: $(($OLD_INSPEED/128)) kbit/s
TPeak: $(($OLD_OUTSPEED/128)) kbit/s
RAvr/RPeak: $(($AV_INSPEED*100/$OLD_INSPEED)) %
TAvr/TPeak: $(($AV_OUTSPEED*100/$OLD_OUTSPEED)) %
Total Received: $RECEIVED2 bytes
Total Transmitted: $TRANSMITTED2 bytes" > /tmp/speed.stat

	/usr/local/sbin/wifistat.sh
	WIFI_CNT=0
else
	WIFI_CNT=$(($WIFI_CNT+1))
fi 

done;
