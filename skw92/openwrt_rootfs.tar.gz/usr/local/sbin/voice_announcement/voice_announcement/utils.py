import os
import zipfile
import traceback
from collections import deque
import time
from config import BaseConfig
import sqlite3
from math import radians, cos, sin, asin, sqrt
import polyline
import hashlib
from logging import getLogger

logger = getLogger()


audio_queue = deque()
jobs = deque()
prev_exception = None


def extract_and_delete(zipped_path: str, extract_location: str):
    if not os.path.exists(zipped_path):
        raise FileNotFoundError(zipped_path)
    with zipfile.ZipFile(zipped_path, 'r') as zipped:
        zipped.extractall(extract_location)
        zipped.close()
    os.remove(zipped_path)


def read_file(file_path: str) -> str:
    if not os.path.exists(file_path):
        raise FileNotFoundError(file_path)
    with open(file_path, 'r') as f:
        return f.read()


def manage_exceptions(*args, file_path: str):
    logger.exception(args)
    global prev_exception
    if args[1] == prev_exception:
        return
    else:
        prev_exception = args[1]
    with open(file_path, 'w') as f:
        for line in args:
            f.write(line)


def worker():
    while True:
        try:
            if not jobs:
                continue
            job, args, kwargs = jobs.popleft()
            job(*args, **kwargs)
        except BoxException as be:
            manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'warning'), str(be),
                              file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
        except Exception as e:
            ex = traceback.format_exc()
            manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'error'), str(e), ex,
                              file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
        finally:
            time.sleep(1)


import requests
from .voice import BoxException


def get_current_db_version(url: str, token: str):
    try:
        r = requests.get(url, headers=dict(Authorization=token), timeout=2)
    except requests.Timeout:
        return None
    if r.status_code != 200:
        msg = '{} - {} - {}'.format(url, r.status_code, r.text)
        raise BoxException(msg)
    return r.json()['city']['db_version']


def post_request(url, token, data):
    try:
        r = requests.post(url, headers=dict(Authorization=token), timeout=2, json=data)
    except requests.Timeout:
        pass
    else:
        if r.status_code != 200:
            msg = '{} - {} - {}'.format(url, r.status_code, r.text)
            raise BoxException(msg)


def download(url: str, filename: str, token: str=None, md5=None):
    logger.debug(url)
    headers = dict()
    if token:
        headers['Authorization'] = token
    try:
        with requests.get(url, headers=headers, timeout=180, stream=True) as r:
            if r.status_code != 200:
                if url.endswith('.wav'):
                    return
                msg = '{} - {} - {}'.format(url, r.status_code, r.text)
                raise BoxException(msg)
            with open(filename, 'wb') as f:
                for chunk in r.iter_content(chunk_size=1024):
                    if chunk:  # filter out keep-alive new chunks
                        f.write(chunk)
                        # f.flush() commented by recommendation from J.F.Sebastian
            try:
                file_md5 = get_md5(filename)
            except OSError:
                os.remove(filename)
                return
            if md5:
                if file_md5 != md5:
                    os.remove(filename)
    except requests.Timeout:
        return


def polyline_to_linestring(polyline_raw: str) -> list:
    linestring = polyline.decode(polyline_raw)
    return linestring


def latlng_value_index_in_array(array: (list, tuple), value: (list, tuple)) -> int:
    t_lat, t_lng = value
    for i, coord in enumerate(array):
        lat, lng = coord
        if round(t_lat, 3) == round(lat, 3) and round(t_lng, 3) == round(lng, 3):
            return i


def get_distance(shape, shape2) -> float:
    return round(shape.distance(shape2) * 100, 3)


AVG_EARTH_RADIUS = 6371  # in km


def haversine(point1,
              point2,
              meters: bool=True) -> float:
    """ Calculate the great-circle distance between two points on the Earth surface.
    :input: two 2-tuples, containing the latitude and longitude of each point
    in decimal degrees.
    Example: haversine((45.7597, 4.8422), (48.8567, 2.3508))
    :output: Returns the distance between the two points.
    The default unit is kilometers. Miles can be returned
    if the ``miles`` parameter is set to True.
    """
    # unpack latitude/longitude
    lat1, lng1 = point1
    lat2, lng2 = point2

    # convert all latitudes/longitudes from decimal degrees to radians
    lat1, lng1, lat2, lng2 = map(radians, (lat1, lng1, lat2, lng2))

    # calculate haversine
    lat = lat2 - lat1
    lng = lng2 - lng1
    d = sin(lat * 0.5) ** 2 + cos(lat1) * cos(lat2) * sin(lng * 0.5) ** 2
    h = 2 * AVG_EARTH_RADIUS * asin(sqrt(d))
    if meters:
        return h * 1000 # in meters
    else:
        return h  # in kilometers


def get_current_direction(new, old, dirs):
    dir1, dir2 = dirs
    old2 = dir1.line.project(old)
    new2 = dir1.line.project(new)

    if (new2 - old2) > 0:
        return dir1
    return dir2


def find_break_point(rows) -> int:
    return int(len(rows) / 2)


def db_break_points(conn) -> dict:
    sql_break_points = '''
            select bp.*, p.lat, p.lng from breakpoints bp
            inner join platforms p
            on bp.entry_id = p.id

        '''
    cursor = conn.cursor()
    cursor.execute(sql_break_points)
    points = {
        id: {
            "id": e_id,
            "coords": (lat, lng)
        }
        for id, e_id, lat, lng in cursor.fetchall()
    }
    return points


def db_directions(conn, line_id: int) -> tuple:
    SQL_directions = '''
        select d.id, d.line, d.type from routes as r
            inner join route_directions as rd
                on rd.id = r.id
            inner join directions as d
                on rd.entry_id = d.id

            where r.id = ?
            order by rd.pos
        '''
    cursor = conn.cursor()
    cursor.execute(SQL_directions, (line_id,))
    return cursor.fetchall()


def db_platforms(conn, direction_id: int) -> tuple:
    SQL_platforms = '''
        select p.id, p.lat, p.lng, s.name, s.id from stations s
            inner join station_platforms sp
                on s.id=sp.id
            inner join platforms p
                on p.id = sp.entry_id
            inner join direction_platforms dp
                on p.id = dp.entry_id
            inner join directions d
                on d.id = dp.id
            where d.id = ?
            order by dp.pos
        '''
    cursor = conn.cursor()
    cursor.execute(SQL_platforms, (direction_id,))
    return cursor.fetchall()


def insert_break(conn, direction_id: int, platform_id: int):
    sql = '''
    insert into breakpoints (id, entry_id) values(?, ?)'''
    cursor = conn.cursor()
    cursor.execute(sql, (direction_id, platform_id))
    conn.commit()


def create_table_break_points(conn):
    sql = '''create table breakpoints (id int, entry_id int)'''
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()


def is_db_valid(db_path: str):
    with sqlite3.connect(db_path) as conn:
        try:
            break_points = db_break_points(conn)
        except sqlite3.OperationalError:
            create_table_break_points(conn)
            break_points = {}
        cursor = conn.cursor()
        lines_sql = '''select id from routes 
                       where 
                          type in ("bus", "trolleybus") and 
                          id not in (select id from exclude_routes)'''
        lines = cursor.execute(lines_sql)
        for line_id in lines:
            directions = db_directions(conn, line_id[0])
            platforms = db_platforms(conn, directions[0][0])
            if len(directions) == 1:
                if not break_points.get(directions[0][0]):
                    break_platform = find_break_point(platforms)
                    insert_break(conn, directions[0][0], platforms[break_platform][0])


def get_md5(file_path):
    if not os.path.exists(file_path):
        return None
    md5 = hashlib.md5()
    with open(file_path, 'rb') as f:
        md5.update(f.read())
        return md5.hexdigest()


def get_file_hashes(folder, _files=set()):
    if not os.path.exists(folder):
        os.mkdir(folder)
    exist_files = [title for title in os.listdir(folder) if os.path.isfile(os.path.join(folder, title))]
    files = dict()
    for title in exist_files:
        if title in _files:
            try:
                files[title] = get_md5(os.path.join(folder, title))
            except OSError:
                os.remove(os.path.join(folder, title))
    return files


def remove(path):
    try:
        logger.debug("REMOVING {}".format(path))
        os.remove(os.path.join(path))
    except FileNotFoundError:
        pass


def is_time_travel_valid(time1, time2):
    if not time1 or not time2:
        return False
    final_time = time2 - time1
    if (final_time < 0) or (time2 - time1 > 60 * 30):
        return False
    else:
        return True
