from .voice import Notification, BoxException, extend_ping
import json
import time
import sys, os
from config import BaseConfig
from .utils import read_file, extract_and_delete, manage_exceptions, audio_queue, get_current_db_version, \
    download, is_db_valid, get_file_hashes, remove, is_time_travel_valid, post_request
from shutil import rmtree
from threading import Thread
import traceback
import requests
from . import eta
from logging import getLogger

logger = getLogger()


class BoxThread(Thread):
    def run(self):
        try:
            if self._target:
                self._target(*self._args, **self._kwargs)
        except BoxException as be:
            manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'warning'), str(be),
                              file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
        except Exception as e:
            ex = traceback.format_exc()
            manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'error'), str(e), ex,
                              file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
        finally:
            # Avoid a refcycle if the thread is running a function with
            # an argument that has a member that points to the thread.
            del self._target, self._args, self._kwargs


notification = Notification()


def download_not_found_files(station_id=None, md5=None):
    if not state.lang:
        return
    pattern = '{path}/{lang}/{file}_{direction}{format}'
    if not station_id:
        platforms = notification.line_platforms()
    else:
        platforms = (station_id,)
    for k, v in state.lang.items():

        folder_path = '{base}/{folder}'.format(base=BaseConfig.SOUND_FILE_PATH, folder=v['name'])
        if not os.path.exists(folder_path):
            os.mkdir(folder_path)
        for row in platforms:
            next_filename = pattern.format(path=BaseConfig.SOUND_FILE_PATH,
                                           lang=v['name'],
                                           file=row,
                                           direction=BaseConfig.NEXT,
                                           format=BaseConfig.SOUND_FORMAT)
            current_filename = pattern.format(path=BaseConfig.SOUND_FILE_PATH,
                                              lang=v['name'],
                                              file=row,
                                              direction=BaseConfig.CURRENT,
                                              format=BaseConfig.SOUND_FORMAT)
            next_url = "{host}{api}/{lang}/{file}_{direction}{format}".format(
                host=state.host,
                api=BaseConfig.SOUND_DOWNLOAD_API,
                lang=v['name'],
                file=row,
                direction=BaseConfig.NEXT,
                format=BaseConfig.SOUND_FORMAT)
            current_url = "{host}{api}/{lang}/{file}_{direction}{format}".format(
                host=state.host,
                api=BaseConfig.SOUND_DOWNLOAD_API,
                lang=v['name'],
                file=row,
                direction=BaseConfig.CURRENT,
                format=BaseConfig.SOUND_FORMAT)
            if not os.path.exists(next_filename):
                download(next_url, next_filename, md5=md5)
            if not os.path.exists(current_filename):
                download(current_url, current_filename, md5=md5)


class State:
    manage_file_path = BaseConfig.MANAGE_FILE_PATH
    id = None
    db_version = None
    host = BaseConfig.HOST
    token = None
    line_id = None
    route_type = None
    city = None
    prev_latlng = None
    line_changed = False
    lang = None
    line_files = set()
    audio_hash = dict()
    buffer = None
    db_version_api = BaseConfig.DB_VERSION_API
    db_download_api = BaseConfig.DB_DOWNLOAD_API
    gps_read_period = BaseConfig.GPS_READ_PERIOD
    gps_file_path = BaseConfig.GPS_FILE_PATH
    config_read_period = BaseConfig.SETTINGS_READ_PERIOD

    distance_coefficient = BaseConfig.distance_100m_coefficient
    projection_coefficient = BaseConfig.projection_100m_coefficient
    platform_distance_entry = BaseConfig.platform_distance_entry
    platform_distance_escape = BaseConfig.platform_distance_escape
    platform_penalty_period = BaseConfig.do_not_notification_period

    prev_platform = None
    platform_current_time = None
    platform_next_time = None

    direction = None

    @staticmethod
    def get_remote_settings() -> dict:
        export = {}
        try:
            settings = json.loads(read_file(BaseConfig.SETTINGS_FILE_PATH))
        except FileNotFoundError:
            raise BoxException('settings file not found {}'.format(BaseConfig.SETTINGS_FILE_PATH))
        except json.JSONDecodeError:
            raise BoxException('settings file JSONDecodeError {}'.format(BaseConfig.SETTINGS_FILE_PATH))
        try:
            token = read_file(BaseConfig.TOKEN_FILE_PATH).strip()
        except FileNotFoundError:
            raise BoxException('token file not found {}'.format(BaseConfig.TOKEN_FILE_PATH))
        try:
            host = read_file(BaseConfig.HOST_FILE_PATH).strip()
        except FileNotFoundError:
            raise BoxException('token file not found {}'.format(BaseConfig.HOST_FILE_PATH))
        if settings.get('instructions'):
            if settings['instructions'].get('voice'):
                if isinstance(settings['instructions']['voice'], dict):
                    export.update(settings['instructions']['voice'])

        if settings.get('city'):
            export['city'] = settings['city']
        if settings.get('line_id'):
            export['line_id'] = settings['line_id']
        if settings.get('type'):
            export['type'] = settings['type']
        if settings.get('id'):
            export['id'] = settings['id']
        if token:
            export['token'] = token
        if host:
            export['host'] = host
        return export

    def update_settings(self):
        remote_settings = self.get_remote_settings()
        try:
            f = read_file(self.manage_file_path)
            manage = json.loads(f)
        except FileNotFoundError:
            manage = dict()
        except json.JSONDecodeError:
            manage = dict()
        manage.update(remote_settings)
        updated = False
        if manage.get('line_id') != self.line_id and manage.get('line_id') is not None:
            updated = True
            self.line_id = manage['line_id']
            notification.line_id = self.line_id
            self.line_changed = True
            self.audio_hash = dict()

        if manage.get('id') != self.id and manage.get('id') is not None:
            self.id = manage['id']
            updated = True

        if manage.get('city') != self.city and manage.get('city') is not None:
            updated = True
            self.city = manage['city']

        if manage.get('host') != self.host and manage.get('host') is not None:
            updated = True
            self.host = manage['host']

        if manage.get('token') != self.token and manage.get('token') is not None:
            updated = True
            self.token = manage['token']

        if manage.get('db_version_api') != self.db_version_api and \
                manage.get('db_version_api') is not None:
            updated = True
            self.db_version_api = manage['db_version_api']

        if manage.get('db_download_api') != self.db_download_api and \
                manage.get('db_download_api') is not None:
            updated = True
            self.db_download_api = manage['db_download_api']

        if manage.get('gps_read_period') != self.gps_read_period and \
                manage.get('gps_read_period') is not None:
            updated = True
            self.gps_read_period = manage['gps_read_period']

        if manage.get('distance_coefficient') != self.distance_coefficient and \
                manage.get('distance_coefficient') is not None:
            updated = True
            self.distance_coefficient = manage['distance_coefficient']
            notification.distance_100m = self.distance_coefficient

        if manage.get('projection_coefficient') != self.projection_coefficient and \
                manage.get('projection_coefficient') is not None:
            updated = True
            self.projection_coefficient = manage['projection_coefficient']
            notification.projection_100m = self.projection_coefficient

        if manage.get('platform_distance_entry') != self.platform_distance_entry and \
                manage.get('platform_distance_entry') is not None:
            updated = True
            self.platform_distance_entry = manage['platform_distance_entry']
            notification.platform_distance_entry = self.platform_distance_entry

        if manage.get('platform_distance_escape') != self.platform_distance_escape and \
                manage.get('platform_distance_escape') is not None:
            updated = True
            if len(manage['platform_distance_escape']) == 2:
                self.platform_distance_escape = manage['platform_distance_escape']
                notification.platform_distance_escape = self.platform_distance_escape

        if manage.get('platform_penalty_period') != self.platform_penalty_period and \
                manage.get('platform_penalty_period') is not None:
            updated = True
            self.platform_penalty_period = manage['platform_penalty_period']
            notification.do_not_notification_period = self.platform_penalty_period

        if manage.get('db_version') != self.db_version and manage.get('db_version') is not None or \
            not notification.db_path and manage.get('db_version'):
            updated = True
            self.db_version = manage['db_version']
            notification.db_path = "{}/{}/data.db".format(BaseConfig.DB_PATH, self.db_version)

        if 'lang' in manage and manage['lang'] != self.lang:
            updated = True
            self.lang = manage['lang']

        if 'type' in manage:
            self.route_type = manage['type']

        if updated:
            self.save_current_state()

    def save_current_state(self):
        manage_data = dict(
            host=self.host,
            token=self.token,
            db_version_api=self.db_version_api,
            db_download_api=self.db_download_api,
            gps_read_period=self.gps_read_period,
            distance_coefficient=self.distance_coefficient,
            projection_coefficient=self.projection_coefficient,
            platform_distance_entry=self.platform_distance_entry,
            platform_distance_escape=self.platform_distance_escape,
            platform_penalty_period=self.platform_penalty_period,
            db_version=self.db_version,
            line_id=self.line_id,
            city=self.city,
            lang=self.lang,
            id=self.id
        )
        with open(BaseConfig.MANAGE_FILE_PATH, 'w') as f:
            json.dump(manage_data, f, indent=2)

    def update_db(self):
        while True:
            try:
                if not self.token:
                    raise BoxException('token not set')
                if not self.city:
                    raise BoxException('city not set')
                if not self.host:
                    raise BoxException('host not set')
                url = '{host}{api}/{city}'.format(host=self.host, api=self.db_version_api,
                                                  city=self.city)
                current_version = get_current_db_version(url, self.token)
                if current_version and (self.db_version != current_version or not os.path.exists(notification.db_path)):
                    filename = "{}/{}.zip".format(BaseConfig.DB_PATH, current_version)
                    download_url = "{url}{api}/{v}".format(url=url,
                                                           api=self.db_download_api,
                                                           v=current_version)
                    download(download_url, token=self.token, filename=filename)
                    extract_and_delete(filename, filename[:-4])
                    db_path = "{}/data.db".format(filename[:-4])
                    try:
                        is_db_valid(db_path)
                    except Exception:
                        try:
                            rmtree(filename[:-4])
                        except FileNotFoundError:
                            ...
                        raise
                    notification.db_path = db_path
                    if current_version != self.db_version:
                        try:
                            rmtree("{}/{}".format(BaseConfig.DB_PATH, self.db_version))
                        except FileNotFoundError:
                            ...
                    self.db_version = current_version
                    self.save_current_state()
                    self.audio_hash = dict()
                if BaseConfig.VOICE_ACTIVE:
                    self.audio_sync()
            except BoxException as be:
                manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'warning'),
                                  str(be), file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
            except Exception as e:
                ex = traceback.format_exc()
                manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'error'), str(e),
                                  ex, file_path=BaseConfig.EXCEPTIONS_FILE_PATH)

            finally:
                time.sleep(BaseConfig.DB_VERSION_CHECK_PERIOD)

    def feed(self, gps=None):
        if not gps:
            with open(BaseConfig.GPS_FILE_PATH, 'r') as f:
                gps = json.load(f)
        logger.debug(gps)
        is_ok = False
        if self.prev_latlng != gps:
            self.prev_latlng = gps
            lat, lng = gps.get('lat'), gps.get('lon')
            if not lat or not lng:
                return
            is_ok = notification.ping(float(lat), float(lng))
        else:
            logger.debug("similar data FAILED")
            return
        # logger.debug(is_ok)
        if is_ok:
            current_time = int(time.time())
            platform_id, is_next = is_ok
            if BaseConfig.VOICE_ACTIVE:
                order = sorted(self.lang.keys())
                for index in order:
                    audio_queue.append((platform_id,
                                        is_next,
                                        BaseConfig.SOUND_FILE_PATH,
                                        self.lang[index]['name'],
                                        self.lang[index]['action']))
            if not notification.prev_platform:
                return

            data = {}
            # leaved the platform
            if is_next:
                if self.platform_current_time and not is_time_travel_valid(self.platform_current_time, current_time):
                    return
                prev_platform = notification.prev_platform.id
                self.prev_platform = prev_platform
                self.platform_next_time = current_time
                if BaseConfig.PLATFORM_TIME_TRAVEL_ACTIVE:
                    data['platform_time_travel'] = {
                        "platform_id": prev_platform,
                        "entry_time": self.platform_current_time,
                        "leave_time": self.platform_next_time
                    }

                if BaseConfig.ETA_ACTIVE:
                    data['eta'] = eta.calc(notification.platform_left[:BaseConfig.ETA_CALCED_PLATFORM_COUNT],
                                           current_time=current_time)

            # entered the platform
            else:
                self.platform_current_time = current_time
                if (is_time_travel_valid(self.platform_next_time, self.platform_current_time)) and \
                        (self.prev_platform and self.prev_platform == notification.prev_platform.id):

                    if BaseConfig.ETA_ACTIVE:
                        data['eta_log'] = eta.write(start_platform=self.prev_platform,
                                                    start_time=self.platform_next_time,
                                                    end_platform=platform_id,
                                                    end_time=self.platform_current_time)
                else:
                    self.platform_next_time = None
                    self.prev_platform = None
            if data:
                data.update({
                    "id": self.id,
                    "route_id": self.line_id,
                    "direction_id": notification.current_direction.id,
                    "route_type": self.route_type,
                    "time": current_time

                })
                post_request(BaseConfig.transport_data_url(self.host), self.token, data)
            if self.direction != notification.current_direction.id:
                self.direction = notification.current_direction.id
                extend_ping({
                    "direction_id": notification.current_direction.id,
                    "direction_type": notification.current_direction.type
                })
                return

    def audio_sync(self):
        if not self.lang:
            return
        url_pattern = '{host}{api}/{lang}/sync'
        for ind, data in self.lang.items():
            try:
                r = requests.get(url_pattern.format(host=self.host,
                                                    api=BaseConfig.SOUND_DOWNLOAD_API,
                                                    lang=data['name']),
                                 headers=dict(Authorization=self.token),
                                 timeout=2,
                                 params=dict(line_id=self.line_id))
            except requests.Timeout:
                return

            if r.status_code != 200:
                raise BoxException('audio_sync error {} {}'.format(r.status_code, r.text))
            folder_path = os.path.join(BaseConfig.SOUND_FILE_PATH, data['name'])
            if not self.audio_hash.get(data['name']):
                files = set()
                for platform in notification.line_platforms():
                    files.add("{}_next{}".format(platform, BaseConfig.SOUND_FORMAT))
                    files.add("{}_current{}".format(platform, BaseConfig.SOUND_FORMAT))
                self.line_files = files
                self.audio_hash[data['name']] = get_file_hashes(folder_path, self.line_files)
            resp_data = r.json()['data']
            as_is = set(self.audio_hash[data['name']].keys())
            to_be = set(resp_data.keys())
            to_remove = as_is.difference(to_be)
            updated = False
            for title, md5 in resp_data.items():
                if title in self.audio_hash[data['name']]:
                    if self.audio_hash[data['name']][title] != md5:
                        updated = True
                        remove(os.path.join(folder_path, title))
                elif title in self.line_files:
                    updated = True
                    download_not_found_files(title.split('_')[0], md5=md5)
            for file in to_remove:
                updated = True
                remove(os.path.join(folder_path, file))
            if updated:
                self.audio_hash[data['name']] = get_file_hashes(folder_path)

    def is_ready(self):
        if BaseConfig.VOICE_ACTIVE and not self.lang:
            raise NotImplementedError('lang rules not set')
        if not notification.db_path:
            raise NotImplementedError('database not loaded yet')
        if not notification.line_id:
            raise NotImplementedError('line_id not set')


state = State()


def play_sound(command: str, format_: str):
    while True:
        try:
            if not audio_queue:
                continue
            base_pattern = '{cmd} {path}/{lang}/{file}_{direction}{format}'
            platform_id, is_next, file_path, lang, rule, *p = audio_queue.popleft()
            next_ = base_pattern.format(cmd=command, path=file_path, lang=lang, file=platform_id,
                                        direction=BaseConfig.NEXT, format=format_)
            current = base_pattern.format(cmd=command, path=file_path, lang=lang, file=platform_id,
                                          direction=BaseConfig.CURRENT, format=format_)
            if is_next:
                file = next_[len(command) + 1:]
                if not os.path.exists(file):
                    continue
                os.system(next_)

            else:
                file = current[len(command) + 1:]
                if not os.path.exists(file):
                    continue
                os.system(current)
        except BoxException as be:
            manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'warning'), str(be),
                              file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
        except Exception as e:
            ex = traceback.format_exc()
            manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'error'), str(e), ex,
                              file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
        finally:
            time.sleep(1)


def run():
    prev_settings_update_time = 0
    db_thread = BoxThread(target=state.update_db, daemon=True)
    thread_started = False
    if BaseConfig.VOICE_ACTIVE:
        BoxThread(target=play_sound, args=(BaseConfig.SOUND_PLAY_COMMAND, BaseConfig.SOUND_FORMAT),
                  daemon=True).start()
    while True:
        try:
            prev_settings_update_time = time.time()
            state.update_settings()
            if not thread_started:
                db_thread.start()
                thread_started = True
            state.is_ready()

        except KeyboardInterrupt:
            sys.exit(0)
        except BoxException as be:
            manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'warning'), str(be),
                              file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
        except NotImplementedError as nie:
            if str(nie):
                manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'warning'), str(nie),
                                  file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
            time.sleep(1)
            continue
        except Exception as e:
            ex = traceback.format_exc()
            manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'error'), str(e), ex,
                              file_path=BaseConfig.EXCEPTIONS_FILE_PATH)

        try:
            while True:
                state.feed()

                if time.time() - prev_settings_update_time > BaseConfig.SETTINGS_READ_PERIOD:
                    break
                time.sleep(state.gps_read_period)
        except KeyboardInterrupt:
            sys.exit(0)
        except BoxException as be:
            manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'warning'), str(be),
                              file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
            time.sleep(1)
        except Exception as e:
            ex = traceback.format_exc()
            manage_exceptions("{} {} {}\n".format(BaseConfig.NAME, BaseConfig.EXCEPTION_RECEIVER, 'error'), str(e), ex,
                              file_path=BaseConfig.EXCEPTIONS_FILE_PATH)
            time.sleep(1)


if __name__ == '__main__':
    run()

