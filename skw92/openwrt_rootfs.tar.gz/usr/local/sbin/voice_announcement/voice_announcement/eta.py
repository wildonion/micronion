from sqlalchemy.ext.declarative import declarative_base
import sqlalchemy as db
from decouple import config
from logging import getLogger
import requests
from .voice import BoxException
from datetime import datetime
from sqlalchemy import Index
from config import BaseConfig

logger = getLogger()

if BaseConfig.ETA_ACTIVE:

    engine = db.create_engine(config('ETA_DB_URL', cast=str))

    Base = declarative_base(bind=engine)

    session = db.orm.sessionmaker(bind=engine)()
else:
    Base = object


class PassesTime(Base):
    __tablename__ = 'passes_time'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    start_platform = db.Column(db.Integer)
    end_platform = db.Column(db.Integer)

    start_time = db.Column(db.Integer)
    end_time = db.Column(db.Integer)

    quarter = db.Column(db.Integer)
    hour = db.Column(db.Integer)
    weekday = db.Column(db.Integer)

    @classmethod
    def estimate(cls, start_platform_id, end_platform_id, current_time: float=None):
        now = datetime.fromtimestamp(current_time) if current_time else datetime.now()
        hour = now.hour
        quarter = hour // 3
        weekday = now.weekday()
        base_q = session.query(db.func.avg(cls.end_time - cls.start_time))\
            .filter(db.or_(
                        db.and_(cls.start_platform == start_platform_id,
                                cls.end_platform == end_platform_id),
                        db.and_(cls.start_platform == end_platform_id,
                                cls.end_platform == start_platform_id)
            )
        )
        filtered_q = base_q.filter(db.and_(cls.weekday == weekday, cls.quarter == quarter))
        data = filtered_q.first()[0]
        if not data:
            data = base_q.first()[0]
        return data

    @classmethod
    def clean(cls, time):
        r = session.query(cls).filter(cls.start_time < time).delete(False)
        session.commit()
        return r


Index('weekday_quarter_idx', PassesTime.weekday, PassesTime.quarter)
Index('weekday_hour_idx', PassesTime.weekday, PassesTime.hour)
Index('start_end_idx', PassesTime.start_platform, PassesTime.end_platform)
Index('end_start_idx', PassesTime.end_platform, PassesTime.start_platform)


def _calc(platforms: list, current_time: float=None):
    response = []
    times = [0]
    for i in range(1, len(platforms)):
        time = PassesTime.estimate(platforms[i - 1].id, platforms[i].id, current_time=current_time)
        if not time:
            break
        time = times[i - 1] + time
        response.append({
            "id": platforms[i].id,
            "eta": int(time)
        })
        times.append(time)
    return response


def calc(platforms: list, current_time=None):
    calced = _calc(platforms, current_time=current_time)
    for i in calced:
        logger.debug("{} = {}".format(i['id'], i['eta']))
    return calced
    # try:
    #     r = requests.post(url, json=extra, timeout=2)
    #     if r.status_code != 200:
    #         raise BoxException(r.text)
    # except requests.RequestException as e:
    #     logger.exception(e)
    #     pass
    # else:
    #     for i in calced:
    #         logger.debug("{} = {}".format(i['id'], i['eta']))


def write(*, start_platform, end_platform, start_time, end_time):
    mid_time = datetime.fromtimestamp((start_time + end_time) / 2)
    hour = mid_time.hour
    quarter = hour // 3
    weekday = mid_time.weekday()

    pt = PassesTime(start_platform=start_platform, end_platform=end_platform,
                    start_time=start_time, end_time=end_time, hour=hour, quarter=quarter,
                    weekday=weekday)
    session.add(pt)
    session.commit()
    logger.debug("PASSES {} {} for {} s".format(start_platform, end_platform, end_time - start_time))

    return {
        "hour": hour,
        "quarter": quarter,
        "weekday": weekday,
        "start_platform": start_platform,
        "start_time": start_time,
        "end_platform": end_platform,
        "end_time": end_time
    }



