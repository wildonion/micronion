class BoxException(Exception):
    ...





from collections import deque, namedtuple
from time import time
from shapely.geometry import Point, LineString
from .utils import get_distance, get_current_direction, \
    polyline_to_linestring, latlng_value_index_in_array, haversine, db_platforms, db_break_points, db_directions
import sqlite3
from config import BaseConfig
from logging import getLogger
import json

logger = getLogger()


def extend_ping(data):
    with open(BaseConfig.EXTEND_PING_FILE, 'w') as f:
        json.dump(data, f)


Platform = namedtuple('Platform', 'id point name lat lng station')
Ping = namedtuple('Ping', 'time lat lng')
Direction = namedtuple('Direction', 'id line platforms type')


class Notification:
    distance_100m = BaseConfig.distance_100m_coefficient
    projection_100m = BaseConfig.projection_100m_coefficient
    platform_distance_entry = BaseConfig.platform_distance_entry
    platform_distance_escape = BaseConfig.platform_distance_escape
    do_not_notification_period = BaseConfig.do_not_notification_period
    platform_left = []
    prev_platform = None

    _line_id = None
    _db_path = None

    is_prev_ping_distance_failed = False

    @property
    def db_path(self):
        return self._db_path

    @db_path.setter
    def db_path(self, db_path):
        self._db_path = db_path
        self.directions = None
        self.current_direction = None

    @property
    def line_id(self) -> int:
        return self._line_id

    @line_id.setter
    def line_id(self, line_id):
        self._line_id = line_id
        self.directions = None
        self.current_direction = None

    def __init__(self):
        self.history = deque(maxlen=10)
        self.current_direction = None
        self.directions = None
        self.platform_current_informed = dict()
        self.platform_next_informed = dict()

    def ping(self, lat: float, lng: float):
        if not self.line_id:
            raise BoxException('line_id not set')
        p = Ping(time(), lat, lng)
        if not self.pings_valid(p):
            return None
        if not self.directions:
            self._set_directions()
        p1 = self.history[0]
        self.current_direction = get_current_direction(Point(p.lat, p.lng), Point(p1.lat, p1.lng), self.directions)
        if not self.current_direction:
            logger.debug('direction')
            return None
        distance = get_distance(self.current_direction.line, Point(p.lat, p.lng))
        if distance > 0.8:  # magic coefficient, about (800 m)
            logger.debug("distance validation FAILED")
            # Change Dir
            self.directions = None
            self.current_direction = None

            # Traccar column
            # specific value to identify distance validation error
            if not self.is_prev_ping_distance_failed:
                self.is_prev_ping_distance_failed = True
                extend_ping({BaseConfig.ON_ROUTE_IDENTIFIER: BaseConfig.OUT_OF_ROUTE_VALUE})
                return
        else:
            self.is_prev_ping_distance_failed = False
            platform_now, platform_next = self._find_platform(p)
            if platform_now:
                return platform_now.id, False
            if platform_next:
                return platform_next.id, True
            return None

    def _set_directions(self):
        with sqlite3.connect(self.db_path) as conn:
            break_points = db_break_points(conn)
            directions = db_directions(conn, self.line_id)
            dirs = []

            for dir_id, dir_line, dir_type in directions:
                platform_break = break_points.get(dir_id)
                raw_line = polyline_to_linestring(dir_line)
                if platform_break:
                    line_ind = latlng_value_index_in_array(raw_line, tuple(platform_break['coords']))
                    line = LineString(raw_line[:line_ind])
                    line2 = LineString(raw_line[line_ind:])
                else:
                    line = LineString(raw_line)

                raw_platforms = db_platforms(conn, dir_id)
                platforms = []
                platforms2 = []
                to_append = platforms
                to_project = line
                for pl_id, pl_lat, pl_lng, pl_name, station in raw_platforms:

                    pl = Platform(pl_id,
                                  to_project.project(Point(pl_lat, pl_lng)),
                                  pl_name,
                                  pl_lat,
                                  pl_lng,
                                  station)
                    to_append.append(pl)

                    if platform_break:
                        if pl_id == platform_break['id']:
                            to_append = platforms2
                            to_project = line2

                            pl = Platform(pl_id,
                                          to_project.project(Point(pl_lat, pl_lng)),
                                          pl_name,
                                          pl_lat,
                                          pl_lng,
                                          station)
                            to_append.append(pl)
                platforms = sorted(platforms, key=lambda x: x.point)
                dirs.append(Direction(
                    id=dir_id,
                    line=line,
                    platforms=platforms,
                    type=dir_type)
                )
                if platform_break:
                    platforms2 = sorted(platforms2, key=lambda x: x.point)
                    dirs.append(Direction(
                        id=dir_id,
                        line=line2,
                        platforms=platforms2,
                        type=dir_type))

        if len(dirs) == 0:
            msg = "directions not found for line {}".format(self.line_id)
            raise BoxException(msg)
        elif len(dirs) != 2:
            msg = 'expected 2 directions (forward, backward), found {} for line {}'.format(len(dirs), self.line_id)
            raise BoxException(msg)
        self.directions = dirs

    def _find_between(self, projection: float) -> tuple:
        length = len(self.current_direction.platforms)
        for i, platform in enumerate(self.current_direction.platforms):
            if i == 0:
                if platform.point >= projection:
                    self.platform_left = self.current_direction.platforms[i:]
                    self.prev_platform = None
                    return None, platform
            if length - 1 >= i + 1:
                platform_2 = self.current_direction.platforms[i + 1]
                if platform.point <= projection <= platform_2.point:
                    self.platform_left = self.current_direction.platforms[i:]
                    self.prev_platform = platform
                    return platform, platform_2
            else:
                self.platform_left = []
                self.prev_platform = platform
                return platform, None

    def _find_platform(self, point: Ping) -> tuple:
        projection = self.current_direction.line.project(Point(point.lat, point.lng))
        now = None
        next = None

        platform_1, platform_2 = self._find_between(projection)
        if platform_2:
            if abs(point.time - self.platform_current_informed.get(platform_2.id, 0)) > self.do_not_notification_period:
                distance = haversine((point.lat, point.lng), (platform_2.lat, platform_2.lng))
                if distance <= self.platform_distance_entry:
                    self.platform_current_informed[platform_2.id] = point.time
                    now = platform_2
        if platform_1:
            if abs(point.time - self.platform_next_informed.get(platform_1.id, 0)) > self.do_not_notification_period:
                if projection - platform_1.point > 0:
                    distance = haversine((point.lat, point.lng), (platform_1.lat, platform_1.lng))
                    if self.platform_distance_escape[0] <= distance <= self.platform_distance_escape[1]:
                        self.platform_next_informed[platform_1.id] = point.time
                        next = platform_2
        return now, next

    def line_platforms(self) -> set:
        platform_ids = set()
        with sqlite3.connect(self.db_path) as conn:
            directions = db_directions(conn, self.line_id)
            for direction in directions:
                platforms = db_platforms(conn, direction[0])
                for platform in platforms:
                    platform_ids.add(platform[0])
        return platform_ids
    
    def pings_valid(self, ping: Ping) -> bool:
        if int(ping.lat) == 0 and int(ping.lng) == 0:
            logger.debug("zeroes FAILED")
            return False
        elif len(self.history) >= 10:
            p1 = self.history[0]

            # Time validation
            if (ping.time - p1.time) > (60 * 5):
                self.history.clear()
                self.history.append(ping)
                self.direction = None
                logger.debug("time validation FAILED")
                return False

            # Distance validation
            distance = get_distance(Point(ping.lat, ping.lng), Point(p1.lat, p1.lng))
            if distance < (self.distance_100m / 10):
                logger.debug("nearby distance validation FAILED")
                return False
            else:
                self.history.append(ping)
                return True
        else:
            self.history.append(ping)
            logger.debug("buffer validation FAILED")
            return False
