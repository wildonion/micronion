from voice_announcement import run, eta
import logging
from decouple import config
from time import time
from config import BaseConfig

import os

logging.basicConfig(level=logging._nameToLevel[config('LOGGING_LEVEL', cast=str)])


if __name__ == '__main__':
    os.makedirs(BaseConfig.SOUND_FILE_PATH, exist_ok=True)
    os.makedirs(BaseConfig.DB_PATH, exist_ok=True)
    if BaseConfig.ETA_ACTIVE:
        logging.info('ETA IS ACTIVE')
        eta.Base.metadata.create_all()
        now = time() - 3600 * 24 * 31 * BaseConfig.LOGGING_MONTH_LIMIT
        cleaned = eta.PassesTime.clean(now)
        logging.info("cleaned {}".format(cleaned))
    else:
        logging.info('ETA IS INACTIVE')
    logging.info('VOICE IS ACTIVE') if BaseConfig.VOICE_ACTIVE else logging.info("VOICE IS INACTIVE")
    logging.info('PLATFORM_SPEND_TIME_ACTIVE IS ACTIVE') if BaseConfig.PLATFORM_TIME_TRAVEL_ACTIVE else logging.info("PLATFORM_TIME_TRAVEL_ACTIVE IS INACTIVE")
    run()
