from decouple import config


class BaseConfig:
    NAME = config('NAME', cast=str)
    EXCEPTIONS_FILE_PATH = config('EXCEPTIONS_FILE_PATH', cast=str)
    EXCEPTION_RECEIVER = config('EXCEPTION_RECEIVER', cast=str)
    HOST = config('HOST', cast=str)
    DB_PATH = config("DB_PATH_DIRECTORY", cast=str)
    DB_VERSION_API = config("DB_VERSION_API", cast=str, default="/v1/cities")
    DB_DOWNLOAD_API = config("DB_DOWNLOAD_API", cast=str, default="/data")
    GPS_READ_PERIOD = config("GPS_READ_PERIOD", cast=float, default=1)
    SETTINGS_READ_PERIOD = config("SETTINGS_READ_PERIOD", cast=int, default=60)
    GPS_FILE_PATH = config('GPS_FILE_PATH', cast=str)
    SETTINGS_FILE_PATH = config('SETTINGS_FILE_PATH', cast=str)
    distance_100m_coefficient = 0.123
    projection_100m_coefficient = 0.001597
    platform_distance_entry = 40
    platform_distance_escape = [40, 100]
    do_not_notification_period = 1800

    MANAGE_FILE_PATH = config('MANAGE_FILE_PATH', cast=str)
    TOKEN_FILE_PATH = config('TOKEN_FILE_PATH', cast=str)
    HOST_FILE_PATH = config('HOST_FILE_PATH', cast=str)

    SOUND_FILE_PATH = config('SOUND_FILE_PATH', cast=str)
    SOUND_PLAY_COMMAND = 'aplay'
    SOUND_FORMAT = '.wav'
    SOUND_DOWNLOAD_API = config('SOUND_DOWNLOAD_API', cast=str, default='/transport/audio')

    DB_VERSION_CHECK_PERIOD = config('DB_VERSION_CHECK_PERIOD', cast=int, default=60)

    ACTION_BEFORE_PLATFORM = 0
    ACTION_AFTER_PLATFORM = 1

    NEXT = 'next'
    CURRENT = 'current'

    VOICE_ACTIVE = config('VOICE_ACTIVE', cast=bool, default=True)

    ETA_ACTIVE = config('ETA_ACTIVE', cast=bool, default=True)
    ETA_CALCED_PLATFORM_COUNT = config('ETA_CALCED_PLATFORM_COUNT', cast=int, default=10) + 1
    TRANSPORT_DATA_API = config('TRANSPORT_DATA_API', cast=str, default='/transport/ping/v1/data')
    LOGGING_MONTH_LIMIT = config("LOGGING_MONTH_LIMIT", cast=int, default=10)

    EXTEND_PING_FILE = config('EXTEND_PING_FILE', cast=str)

    # keys for identify positions from traccar
    ON_ROUTE_IDENTIFIER = config("ON_ROUTE_IDENTIFIER", cast=str, default='altitude')
    OUT_OF_ROUTE_VALUE = config('OUT_OF_ROUTE_VALUE', default=1)
    ON_ROUTE_VALUE = config('ON_ROUTE_VALUE', default=2)

    PLATFORM_TIME_TRAVEL_ACTIVE = config("PLATFORM_TIME_TRAVEL_ACTIVE", cast=bool, default=True)

    @classmethod
    def transport_data_url(cls, host=HOST):
        return "{}{}".format(host, cls.TRANSPORT_DATA_API)
