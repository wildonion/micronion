#!/bin/bash

# constants

# fix01: region parse from settings fixed to handle regions like 'rightel-IR'

if [ -f /settings.ini ]; then
    REGION=$(cat /settings.ini | grep -oP '^REGION = .*' | python3 -c 'import sys; print(sys.stdin.read().split("=")[-1].strip())')
    NETWORK_INTERFACE=$(cat /settings.ini | grep -oP '^DEVICE_ID_INTERFACE = \w*' | python3 -c 'import sys; print(sys.stdin.read().split("=")[-1].strip())')
    COORDS_FILE=$(cat /settings.ini | grep -oP '^LATLNG_INPUT = .*' | python3 -c 'import sys; print(sys.stdin.read().split("=")[-1].strip())')
else
    REGION='KG'
    NETWORK_INTERFACE='eth0'
    COORDS_FILE='/tmp/coords'
fi

HOSTS_URL='http://inobi.kg/hosts.json'
VERSION_FILE='/version'
UPDATE_SCRIPT='/tmp/upscript'


TEST=0
EXEC=1

API_VERSION='/transport/box/version'
API_UPDATE='/transport/box/update'


# arguments parsing (mostly for tests)

if echo $@ | grep -Eoq '\-v'; then TEST=1; fi

if echo $@ | grep -Eoq '\-\-no\-exec'; then EXEC=0; fi

if echo $@ | grep -Eoq '\-\-dry'; then
    echo "
REGION =                $REGION
HOSTS_URL =             $HOSTS_URL
VERSION_FILE =          $VERSION_FILE
UPDATE_SCRIPT =         $UPDATE_SCRIPT
NETWORK_INTERFACE =     $NETWORK_INTERFACE 
COORDS_FILE =           $COORDS_FILE
TEST =                  $TEST
API_VERSION =           $API_VERSION
API_UPDATE =            $API_UPDATE"
    exit 0
fi

if echo $@ | grep -Eoq '\-\-help'; then 
    echo 'Fuck you!'
    exit 0
fi

# stuff...

if [ $TEST -eq 1 ]; then echo 'requesting hosts.json...'; fi
curl_resp__=`curl -kLs $HOSTS_URL`

echo $curl_resp__

url=`python3 -c "import json, sys; d = json.loads('''$curl_resp__'''); print(d.get(sys.argv[1], d.get('', '')))" $REGION`

if [ -z "$url" ]; then
    echo "Url corrupted, region: '$REGION', url: '$url'" 1>&2
    echo $url
    exit 0
fi

if [ $TEST == 1 ]; then echo Host\: $url; fi

if echo "$url" | grep -Eq '^https?://'; then

    if [ $TEST == 1 ]; then echo 'requesting version...'; fi
    ver=$(curl -kLs "$url$API_VERSION")
    
    if echo "$ver" | grep -q '^[0-9]\+$'; then 
        echo Version: $ver

        if [ $ver == 0 ]; then
            exit 0
        fi

        if grep -q "^$ver$" $VERSION_FILE; then 
            if [ $TEST == 1 ]; then echo "No need to update already equal ($ver)"; fi
            exit 0
        fi

        old=`cat $VERSION_FILE`

        mac=$(ifconfig $NETWORK_INTERFACE | grep -oE '([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})')

        user=`whoami`

        data=`python3 -c "
import json, sys, time
data = dict(zip('id previous_version user region network_interface'.split(), sys.argv[2:]))
try:
    with open(sys.argv[1], 'r') as f:
        data.update(json.load(f))
except:
    pass
data['device_time'] = time.time()
print(json.dumps(data, ensure_ascii=False))
" $COORDS_FILE "$mac" "$old" "$user" "$REGION" "$NETWORK_INTERFACE"`

        echo "$data"

        curl -sLk -X POST -H 'Content-Type: application/json' -d "$data" "$url$API_UPDATE" > $UPDATE_SCRIPT
        
        if [ $TEST == 1 ]; then
            echo "executing: bash $UPDATE_SCRIPT $ver"
            cat "$UPDATE_SCRIPT"
        fi

        if [ $EXEC == 1 ]; then
            bash "$UPDATE_SCRIPT" $ver
        fi
    else
        echo 'Version corrupted' 1>&2
        echo $ver
        exit 0
    fi 
fi

