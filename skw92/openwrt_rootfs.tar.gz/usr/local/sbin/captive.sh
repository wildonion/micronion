#!/bin/bash

touch /var/spool/atd/.SEQ
chmod 770 /var/spool/atd/.SEQ 
chown -R daemon:daemon /var/spool/atd
chmod -R 777 /mnt/media

if df /dev/mmcblk0p3 --output=pcent | grep -q "100%"
then
	resize2fs -f /dev/mmcblk0p3
fi

cp /etc/dhcpd.conf.bak /var/tmp/dhcpd.conf

iptables -t nat -A PREROUTING -p tcp ! --dport 53 -j DNAT --to-destination 192.168.2.1
iptables -P FORWARD DROP

#drop ssh connections
iptables -A INPUT -p tcp --dport 22 -j DROP

#ssh brutforce firewall
#iptables -A INPUT -p tcp -m tcp --dport 22 -m state --state NEW -m hashlimit --hashlimit 1/hour --hashlimit-burst 2 --hashlimit-mode srcip --hashlimit-name SSH --hashlimit-htable-expire 60000 -j ACCEPT 
#iptables -A INPUT -p tcp -m tcp --dport 22 --tcp-flags SYN,RST,ACK SYN -j DROP 
#iptables -A INPUT -p tcp -m state --state NEW -m tcp --dport 22 -j ACCEPT

sysctl -w net/netfilter/nf_conntrack_timestamp=1
sysctl -w net/netfilter/nf_conntrack_acct=1

APN=$(sed -n 's/^APN_NAME *= *//p' /settings.ini)
USSD=$(sed -n 's/^USSD_COMMAND *= *//p' /settings.ini)

#init lte (green) LED
echo timer > /sys/class/leds/lte/trigger

# Check modem type
if lsusb | grep -q 03f0:581d 
then
	# ME906E - LT4112
	PORT=/dev/ttyUSB1
	INTERFACE=usb0

elif lsusb | grep -q 12d1:1573
then
	# ME906E Original
	PORT=/dev/ttyUSB1
	INTERFACE=usb0

elif lsusb | grep -q 12d1:15bb
then
	# ME936
	PORT=/dev/ttyUSB0
	INTERFACE=wwan0

else
	echo "NO MODEM" > /tmp/modem.stat
	echo 0 > /sys/class/leds/lte/delay_off
	echo 1 > /sys/class/leds/lte/delay_on 
	exit 1
fi

iptables -t nat -A POSTROUTING -o $INTERFACE -j MASQUERADE

tc qdisc add dev wlan0 root handle 1: htb
tc class add dev wlan0 parent 1: classid 1:1 htb rate 50Mbit

# Class 1:10 for local trafic From 192.168.2.1 to WiFi client
tc class add dev wlan0 parent 1:1 classid 1:10 htb rate 40Mbit prio 1
tc filter add dev wlan0 protocol ip parent 1:0 prio 1 u32 match ip src 192.168.2.1 flowid 1:10

# Class 1:11 for internet trafic
tc class add dev wlan0 parent 1:1 classid 1:11 htb rate 40Mbit

# Class 1:10 for data from 192.168.2.1 to internet
iptables -A PREROUTING -t mangle -s 192.168.2.1 -j MARK --set-mark 1
# 241 Class and filter rules for all clients IP range
for (( I=10;I<=250;I++ ))
do
	tc class add dev wlan0 parent 1:11 classid 1:1$I htb rate 10Mbit ceil 40Mbit prio 2
	tc filter add dev wlan0 protocol ip parent 1:0 prio 2 u32 match ip dst 192.168.2.$I flowid 1:1$I
	iptables -A PREROUTING -t mangle -s 192.168.2.$I -j MARK --set-mark $I
done


IMEI=$(echo "AT+CGSN" | atinout -s "" $PORT | grep -o "[0-9]\{15,\}") 
echo "$IMEI" > /tmp/modem.imei
echo "\"$IMEI\"" > /tmp/inobi/add.d/imei.json
COUNT=0
RESET=1

while :
do

if [ ! -z "$RESET" ]; then
	RESET=""
	tc qdisc add dev $INTERFACE root handle 1: htb
	tc class add dev $INTERFACE parent 1: classid 1:1 htb rate 40Mbit
	# Class 1:10 for data from 192.168.2.1 to internet
	tc class add dev $INTERFACE parent 1:1 classid 1:10 htb rate 2Mbit ceil 5Mbit prio 1
	tc filter add dev $INTERFACE protocol ip parent 1:0 prio 1 handle 1 fw flowid 1:10
	# 241 Class and filter rules for all clients IP range
	for (( I=10;I<=250;I++ ))
	do
		tc class add dev $INTERFACE parent 1:1 classid 1:1$I htb rate 10Mbit ceil 40Mbit prio 2
		tc filter add dev $INTERFACE protocol ip parent 1:0 prio 2 handle $I fw flowid 1:1$I
	done
	echo "AT^USSDMODE=0" | atinout -s "OK" $PORT
	echo "AT^NDISDUP=1,1,\"$APN\"" | atinout -s "OK" $PORT
	echo "" > /tmp/modem.imsi
fi

if ! cat /tmp/modem.imei | grep -q "^[0-9]\{14,\}$"
then
	IMEI=$(echo "AT+CGSN" | atinout -s "" $PORT | grep -o "[0-9]\{14,\}")
	echo "$IMEI" > /tmp/modem.imei
	echo "\"$IMEI\"" > /tmp/inobi/add.d/imei.json
fi

if ! cat /tmp/modem.imsi | grep -q "^[0-9]\{14,\}$"
then
        IMSI=$(echo "AT+CIMI" | atinout -s "" -t 3 $PORT | grep -o "[0-9]\{14,\}")
        echo "$IMSI" > /tmp/modem.imsi
        #echo "\"$IMSI\"" > /tmp/inobi/add.d/imsi.json
fi

sleep 15

echo "AT^HCSQ?" | atinout -s "HCSQ" $PORT | grep "HCSQ:" > /tmp/modem.stat
echo "AT^SYSINFOEX" | atinout -s "SYSINFOEX" $PORT | grep "SYSINFOEX:" >> /tmp/modem.stat

if ! grep -q "HCSQ\|\|SYSINFOEX" /tmp/modem.stat
then
# no right answer from modem 
	echo 1 > /sys/class/leds/lte/delay_on
	echo 0 > /sys/class/leds/lte/delay_off
elif grep -q "SYSINFOEX: *[0-9],[0-9],[0-9],255," /tmp/modem.stat
then
# no SIM card 
	echo "AT^TMODE=3" | atinout -t 1 -s "OK" $PORT
	RESET=1
	DISCONNECTED=1
	COUNT=0
	if [ "$(cat /sys/class/leds/lte/delay_off)" != "200" ]
	then
		echo 200 > /sys/class/leds/lte/delay_on
		echo 200 > /sys/class/leds/lte/delay_off
	fi
	sleep 15
elif grep -q "NO SERVICE" /tmp/modem.stat
then
# no service ( cellular network unreacheble )
	echo "AT^NDISDUP=1,0" | atinout -t 3 -s "OK" $PORT
	DISCONNECTED=1
	COUNT=0
	if [ "$(cat /sys/class/leds/lte/delay_off)" != "200" ]
	then
		echo 200 > /sys/class/leds/lte/delay_on
		echo 200 > /sys/class/leds/lte/delay_off
	fi
	if echo "AT+CFUN?" | atinout -s "+CFUN:" $PORT | grep -q "+CFUN: *0"
	then
		echo "AT^TMODE=3" | atinout -t 1 -s "OK" $PORT
		RESET=1
		sleep 15
	fi	
elif grep -q "GSM\|\|LTE\|\|CDMA" /tmp/modem.stat
then
# there is walid network service 
	if [ ! -z "$DISCONNECTED" ]
	then
# make ip connection
		echo "AT^NDISDUP=1,1,\"$APN\"" | atinout -s "OK" $PORT
		DISCONNECTED=""
	else

#-------------------- Check status of ip connection -------------------------

NDISSTAT=$(echo "AT^NDISSTATQRY?" | atinout -s "NDISSTATQRY" $PORT | grep "NDISSTATQRY:")
if echo $NDISSTAT | grep "NDISSTATQRY: 1,"
then
	if [ ! -f /tmp/modem.num ] && [ ! -z "$USSD" ]
	then
	# Send USSD only once 
	touch /tmp/modem.num
	PHONE=$(echo "AT+CUSD=1,\"$USSD\",15" | atinout -t 15 -s "+CUSD:" $PORT | grep -o "[0-9]\{7,\}")
	echo "\"$PHONE\"" > /tmp/inobi/add.d/phone.json
	echo "$PHONE" > /tmp/modem.num
	fi

	if [ "$INTERFACE" = "wwan0" ]
	then
	# If ME936 modem, wwan0 need to be configured manually
		DHCP=$(echo "AT^DHCP?" | atinout -t 5 -s "DHCP:" $PORT | grep "DHCP:")
		H_IP=$(echo $DHCP | cut -d, -f1 | grep -o "[0-9a-fA-F]\{8\}")
		H_NETMASK=$(echo $DHCP | cut -d, -f2 | grep -o "[0-9a-fA-F]\{8\}")
		H_GATEWAY=$(echo $DHCP | cut -d, -f3 | grep -o "[0-9a-fA-F]\{8\}")		
		H_PDNS=$(echo $DHCP | cut -d, -f5 | grep -o "[0-9a-fA-F]\{8\}")
		H_SDNS=$(echo $DHCP | cut -d, -f6 | grep -o "[0-9a-fA-F]\{8\}")
		IP=$(printf '%d.%d.%d.%d\n' $(echo $H_IP | grep -o .. | tac | paste -sd '' - | sed 's/../0x& /g'))
		GATEWAY=$(printf '%d.%d.%d.%d\n' $(echo $H_GATEWAY | grep -o .. | tac | paste -sd '' - | sed 's/../0x& /g'))
		PDNS=$(printf '%d.%d.%d.%d\n' $(echo $H_PDNS | grep -o .. | tac | paste -sd '' - | sed 's/../0x& /g'))
		SDNS=$(printf '%d.%d.%d.%d\n' $(echo $H_SDNS | grep -o .. | tac | paste -sd '' - | sed 's/../0x& /g'))
		if echo $IP | grep -q "[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}"
		then
		if ! ifconfig wwan0 | grep -q $IP
		then
		# If IP was changed (connection was loosed) reconfigure wwan0
			ifconfig wwan0 $IP
			route del default dev wwan0
			route add default gw $GATEWAY dev wwan0
			echo -e "nameserver $PDNS\nnameserver $SDNS" | /usr/bin/resolvconf -a $INTERFACE
			/usr/bin/resolvconf -u
		fi
		fi
	fi

	DNS_OPTIONS=$(cat /etc/resolv.conf | grep -o '^nameserver [0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}' | awk '{print($2)}' | paste -sd "," -)
	# If DNS servers was changed, reconfigure DHCP server
	if ! grep -q $DNS_OPTIONS /var/tmp/dhcpd.conf
	then
		sed -i "s/[0-9]*.[0-9]*.[0-9]*.[0-9]*,[0-9]*.[0-9]*.[0-9]*.[0-9]*/$DNS_OPTIONS/g" /var/tmp/dhcpd.conf
		/usr/bin/systemctl restart 'dhcpd4@wlan0'

		DNS1=$(cat /etc/resolv.conf | grep -o '[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}' | sed -n '1p')
		DNS2=$(cat /etc/resolv.conf | grep -o '[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}' | sed -n '2p')
		iptables -A FORWARD -p tcp --dport 53 -d $DNS1 -j ACCEPT
		iptables -A FORWARD -p udp --dport 53 -d $DNS1 -j ACCEPT
		iptables -A FORWARD -p tcp --sport 53 -s $DNS1 -j ACCEPT
		iptables -A FORWARD -p udp --sport 53 -s $DNS1 -j ACCEPT

		iptables -A FORWARD -p tcp --dport 53 -d $DNS2 -j ACCEPT
		iptables -A FORWARD -p udp --dport 53 -d $DNS2 -j ACCEPT
		iptables -A FORWARD -p tcp --sport 53 -s $DNS2 -j ACCEPT
		iptables -A FORWARD -p udp --sport 53 -s $DNS2 -j ACCEPT
	fi	
	
	if ! grep -q "^{}" /tmp/inobi/settings
	then
		COUNT=0
		if [ "$(cat /sys/class/leds/lte/delay_off)" != "2000" ]
		then
		echo 2000 > /sys/class/leds/lte/delay_off
		echo 200 > /sys/class/leds/lte/delay_on
		fi
	else 
		if [ "$(cat /sys/class/leds/lte/delay_off)" != "500" ]
		then
		echo 500 > /sys/class/leds/lte/delay_on
		echo 500 > /sys/class/leds/lte/delay_off
		fi

		PING=$(cat /etc/resolv.conf | grep -o '^nameserver [0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}' | awk '{print($2)}' | head -1)
		if [ ! -z "$PING" ]; then
			if ! ping -c 1 -W 2 $PING
			then
				(( COUNT=COUNT+1 ))
				if [ "$COUNT" -ge "3" ]; then
					echo "AT^TMODE=3" | atinout -t 1 -s "OK" $PORT
					DISCONNECTED=1
					COUNT=0
					RESET=1
					sleep 15
				fi
			else
				COUNT=0
			fi
		fi
	fi

elif echo $NDISSTAT | grep "NDISSTATQRY: 0,"
then
	echo "AT^NDISDUP=1,0" | atinout -t 3 -s "OK" $PORT
	if [ "$(cat /sys/class/leds/lte/delay_off)" != "200" ]
	then
		echo 200 > /sys/class/leds/lte/delay_on
		echo 200 > /sys/class/leds/lte/delay_off
	fi
	DISCONNECTED=1
	COUNT=0
fi

fi
fi
done


