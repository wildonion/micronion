#!/usr/bin/env python3

import sys

__version_info__ = (0, 1, 0)
__version__ = '.'.join(map(str, __version_info__))

if __name__ == '__main__' and {'--version', '-V'} & set(sys.argv[1:]):
    print(__version__)
    sys.exit(0)


import sys, re
import time
import os
import json
import math


REGEXP_DM = re.compile(r'^(\d+)(\d\d\.\d+)$')
REGEXP_RMC = re.compile(r'^\$GPRMC,.*,A,([^,]*),(N|S),([^,]*),(E|W),(\d*.\d*)')


class LatLngFix(object):

    @classmethod
    def dm_to_sd(cls, dm):
        if not dm or dm == '0':
            return 0.0
        d, m = REGEXP_DM.match(dm).groups()
        return round(float(d) + float(m) / 60, 8)

    @classmethod
    def to_float(cls, lat, dir):
        sd = cls.dm_to_sd(lat)
        if dir in 'EN':
            return +sd
        elif dir in 'SW':
            return -sd
        else:
            return 0.0


def bearing_between(pointA, pointB):

    lat1 = math.radians(pointA[0])
    lat2 = math.radians(pointB[0])

    diffLong = math.radians(pointB[1] - pointA[1])

    x = math.sin(diffLong) * math.cos(lat2)
    y = math.cos(lat1) * math.sin(lat2) - (math.sin(lat1)
            * math.cos(lat2) * math.cos(diffLong))

    initial_bearing = math.degrees(math.atan2(x, y))
    compass_bearing = (initial_bearing + 360) % 360

    return compass_bearing


class Config:
    NORMAL_MAXIMUM_COORDINATES_INTERVAL = 5

    class LedState:
        OK = 0
        NO_COORDS = 1
        NOT_INITED = 2


def main(dev, output_filename, verbose=False, raw=None, leds=False, cfg=Config()):

    def _dump_data(data, raw=None, tmp=False):
        if output_filename == '-':
            print(data)
            return

        fn = output_filename
        if raw:
            fn = output_filename+raw
            d = data
        else:
            d = json.dumps(data)

        if tmp:
            tmp_fn = fn+'.tmp'
            with open(tmp_fn, 'w') as f:
                print(d, file=f)
            os.rename(tmp_fn, fn)
        else:
            with open(fn, 'w') as f:
                print(d, file=f)

    os.system('stty -F {} 9600'.format(dev))

    led_state = None

    def set_led_state(new_state):

        nonlocal led_state

        if new_state == cfg.LedState.OK:
            # show all ok with gps
            os.system('echo 2000 > /sys/class/leds/gps/delay_off')
            os.system('echo 200 > /sys/class/leds/gps/delay_on')
        elif new_state == cfg.LedState.NOT_INITED:
            # say no data from gps
            os.system('echo 0 > /sys/class/leds/gps/delay_off')
            os.system('echo 1 > /sys/class/leds/gps/delay_on')
        elif new_state == cfg.LedState.NO_COORDS:
            # no valid coords from gps
            os.system('echo 500 > /sys/class/leds/gps/delay_off')
            os.system('echo 500 > /sys/class/leds/gps/delay_on')
            led_state = cfg.LedState.NO_COORDS
        elif new_state is None:
            # enabling led
            os.system('echo timer > /sys/class/leds/gps/trigger')

        if verbose:
            print('led state change:', led_state, '->', new_state)

        led_state = new_state

    if leds:
        set_led_state(None)
        set_led_state(cfg.LedState.NOT_INITED)

    d = dict(lat=0.0, lon=0.0)

    _dump_data(dict(lat=0.0, lon=0.0))

    prev_pos = None

    ts = dict(
        coord=None,
        line=None
        )

    with open(dev, 'rb') as input_device:
        for line in input_device:
            
            now = time.time()
            ts['line'] = now

            try:
                line = line.decode()
            except UnicodeDecodeError:
                continue

            res = REGEXP_RMC.match(line)
            if res:
                lat, lat_dir, lng, lng_dir, knots = res.groups()

                latitude = LatLngFix.to_float(lat, lat_dir)
                longitude = LatLngFix.to_float(lng, lng_dir)

                try:
                    knots = float(knots)
                except ValueError:
                    knots = 0.0

                current_pos = (latitude, longitude)

                bearing = None if prev_pos is None else bearing_between(prev_pos, current_pos)

                prev_pos = current_pos

                d = dict(
                    lat=latitude, 
                    lon=longitude, 
                    speed=knots, 
                    bearing=bearing
                )

                if verbose:
                    print(d)
                    if raw:
                        print(line)

                _dump_data(d, tmp=True)

                if raw:
                    _dump_data(line, raw=raw)


                if leds:
                    if led_state != cfg.LedState.OK or ts['coord'] is None:
                        set_led_state(cfg.LedState.OK)

                ts['coord'] = now

            # no valid coords line
            else:

                if leds:
                    if led_state == cfg.LedState.NOT_INITED or (led_state == cfg.LedState.OK and now-ts['coord'] >= cfg.NORMAL_MAXIMUM_COORDINATES_INTERVAL):
                        set_led_state(cfg.LedState.NO_COORDS)

                    else:
                        # already NO_COORDS
                        pass



if __name__ == '__main__':
    try:
        sc_name, dev, output_filename, *args = sys.argv
    except ValueError:
        print("""Error: No output_filename specified.

Usage: {} {{input_device}} {{output_filename}}
""".format(sys.argv[0]))
        sys.exit(1)
    else:
        verbose = '-v' in args or '--verbose' in args
        raw = '-r' in args or '--raw' in args
        leds = not ('--no-led' in args)
        main(dev, output_filename, verbose, raw='.raw' if raw else None, leds=leds)

