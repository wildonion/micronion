#!/bin/bash

WIFI_LIST=$(hostapd_cli all_sta | grep "[0-9a-f]\{2\}\(:[0-9a-f]\{2\}\)\{5\}")
WIFI_LIST_NUM=$(echo $WIFI_LIST | wc -w)

if [ ! -f /tmp/wifi.list ]
then
	touch /tmp/wifi.list
fi

if [ ! -f /tmp/connected.list ]
then
	touch /tmp/connected.list
fi

CONNECTED=0
for (( I=1;I<=WIFI_LIST_NUM;I++ ))
do
	MAC=$(echo $WIFI_LIST | awk "{print \$$I}")
	IP=$(arp -a | grep "$MAC" | grep -o "\([0-9]\{1,3\}[.]\)\{3\}[0-9]\{1,3\}")
	if iptables -t nat -L | grep -q "$IP"
	then
		((CONNECTED++))
		if ! grep "$MAC" /tmp/connected.list
		then
			echo "$MAC" >> /tmp/connected.list
		fi
	fi		
	if ! grep "$MAC" /tmp/wifi.list
	then
		echo "$MAC" >> /tmp/wifi.list
	fi
done
TOTAL=$(grep -c "[0-9a-f]\{2\}\(:[0-9a-f]\{2\}\)\{5\}" /tmp/wifi.list)
CONN_TOTAL=$(grep -c "[0-9a-f]\{2\}\(:[0-9a-f]\{2\}\)\{5\}" /tmp/connected.list)

echo "Wi-Fi connected: $WIFI_LIST_NUM
Wi-Fi total: $TOTAL 
Internet connected: $CONNECTED
Internet total: $CONN_TOTAL" > /tmp/wifi.stat


