#!/bin/bash

# exit if settings OBD = no/0/false/n
( cat /settings.ini | grep -oE 'OBD = (true|yes|1|y)' ) || exit 0

while :
do
	str=$(hcitool scan)
	mac=$(echo $str | grep -io "[a-f0-9][a-f0-9]:[a-f0-9][a-f0-9]:[a-f0-9][a-f0-9]:[a-f0-9][a-f0-9]:[a-f0-9][a-f0-9]:[a-f0-9][a-f0-9] OBD" | grep -oi "[a-f0-9][a-f0-9]:[a-f0-9][a-f0-9]:[a-f0-9][a-f0-9]:[a-f0-9][a-f0-9]:[a-f0-9][a-f0-9]:[a-f0-9][a-z0-9]")
	if [ "$mac" != "" ]
	then
		rfcomm connect hci0 $mac
	else
		sleep 5s
	fi
done &

sr=200
while :
do
	if [ -e "/tmp/inobi/obd" ] && [ -e /dev/rfcomm0 ]
	then
		counter=0
		if [ "$sr" -gt 100 ]
		then
			echo "AT SP 0" | elm327at /dev/rfcomm0
			echo "01 00" | elm327at /dev/rfcomm0
			sr=0
		fi

		(( sr++ )) 
		
		while read LINE
		do
			res=$(echo $LINE | elm327at /dev/rfcomm0)
			out[$counter]=$(echo "$LINE: $res")
			echo ${out[counter]}
			(( counter++ ))
		done < /tmp/inobi/obd
	
		echo ${out[0]} > /tmp/obd.out 
		counter=1
		
		while [ $counter -lt ${#out[@]} ]
		do
			echo ${out[counter]} >> /tmp/obd.out
			(( counter++ ))
		done
	else
		sleep 5s
	fi
done

