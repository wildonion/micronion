#!/usr/bin/env python3

import attr
import re
import os, sys
import subprocess
from pprint import pprint
import io
import itertools as IT, functools as FT
import xml.etree.ElementTree as ET
import struct
import socket
import time
import json
from datetime import datetime, timezone, timedelta
import contextlib
import shutil
from urllib.parse import urlparse
import threading
import collections
import ftplib
import requests
from collections import Counter
from decouple import config


TEST = False

ARP_CMD = 'arp -an' # 'arp -an -i wlan0'
ARP_RE = re.compile(r'. \((?P<ip>(?!0)([0-9]{1,3}\.){3}([0-9]{1,3}))\) at (?P<mac>([a-fA-F0-9]{2}[:|\-]){5}[a-fA-F0-9]{2}).*\s(?P<interface>\S+)')

CONNTRACK_CMD = 'conntrack -j -o extended,xml,ktimestamp -E -e DESTROY'

COORDS_FILE = '/tmp/coords'
COORDS_EXP = 5

USERS_DIR = '/tmp/inobi/users/'
USER_FILE_FORMAT = '{mac}.json'

OUTPUT_DIRECTORY = '/tmp/output/'
OUTPUT_FILENAME_CURRENT = 'current'
OUTPUT_FILENAME_TEMPLATE = '{dt_info}_{service}_{operator}_box-{box_id}.{output_type}.json'
OUTPUT_SERVICE_NUMBER = 8
OUTPUT_OPERATOR_NAME = 'rightel'
OUTPUT_DATE_FORMAT = '%Y%m%d%H%M%S'

NETWORK_INTERFACE = 'wlan0'

FILE_OPEN_INTERVAL = 10#5*60
FILE_DISPATCHER_SLEEP_INTERVAL = 1

GET_APN_CMD="cat /settings.ini | grep 'APN_NAME =' | awk '{print $3}'"
GET_IMSI_CMD = 'cat /tmp/modem.imsi'
GET_IMEI_CMD = 'cat /tmp/modem.imei'
GET_HOST_CMD = 'cat /tmp/inobi/host'
# GET_IMSI_CMD="echo 'AT+CIMI' | /usr/local/sbin/atinout -s '' /dev/ttyUSB1 | grep -E '[0-9]{14,}'"
# GET_IMEI_CMD="echo 'AT+CGSN' | /usr/local/sbin/atinout -s '' /dev/ttyUSB1 | grep -E '[0-9]{15,}'"

BOX_INFO_PATH = '/tmp/inobi/settings'
BOX_INFO_EXP = 20


@attr.s
class BoxInfo:
    device_id = attr.ib()

    id = attr.ib(default=None)
    device_phone = attr.ib(default=None)

    imsi = attr.ib(default=None)
    imei = attr.ib(default=None)

    apn = attr.ib(default=None)

    location = attr.ib(default=None)

    _last_info_ts = None
    _info = None

    @classmethod
    def get(cls, path=None, exp=None, **kwargs):
        if path is None:
            path = BOX_INFO_PATH
        if exp is None:
            exp = BOX_INFO_EXP
        now = time.time()
        if cls._info is None or cls._last_info_ts is None or now - cls._last_info_ts > exp:
            try:
                with open(path) as f:
                    j = json.load(f)
            except (FileNotFoundError, ValueError):
                return None
            try:
                info = cls(device_id=j['device_id'],
                           id=j.get('id'), 
                           device_phone=j.get('device_phone'),
                           **kwargs,
                           )   
            except KeyError:
                return None
            else:
                cls._last_info_ts = now
                cls._info = info

        for k, v in kwargs.items():
            setattr(cls._info, k, v)
        
        return cls._info


    _last_coords_ts = None
    _coord = None


def ip2int(v):
    return struct.unpack('!I', socket.inet_aton(v))[0]


@attr.s(hash=False, cmp=False, slots=True)
class ARPLine:
    """
    # ? (192.168.2.1) at 00:0b:6a:16:4b:ed [ether] on wlan0
    """

    ip = attr.ib()
    mac = attr.ib()
    interface = attr.ib()

    RE = ARP_RE

    @classmethod
    def parse_line(cls, line):
        if not isinstance(line, str):
            line = line.decode()
        m = cls.RE.match(line)
        if m:
            return cls(**m.groupdict())

    def __hash__(self):
        return hash(self.ip)

    def __eq__(self, other):
        if isinstance(other, type(self)):
            return self.ip == other.ip
        return NotImplemented


def arpdict(cmd=None):
    if cmd is None:
        cmd = ARP_CMD
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return { a.ip: a for a in map(ARPLine.parse_line, p.stdout) if a is not None }


def _strip_cmd_output(cmd):
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = p.stdout.read().decode()
    return out.strip()

def get_host(cmd=None):
    if cmd is None:
        cmd = GET_HOST_CMD
    return _strip_cmd_output(cmd)

def get_imsi(cmd=None):
    if cmd is None:
        cmd = GET_IMSI_CMD
    return _strip_cmd_output(cmd)

def get_imei(cmd=None):
    if cmd is None:
        cmd = GET_IMEI_CMD
    return _strip_cmd_output(cmd)

def get_apn(cmd=None):
    if cmd is None:
        cmd = GET_APN_CMD
    return _strip_cmd_output(cmd)


@attr.s(hash=False, cmp=False, slots=True)
class ConntrackFlow:
    """
    # <flow type="destroy">
    # <meta direction="original">
    # <layer3 protonum="2" protoname="ipv4"><src>192.168.2.171</src><dst>109.71.231.39</dst></layer3>
    # <layer4 protonum="17" protoname="udp"><sport>56463</sport><dport>53</dport></layer4>
    # <counters><packets>1</packets><bytes>85</bytes></counters>
    # </meta>
    # <meta direction="reply">
    # <layer3 protonum="2" protoname="ipv4"><src>109.71.231.39</src><dst>100.89.248.182</dst></layer3>
    # <layer4 protonum="17" protoname="udp"><sport>53</sport><dport>56463</dport></layer4>
    # <counters><packets>1</packets><bytes>529</bytes></counters>
    # </meta>
    # <meta direction="independent"><id>2372138528</id><timestamp><start>1557299081474537658</start><stop>1557299111521889757</stop></timestamp><deltatime>30</deltatime>
    # </meta>
    # </flow>
    """

    @attr.s
    class Meta:
        """
        # <meta direction="original">
        # <layer3 protonum="2" protoname="ipv4"><src>192.168.2.171</src><dst>109.71.231.39</dst></layer3>
        # <layer4 protonum="17" protoname="udp"><sport>56463</sport><dport>53</dport></layer4>
        # <counters><packets>1</packets><bytes>85</bytes></counters>
        # </meta>
        """

        direction = attr.ib()

        protonum = attr.ib(converter=int)
        protoname = attr.ib()

        src = attr.ib()
        dst = attr.ib()
        sport = attr.ib()
        dport = attr.ib()

        packets = attr.ib(converter=int)
        bytes = attr.ib(converter=int)

        @classmethod
        def fromxml(cls, v):
            layer3, layer4, counters = v
            # todo: check if protonum is 1, aka icmp 
            sport, dport = layer4.find('sport'), layer4.find('dport')
            return cls(
                direction=v.get('direction'),
                src=layer3[0].text,
                dst=layer3[1].text,
                sport=sport.text if sport is not None else sport,
                dport=dport.text if dport is not None else dport, 
                packets=counters[0].text,
                bytes=counters[1].text,
                **layer4.attrib,    # protonum, protoname
            )

        @property
        def source(self):
            return ':'.join((self.src, str(self.sport)))
        
        @property
        def destination(self):
            return ':'.join((self.dst, str(self.dport)))

        srcint = property(lambda s: ip2int(s.src))
        dstint = property(lambda s: ip2int(s.dst))


    type = attr.ib()

    original = attr.ib(converter=Meta.fromxml)
    reply = attr.ib(converter=Meta.fromxml)

    id = attr.ib(converter=int)

    state = attr.ib()

    _ts_converter = lambda x: int(x) / 10 ** 9
    start_ts = attr.ib(converter=_ts_converter)
    stop_ts = attr.ib(converter=_ts_converter)

    _deltatime = attr.ib(converter=int)

    @property
    def deltatime(self):
        return self.stop_ts - self.start_ts
    
    @property
    def invalid(self):
        return self.original.srcint, self.original.sport

    @property
    def valid(self):
        return self.reply.dstint, self.reply.dport
    
    @property
    def destination(self):
        return self.original.dstint, self.original.dport
    
    @classmethod
    def parsexml(cls, line):
        try:
            el = ET.fromstring(line)
        except ET.ParseError:
            return None
        return cls.fromxml(el)

    @classmethod
    def fromxml(cls, v):
        original, reply, meta = v
        meta = list(meta)
        if len(meta) == 3:
            state = None
            id, ts, deltatime = meta
        else:
            id, state, ts, deltatime = meta
        start_ts, stop_ts = ts
        return cls(
            type=v.attrib['type'],
            original=original,
            reply=reply,
            id=id.text,
            state=state.tag if state is not None else None,
            start_ts=start_ts.text,
            stop_ts=stop_ts.text,
            deltatime=deltatime.text,
        )


@attr.s
class Coordinate:
    """
    # {"lat": 0.0, "lng": 0.0}
    """
    lat = attr.ib()
    lng = attr.ib()

    _last_coords_ts = None
    _coord = None

    @classmethod
    def get(cls, filepath=None, exp=None):
        if filepath is None:
            filepath = COORDS_FILE
        if exp is None:
            exp = COORDS_EXP
        now = time.time()
        if cls._coord is None or cls._last_coords_ts is None or now - cls._last_coords_ts > exp:
            try:
                with open(filepath) as f:
                    j = json.load(f)
            except (FileNotFoundError, ValueError):
                return None
            else:
                cls._last_coords_ts = now
                cls._coord = cls(lat=j['lat'], lng=j.get('lng') or j.get('lon'))
        return cls._coord


@attr.s
class User:
    phone = attr.ib()

    _cache = dict()

    USER_FILE_FP_TEMPLATE = os.path.join(USERS_DIR, USER_FILE_FORMAT)

    @classmethod
    def get(cls, mac):
        if mac in cls._cache:
            return cls._cache[mac]
        try:
            with open(cls.USER_FILE_FP_TEMPLATE.format(mac=mac)) as f:
                j = json.load(f)
        except (FileNotFoundError, ValueError):
            return None
        else:
            u = cls(phone=j['phone'])
            cls._cache[mac] = u
            return u


class FlowOutput:
    
    def init(self):
        """
        return None to pass init output
        """
        raise NotImplementedError()

    def __call__(self, flow, arp=None, box=None, **kwargs):
        """
        return None to pass flow
        """
        raise NotImplementedError()


class CSVOutput(FlowOutput):
    headers = ()
    delimiter = ','
    null = ''
    force_str = False
    with_headers = True
    
    def __init__(self, values_handler=None, headers=None, delimiter=None, null=None, force_str=None, with_headers=None):
        self.delimiter = delimiter if delimiter is not None else self.delimiter 
        self.null = null if null is not None else self.null
        self.headers = tuple(headers) if headers is not None else self.headers
        self.force_str = force_str if force_str is not None else self.force_str
        self.values_handler = values_handler
        self.with_headers = with_headers if with_headers is not None else self.with_headers

    def init(self):
        if self.with_headers:
            return self.delimiter.join(self.headers)

    def __call__(self, *args, **kwargs):
        vals = self.values(*args, **kwargs)
        if vals is None:
            return None
        assert len(vals) == len(self.headers)
        return self.delimiter.join(map(
            lambda x: (x if not self.force_str else str(x)) if x is not None else self.null, 
            vals,
        ))

    def values(self, *args, **kwargs):
        if self.values_handler is not None:
            return self.values_handler(*args, **kwargs)
        raise NotImplementedError()


def purify_mac_value(mac):
    return ''.join(ch for ch in mac if ch not in ':-')


class ValueConverterMixin:

    def ip_port_to_value(self, v):
        ip, port = v
        return '{:x}'.format(ip), port
    
    def coordinate_to_value(self, coord):
        return '{:.5f}'.format(coord)

    def mac_to_value(self, mac):
        return purify_mac_value(mac)

    def time_to_value(self, value):
        return datetime.utcfromtimestamp(value).replace(tzinfo=timezone.utc).astimezone(tz=timezone(timedelta(hours=4, minutes=30))).strftime('%Y%m%d%H%M%S')

    def session_id_value(self, mac, flow_id):
        return '{}{}'.format(purify_mac_value(mac), flow_id)


class IranIPDROutput(CSVOutput, ValueConverterMixin):
    headers = 'phone,mac,start,protonum,invalid_ip,invalid_port,valid_ip,valid_port,dst_ip,dst_port,loc1,loc2,apn,imsi,imei'.split(',')
    delimiter = '|'

    def values(self, flow, arp=None, user=None, box=None, **kwargs):
        if not TEST and (arp is None or user is None or box is None):
            return 
        coords = box.location
        apn = box.apn
        imsi = box.imsi
        imei = box.imei
        return [
            user and user.phone,
            arp and self.mac_to_value(arp.mac),
            str(int(flow.start_ts)),
            str(flow.original.protonum),
            # flow.original.source,
            # flow.original.destination,
            # flow.reply.destination,
            *self.ip_port_to_value(flow.invalid),
            *self.ip_port_to_value(flow.valid),
            *self.ip_port_to_value(flow.destination),
            coords and self.coordinate_to_value(coords.lat),
            coords and self.coordinate_to_value(coords.lng),
            apn,
            imsi,
            imei,
        ] 
    
class IranIPDRJSONOutput(CSVOutput):
    with_headers = False

    def values(self, flow, arp=None, user=None, box=None, **kwargs):
        if not TEST and (arp is None or user is None or box is None):
            return 
        coords = box.location
        apn = box.apn
        imsi = box.imsi
        imei = box.imei
        return {
            "phone": user and user.phone,
            "mac": arp and self.mac_to_value(arp.mac),
            "start": str(int(flow.start_ts)),
            "protonum": str(flow.original.protonum),
            "invalid_ip": self.ip_port_to_value(flow.invalid)[0],
            "invalid_port": self.ip_port_to_value(flow.invalid)[1],
            "valid_ip": self.ip_port_to_value(flow.valid)[0],
            "valid_port": self.ip_port_to_value(flow.valid)[1],
            "dst_ip": self.ip_port_to_value(flow.destination)[0],
            "dst_port": self.ip_port_to_value(flow.destination)[1],
            "loc1": coords and self.coordinate_to_value(coords.lat),
            "loc2": coords and self.coordinate_to_value(coords.lng),
            "apn": apn,
            "imsi": imsi,
            "imei": imei
        }

    def ip_port_to_value(self, v):
        ip, port = v
        return '{:x}'.format(ip), port

    def mac_to_value(self, mac):
        return self.purify_mac_value(mac)

    def purify_mac_value(self, mac):
        return ''.join(ch for ch in mac if ch not in ':-')

    def coordinate_to_value(self, coord):
        return '{:.5f}'.format(coord)

class IranCDROutput(CSVOutput, ValueConverterMixin):
    headers = ('SessionId,MSISDN,Ip,MacAddress,StartTime,EndTime,Duration'
               ',ByteUp,ByteDown,PackageName,PackageCode,PackageId,ServiceType'
               ',cdr_type,NAS_ID'
               ',NodeMsisdn,NodeIP,NodeIMEI,NodeLocation'
               ',Reserved field NO.1,Reserved field NO.2,Reserved field NO.3,Reserved field NO.4,Reserved field NO.5'
               ).split(',')
    delimiter = ','

    def values(self, flow, arp=None, user=None, coords=None, box=None, **kwargs):
        if not TEST and (arp is None or user is None or box is None):
            return 
        device_phone = box.device_phone
        box_id = box.device_id
        imei = box.imei
        coords = box.location
        return [
            arp and self.session_id_value(arp.mac, flow.id),  # session_id
            user and user.phone,
            flow.original.dst,
            arp and self.mac_to_value(arp.mac),
            self.time_to_value(flow.start_ts),
            self.time_to_value(flow.stop_ts),
            str(int(flow.stop_ts - flow.start_ts)),
            str(flow.original.bytes),
            str(flow.reply.bytes),

            None,       # package_name
            None,       # package_code
            None,       # package_id
            "Data",
            "101",
            box_id and "Bus{}".format(box_id),

            device_phone,
            flow.reply.dst,
            imei,
            coords and ' '.join(map(self.coordinate_to_value, (coords.lat, coords.lng))),
            None,
            None,
            None,
            None,
            None,
            
        ] 

class IranCDRJSONOutput(CSVOutput):
    with_headers = False

    def values(self, flow, arp=None, user=None, coords=None, box=None, **kwargs):
        if not TEST and (arp is None or user is None or box is None):
            return 
        device_phone = box.device_phone
        box_id = box.device_id
        imei = box.imei
        coords = box.location

        return {
            "SessionId": arp and self.session_id_value(arp.mac, flow.id),  # session_id
            "MSISDN": user and user.phone,
            "Ip": flow.original.dst,
            "MacAddress": arp and self.mac_to_value(arp.mac),
            "StartTime": self.time_to_value(flow.start_ts),
            "EndTime": self.time_to_value(flow.stop_ts),
            "Duration": str(int(flow.stop_ts - flow.start_ts)),
            "ByteUp": str(flow.original.bytes),
            "ByteDown": str(flow.reply.bytes),
            "PackageName": None,       # package_name
            "PackageCode": None,       # package_code
            "PackageId": None,       # package_id
            "ServiceType": "Data",
            "cdr_type": "101",
            "NAS_ID": box_id and "Bus{}".format(box_id),
            "NodeMsisdn": device_phone,
            "NodeIP": flow.reply.dst,
            "NodeIMEI": imei,
            "NodeLocation": coords and ' '.join(map(self.coordinate_to_value, (coords.lat, coords.lng))),
        }

    def ip_port_to_value(self, v):
        ip, port = v
        return '{:x}'.format(ip), port

    def mac_to_value(self, mac):
        return self.purify_mac_value(mac)

    def purify_mac_value(self, mac):
        return ''.join(ch for ch in mac if ch not in ':-')

    def coordinate_to_value(self, coord):
        return '{:.5f}'.format(coord)

    def session_id_value(self, mac, flow_id):
        return '{}{}'.format(purify_mac_value(mac), flow_id)

    def time_to_value(self, value):
        return datetime.utcfromtimestamp(value).replace(tzinfo=timezone.utc).astimezone(tz=timezone(timedelta(hours=4, minutes=30))).strftime('%Y%m%d%H%M%S')

def conntrack_logs(cmd=None):
    if cmd is None:
        cmd = CONNTRACK_CMD
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
    yield from p.stdout


def emulated_conntrack_logs(fp='logs/conntrack.xml'):
    p = subprocess.Popen('cat {}'.format(fp), shell=True, stdout=subprocess.PIPE)
    yield from p.stdout


def get_box_id(interface=None):
    if interface is None:
        interface = NETWORK_INTERFACE
    cmd = "ifconfig "+interface+" | grep -oE '(([0-9a-fA-F]{2}[:-]{1}){5}[0-9a-fA-F]{2})'"
    return subprocess.check_output(cmd, shell=True).decode().strip()


@contextlib.contextmanager
def output_file(name=None, save=None, dir=None, service=None, box_id=None, operator=None, date_format=None, mode='w', **kwargs):
    if operator is None:
        operator = OUTPUT_OPERATOR_NAME
    if service is None:
        service = OUTPUT_SERVICE_NUMBER
    if dir is None:
        dir = OUTPUT_DIRECTORY
    if name is None:
        name = OUTPUT_FILENAME_CURRENT
    if save is None:
        save = OUTPUT_FILENAME_TEMPLATE
    if box_id is None:
        box_id = get_box_id().replace(':', '-')
    if date_format is None:
        date_format = OUTPUT_DATE_FORMAT

    tmp_fp = os.path.join(dir, name)
    os.makedirs(dir, exist_ok=True)
    f = open(tmp_fp, mode=mode)
    try:
        yield f
    finally:
        f.close()
        now = datetime.now()
        dst = os.path.join(dir, save.format(dt_info=now.strftime(date_format), service=service, operator=operator, box_id=box_id, **kwargs))
        shutil.move(tmp_fp, dst)
        return dst


DEFAULT_FILE_OPENER = output_file

SEND_REPORTS_USERNAME = 'ara_box_nooken'
SEND_REPORTS_PASSWORD = 'Ar@Ftp#123'
SEND_REPORTS_HOSTNAME = '185.24.136.21'
SEND_REPORTS_PORT = 2121
SEND_REPORTS_DIR = 'ARA_box'

SEND_REPORTS_MAKEDIRS = False

def _set_send_options(**kwargs):
    diff = set(kwargs.keys()).difference('username password hostname port dir makedirs'.split())
    assert not diff, '{} keys misunderstood'.format(diff)
    for k, v in kwargs.items():
        gk = 'SEND_REPORTS_'+k.upper()
        pv = globals()[gk]
        globals()[gk] = v
        print(gk, '=', globals()[gk], '({!r})'.format(pv))


def send_reports_ftp(files, makedirs=True, delete=True):

    makedirs = SEND_REPORTS_MAKEDIRS

    if not files:
        return

    with ftplib.FTP() as ftp:
        print(ftp.connect(SEND_REPORTS_HOSTNAME, SEND_REPORTS_PORT))
        print(ftp.login(SEND_REPORTS_USERNAME, SEND_REPORTS_PASSWORD))

        directory = SEND_REPORTS_DIR

        if makedirs:
            head, tail = os.path.split(directory)
            ds = [directory, ]
            while tail != '':
                ds.append(head)
                head, tail = os.path.split(head)

            for d in ds[::-1]:
                try:
                    ftp.mkd(d)
                except ftplib.error_perm as e:
                    continue

        for fp, fn in files:
            with open(fp, 'rb') as f:
                print(ftp.storbinary('stor '+os.path.join(directory, fn), f))
            if delete:
                os.remove(fp)


def send_reports_ftp_cmd(files, makedirs=True, delete=True):

    makedirs = SEND_REPORTS_MAKEDIRS

    if not files:
        return

    directory = SEND_REPORTS_DIR

    if makedirs:
        head, tail = os.path.split(directory)
        ds = [directory, ]
        while tail != '':
            ds.append(head)
            head, tail = os.path.split(head)

        mkd = '\n'.join(map(lambda x: 'mkd '+x, ds[::-1]))
    else:
        mkd = ''

    put = []
    for fp, fn in files:
        d, f = os.path.split(fp)
        put.append('lcd '+d)
        put.append('put '+f)
    put = '\n'.join(put)

    # local_dir = os.path.dirname(files[0][1])
    # put = 'lcd {directory}\nmput *.csv'.format(directory=local_dir)

    os.system('''
ftp -n -i -p {host} {port} <<EOF
quote USER {username}
quote PASS {password}
{mkd}
cd {directory}
{put}
quit
EOF
'''.format(host=SEND_REPORTS_HOSTNAME, port=SEND_REPORTS_PORT,
           username=SEND_REPORTS_USERNAME, password=SEND_REPORTS_PASSWORD,
           mkd=mkd, put=put,
           directory=directory,
           ))

    if delete:
        os.system('''rm {files}'''.format(files=' '.join(fp for fp, _ in files)))


def is_empty_report(fp):
    with open(fp) as f:
        header_line = f.readline()
        next_line = f.readline()
        if next_line == '':
            return True
    return False


def send_reports(dir=None, send=None, clean_empty=True,
                 pattern=re.compile(r'.*\.csv$'), 
                 *sender_args, **sender_kwargs,
                 ):

    if dir is None:
        dir = OUTPUT_DIRECTORY
    
    if send is None:
        send = DEFAULT_SENDER

    files = [(os.path.join(dir, fn), fn) for fn in os.listdir(dir) if pattern.match(fn)]

    non_empty_files = []
    for fp, fn in files:
        if not is_empty_report(fp):
            non_empty_files.append((fp, fn))
        elif clean_empty:
            os.remove(fp)

    send(non_empty_files, 
         *sender_args, 
         **sender_kwargs,
         )

def send_json_reports(dir=None, send=None, clean_empty=True,
                 pattern=re.compile(r'.*\.csv$'),
                 *sender_args, **sender_kwargs,
                 ):
    
    global host
    global opts

    pattern = re.compile(r'.*\.'+opts.output_type+'\.json$')

    if dir is None:
        dir = OUTPUT_DIRECTORY

    files = [(os.path.join(dir, fn), fn) for fn in os.listdir(dir) if pattern.match(fn)]

    non_empty_files = []
    for fp, fn in files:
        if not is_empty_report(fp):
            non_empty_files.append((fp, fn))
        else:
            os.remove(fp)

    endpoint = None
    if opts.output_type == 'ipdr':
        endpoint = '/network/v1/ipdr'
    else:
        endpoint = '/network/v1/cdr'

    if host == None or len(host) < 10:
        host = get_host()

    for path in non_empty_files:
        fp = path[0]
        f= open(fp,"r")
        content = f.read()
        if content is not None:
            content = content[:-2]
            data = json.loads("[" + content + "]")

            response = requests.post(host + endpoint, headers={"content-type":"application/json"}, json=data)
            if response.status_code == 200:
                os.remove(fp)
        f.close()

class FileEventHandler:

    def file_opened(self, file):
        raise NotImplementedError()

    def file_closing(self, file):
        raise NotImplementedError()

    def file_closed(self):
        raise NotImplementedError()

    def file_dispatched(self, file, *args, **kwargs):
        raise NotImplementedError()


class FileLogger(FileEventHandler):
    def __init__(self, on_open=None, on_closing=None, on_dispatch=None, on_closed=None):
        self.on_open, self.on_closing, self.on_dispatch, self.on_closed = on_open, on_closing, on_dispatch, on_closed
    
    def file_opened(self, file):
        if self.on_open:
            self.on_open(file)
    def file_closing(self, file):
        if self.on_closing:
            self.on_closing(file)
    def file_dispatched(self, file, *args, **kwargs):
        if self.on_dispatch:
            self.on_dispatch(file, *args, **kwargs)
    def file_closed(self):
        if self.on_closed:
            self.on_closed()


class FileForIntervalDispatcher(threading.Thread):

    def __init__(self, handler=None, interval=None, _sleep=None, _open_file=None, on_open=None, on_dispatch=None, on_closed=None, on_closing=None, **file_open_options):
        self.interval = interval if interval is not None else FILE_OPEN_INTERVAL
        self._sleep = _sleep if _sleep is not None else FILE_DISPATCHER_SLEEP_INTERVAL
        self.handler = handler if handler is not None else FileLogger(on_open=on_open, on_closing=on_closing, on_dispatch=on_dispatch, on_closed=on_closed)
        self.file = None
        self._open_file = _open_file if _open_file is not None else DEFAULT_FILE_OPENER
        self._open_options = file_open_options
        self._stopped = False
        self._undispatched = collections.deque()
        super().__init__()

    def dispatch(self, *args, **kwargs):
        # assert self.file is not None, "Can not dispatch while not .start()'ed"
        self._undispatched.append((args, kwargs))
        while self._undispatched:
            if self.file is None:
                break
            a, kwa = self._undispatched.popleft()
            self.handler.file_dispatched(self.file, *a, **kwa)

    def run(self):
        while not self._stopped:
            with self._open_file(**self._open_options) as f:
                self.handler.file_opened(f)
                self.file = f
                ts = time.time() + self.interval
                while not self._stopped and ts - time.time() > 0:
                    time.sleep(self._sleep)
                self.handler.file_closing(f)
            self.file = None
            self.handler.file_closed()

    def stop(self):
        self._stopped = True
    
    def __enter__(self):
        self.start()
        return self
    
    def __exit__(self, *exc_args):
        self.stop()
        self.join()



class OutputToFileManager(FileEventHandler):

    def __init__(self, output):
        self.logs = 0
        self.output = output
        self.sender_threads = []
        self.report_type = None

    def file_opened(self, file):
        self.logs = 0
        init_line = self.output.init()
        if init_line is not None:
            print(init_line, file=file, flush=True)

    def file_dispatched(self, file, line):
        try:
            print(line, file=file, flush=True)
        except ValueError:
            # I/O operation on closed file.
            return
        else:
            self.logs += 1

    def file_closed(self):
        if self.logs > 0:
            # send_reports()
            # sending files in background
            new_th = threading.Thread(target=send_json_reports)
            new_th.start()
            self.sender_threads = [*(th for th in self.sender_threads if th.is_alive()), new_th]

    def file_closing(self, file):
        pass

    def __enter__(self):
        return self
    
    def __exit__(self, *exc_args):
        for th in self.sender_threads:
            th.join()

    @property
    def dispatcher_options(self):
        return dict(
            on_open=self.file_opened, 
            on_closed=self.file_closed, 
            on_dispatch=self.file_dispatched,
        )

def main():

    import optparse

    parser = optparse.OptionParser()

    output_types = ('ipdr', 'cdr')
    parser.add_option('-t', '--type', action='store', dest='output_type', help='one of type: {0} (default: {0[0]})'.format(output_types), type='choice', choices=output_types, default='ipdr')

    parser.add_option('--apn', action='store', dest='apn', default=None)
    parser.add_option('--imsi', action='store', dest='imsi', default=None)
    parser.add_option('--imei', action='store', dest='imei', default=None)

    parser.add_option('-c', '--exec', action='append', dest='exec', default=[])
    parser.add_option('-i', '--include', action='append', dest='include', default=[])
    
    parser.add_option('-d', '--delimiter', action='store', dest='delimiter', default=None, help='CSV delimiter')
    parser.add_option('--null', action='store', dest='null', default=None, help='CSV null value')
    parser.add_option('--test', action='store_true', dest='test', default=False)

    parser.add_option('-o', '--current-output-file', action='store', dest='current_output_file', default=OUTPUT_FILENAME_CURRENT)
    
    parser.add_option('--dry-run', action='store_true', dest='dry_run', default=False)
    
    global opts
    opts, args = parser.parse_args()
    
    global TEST
    TEST = opts.test

    output = None
    if opts.output_type == 'ipdr':
        output = IranIPDRJSONOutput()
    elif opts.output_type == 'cdr':
        output = IranCDRJSONOutput()
    else:
        assert False, 'undefined output type %s' % opts.output_type

    

    include = []
    if 'REPORTER_INCLUDE' in os.environ:
        include.extend(os.environ['REPORTER_INCLUDE'].strip().strip(';').split(';'))
    include.extend(opts.include)

    for i in include:
        with open(i) as f:
            exec(f.read(), globals())

    exec_values = []
    if 'REPORTER_EXEC' in os.environ:
        exec_values.append(os.environ['REPORTER_EXEC'])
    exec_values.extend(opts.exec)

    for i in exec_values:
        exec(i, globals())

    arpd = arpdict()    

    # arpd = {'192.168.2.171': ARPLine(ip='192.168.2.171', mac='ac:b5:7d:e5:42:a5', interface='wlan0')}

    def get_strong_value(generator, minimum=3, sleep=1, max=15, check=bool, default=None):
        assert not max or max > minimum
        c = Counter()
        i = 0
        while True:
            v = generator()
            c[v] += 1
            for k, v in c.items():
                if check(k) and v >= minimum:
                    return k
            i += 1
            if max and i == max:
                return default
            time.sleep(sleep)

    def is_digits_str(with_length_more_than=None):
        return lambda x: bool(re.match(r'^[0-9]{'+str(with_length_more_than or 0)+r',}$', x))

    global host
    host = get_host()
    apn = opts.apn or get_apn()
    imsi = opts.imsi if opts.imsi is not None else get_strong_value(get_imsi, max=None, check=is_digits_str(14))
    imei = opts.imei if opts.imei is not None else get_strong_value(get_imei, max=None, check=is_digits_str(15))

    delimiter = opts.delimiter
    nulls = opts.null

    if opts.dry_run:
        print('''
apn: {apn!r}
imei: {imei!r}
imsi: {imsi!r}
delimiter: {delimiter!r}
null: {null!r}
test: {test!r}
output_type: {output_type!r}
current_output_file: {current_output_file!r}
dry-run: {dry_run!r}
TEST: {TEST!r}

arpdict: {arpdict!r}
output: {output!r}
'''.format(
    dry_run=opts.dry_run,
    apn=apn,
    imsi=imsi,
    imei=imei,
    delimiter=delimiter,
    null=nulls,
    test=opts.test,
    output_type=opts.output_type,
    current_output_file=opts.current_output_file,
    TEST=globals()['TEST'],

    arpdict=arpdict(),
    output=output,
))
        sys.exit()

    logs_generator = emulated_conntrack_logs if opts.test else conntrack_logs

    with OutputToFileManager(output) as output_manager, \
        FileForIntervalDispatcher(handler=output_manager, 
                                  output_type=opts.output_type, 
                                  name=opts.current_output_file,
                                  ) as file_dispatcher:

        logs = IT.islice(logs_generator(), 2, None)
        
        for i, line in enumerate(logs):
            try:
                flow = ConntrackFlow.parsexml(line)
            except Exception:
                print('PARSE_ERROR:', line)
                continue

            if not flow:
                print('PARSE_ERROR(2):', line)
                continue

            if flow.state == 'unreplied':
                print('UNREPLIED:', line)
                continue
            
            if flow.valid == flow.invalid:
                print('VALID==INVALID:', line)
                continue
            
            arp = arpd.get(flow.original.src)
            if not arp:
                arpd.update(arpdict())
                # arpd = arpdict()
                arp = arpd.get(flow.original.src)
                if not arp:
                    pass
                    # continue

            user = arp and User.get(arp.mac)
            if not user:
                pass
                # continue

            location = Coordinate.get()

            box = BoxInfo.get(imsi=imsi, imei=imei, apn=apn, location=location)
            
            l = output.values(flow, arp=arp, user=user, box=box)
            
            if l is not None:
                file_dispatcher.dispatch(json.dumps(l) + ",")


if __name__ == '__main__':
    main()
