#!/bin/bash

if [ "$2" == "AP-STA-DISCONNECTED" ]
then
	IP=$(arp -a | grep "$3" | grep -o "\([0-9]\{1,3\}[.]\)\{3\}[0-9]\{1,3\}")
	if [ ! -z $IP ]; then
		iptables -t nat -D PREROUTING -s $IP -j ACCEPT 
		iptables -D FORWARD -s $IP -j ACCEPT 
		iptables -D FORWARD -d $IP -j ACCEPT
		ATJOB=$(cat /tmp/atjobs.list | grep "$IP [0-9]*" | grep -o "[0-9]*$")
		echo "$3 $IP $ATJOB"
		atrm $ATJOB
		sed -i "/$IP /d" /tmp/atjobs.list
	fi
fi
