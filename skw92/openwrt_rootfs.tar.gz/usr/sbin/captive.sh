#!/bin/bash

echo 'timer' > /sys/class/leds/lte/trigger
chmod -R 777 /mnt/media

sysctl net.ipv4.ip_forward=1
if df /dev/mmcblk0p2 | grep -q "100%"
then
	resize2fs -f /dev/mmcblk0p2
fi

iptables -t nat -A PREROUTING -p tcp ! --dport 53 -j DNAT --to-destination 192.168.2.1
iptables -P FORWARD DROP

iptables -t nat -A POSTROUTING -o wwan0 -j MASQUERADE

tc qdisc add dev wlan0 root handle 1: htb
tc class add dev wlan0 parent 1: classid 1:1 htb rate 300Mbit

# Class 1:10 for local trafic From 192.168.2.1 to WiFi client
tc class add dev wlan0 parent 1:1 classid 1:10 htb rate 300Mbit prio 1
tc filter add dev wlan0 protocol ip parent 1:0 prio 1 u32 match ip src 192.168.2.1 flowid 1:10

# Class 1:11 for internet trafic
tc class add dev wlan0 parent 1:1 classid 1:11 htb rate 300Mbit

# Class 1:10 for data from 192.168.2.1 to internet
iptables -A PREROUTING -t mangle -s 192.168.2.1 -j MARK --set-mark 1
# 241 Class and filter rules for all clients IP range
for (( I=2;I<=254;I++ ))
do
	tc class add dev wlan0 parent 1:11 classid 1:1$I htb rate 10Mbit ceil 100Mbit prio 2
	tc filter add dev wlan0 protocol ip parent 1:0 prio 2 u32 match ip dst 192.168.2.$I flowid 1:1$I
	iptables -A PREROUTING -t mangle -s 192.168.2.$I -j MARK --set-mark $I
done

tc qdisc add dev wwan0 root handle 1: htb
tc class add dev wwan0 parent 1: classid 1:1 htb rate 150Mbit
# Class 1:10 for data from 192.168.2.1 to internet
tc class add dev wwan0 parent 1:1 classid 1:10 htb rate 10Mbit ceil 20Mbit prio 1
tc filter add dev wwan0 protocol ip parent 1:0 prio 1 handle 1 fw flowid 1:10
# 241 Class and filter rules for all clients IP range
for (( I=2;I<=254;I++ ))
do
	tc class add dev wwan0 parent 1:1 classid 1:1$I htb rate 10Mbit ceil 20Mbit prio 2
	tc filter add dev wwan0 protocol ip parent 1:0 prio 2 handle $I fw flowid 1:1$I
done

echo -ne 'AT+CGPS=1,1\r\n' > /dev/ttyUSB2
IMEI=$(uqmi -s -d /dev/cdc-wdm0 --get-imei) 
echo "$IMEI" > /tmp/modem.imei
echo "$IMEI" > /tmp/inobi/add.d/imei.json


while :
do
	sleep 10
	uqmi -d /dev/cdc-wdm0 --get-signal-info > /tmp/modem.stat
	if uqmi -d /dev/cdc-wdm0 --get-data-status | grep -q "\"connected\""; then
		if ping -c 1 -W 3 inobi.kg; then
			if [ "$(cat /sys/class/leds/lte/delay_off)" != "2000" ]; then
			echo '2000' > /sys/class/leds/lte/delay_off
			echo '200' > /sys/class/leds/lte/delay_on
			fi
		else 
			if [ "$(cat /sys/class/leds/lte/delay_off)" != "500" ]; then
			echo '500' > /sys/class/leds/lte/delay_on
			echo '500' > /sys/class/leds/lte/delay_off
			fi
		fi
	else
		if [ "$(cat /sys/class/leds/lte/delay_off)" != "200" ]; then
			echo '200' > /sys/class/leds/lte/delay_on
			echo '200' > /sys/class/leds/lte/delay_off
		fi	
	fi	
done


